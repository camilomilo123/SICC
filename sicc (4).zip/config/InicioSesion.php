<?php
// Mostrar todos los errores de PHP (útil en desarrollo)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Importa el archivo que contiene la clase de conexión a base de datos
require_once '../models/conexion_bd.php';

// Inicia o reanuda una sesión
session_start();

// Verifica que el método de solicitud sea POST (es decir, que venga de un formulario)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Obtiene los datos enviados desde el formulario
    $correo = $_POST['correo'];
    $password = $_POST['password'];
    
    try {
        // Instancia la clase Database y obtiene la conexión PDO
        $conexion = new Database();
        $pdo = $conexion->getConnection();

        // Prepara y ejecuta una consulta para buscar al usuario por correo
        $sql = "SELECT id_usuario, nombre, correo, role_id, contraseña FROM usuario WHERE correo = :correo";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['correo' => $correo]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // Verifica si se encontró un usuario con ese correo
        if (!$user) {
            echo "<script>
                    alert('Usuario no encontrado');
                    window.location.href = '../index.php';
                  </script>";
            exit();
        }

        // Verifica que el nombre no esté vacío o NULL
        if (empty($user['nombre'])) {
            echo "<script>alert('Error: El campo nombre está vacío en la base de datos');</script>";
            exit();
        }

        // Verifica si la contraseña ingresada coincide con la contraseña hasheada en la base de datos
        if (password_verify($password, $user['contraseña'])) {
            // Si la verificación es correcta, guarda datos del usuario en la sesión
            $_SESSION['user_id'] = $user['id_usuario'];
            $_SESSION['correo'] = $user['correo'];
            $_SESSION['username'] = $user['nombre'];
            $_SESSION['role_id'] = $user['role_id'];

            // Finaliza el almacenamiento de la sesión antes de redirigir
            session_write_close();

            // Redirige al usuario a la página correspondiente según su rol
            if ($user['role_id'] == 1) {
                header('Location: ../views/admin/administrador.php');
                exit();
            } elseif ($user['role_id'] == 2) {
                header('Location: ../views/Laboratorio/laboratorio.php');
                exit();
            } elseif ($user['role_id'] == 3) {
                header('Location: ../views/Deportes/deportes.php');
                exit();
            } elseif ($user['role_id'] == 4) {
                header('Location: ../views/Bienestar/bienestar.php');
                exit();
            } elseif ($user['role_id'] == 5) {
                header('Location: ../views/Hospedaje/hospedaje.php');
                exit();
            } else {
                // Si el rol no es válido, muestra una alerta
                echo "<script>alert('Acceso denegado');</script>";
            }
        } else {
            // Si la contraseña no coincide, muestra un mensaje de error
            echo "<script>
                    alert('credenciales incorrectas');
                    window.location.href = '../index.php';
                  </script>";
            exit();
        }
    } catch (Throwable $th) {
        // Captura y muestra errores si ocurre una excepción o error
        echo "Error en la conexión: " . $th->getMessage();
    }
}


