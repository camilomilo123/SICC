<?php
// Inicia o reanuda una sesión
session_start();

// Elimina todas las variables de sesión
session_unset(); 

// Destruye la sesión actual completamente
session_destroy(); 

// Previene que el navegador almacene en caché esta página
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");

// Asegura la compatibilidad con algunas versiones de Internet Explorer
header("Cache-Control: post-check=0, pre-check=0", false);

// Otra cabecera para evitar caché (por compatibilidad con HTTP/1.0)
header("Pragma: no-cache");

// Redirige al usuario a la página principal (index.php)
header("Location: ../index.php");

// Finaliza el script para asegurarse de que no se ejecute nada más
exit();
