<?php
// Inicia la sesión para gestionar la información del usuario
session_start();

// Establece el nombre de usuario desde la sesión o como 'Usuario' si no está definido
$username = isset($_SESSION['username']) ? $_SESSION['username'] : 'Usuario';

// Habilita la visualización de todos los errores para facilitar la depuración
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Carga el autoload de Composer y el archivo de conexión a la base de datos
require '../vendor/autoload.php';
require_once '../models/conexion_bd.php';

// Usa la librería Dompdf para generar PDFs
use Dompdf\Dompdf;
use Dompdf\Options;

// Establece la zona horaria de Bogotá
date_default_timezone_set('America/Bogota');
// Obtiene la fecha y hora actuales
$fecha_actual = date('Y-m-d');
$hora_actual = date('h:i A');

// Recupera las fechas y la dependencia desde los parámetros GET, o usa las actuales
$fecha_inicio = isset($_GET['fecha_inicio']) ? $_GET['fecha_inicio'] : $fecha_actual;
$fecha_fin = isset($_GET['fecha_fin']) ? $_GET['fecha_fin'] : $fecha_actual;
$dependencia = isset($_GET['dependencia']) ? $_GET['dependencia'] : '';

// Formatea las fechas para incluir la hora completa
$fecha_inicio .= " 00:00:00";
$fecha_fin .= " 23:59:59";

// Establece la conexión a la base de datos
$conexion = new Database();
$pdo = $conexion->getConnection();

// Si la conexión falla, termina el script mostrando un error
if (!$pdo) {
    die("Error al conectar con la base de datos.");
}

// Consulta SQL para obtener los registros dentro del rango de fechas y de la dependencia específica
$sql = "SELECT dependencia, responsable, id, insumo, fecha, unidad_medida, cantidad_anterior, cantidad_ingresada, cantidad_total 
        FROM entradas 
        WHERE fecha BETWEEN :fecha_inicio AND :fecha_fin
        AND dependencia = :dependencia";

// Prepara la consulta y la ejecuta
$stmt = $pdo->prepare($sql);
$stmt->bindParam(':fecha_inicio', $fecha_inicio);
$stmt->bindParam(':fecha_fin', $fecha_fin);
$stmt->bindParam(':dependencia', $dependencia);
$stmt->execute();

// Obtiene todos los registros de la consulta
$insumos = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Configura las opciones de Dompdf
$options = new Options();
$options->set('defaultFont', 'Helvetica'); // Establece la fuente predeterminada
$options->set('isHtml5ParserEnabled', true); // Permite el parseo de HTML5
$options->set('isRemoteEnabled', true); // Permite cargar imágenes desde URLs remotas
$chrootPath = realpath($_SERVER['DOCUMENT_ROOT']);
$options->set('chroot', $chrootPath); // Establece el directorio raíz para las imágenes remotas

// Crea una instancia de Dompdf con las opciones configuradas
$dompdf = new Dompdf($options);

// Obtiene la ruta de la imagen del logo
$imagen = realpath($_SERVER['DOCUMENT_ROOT'] . '/views/img/senap.jpg');

// Verifica si la imagen existe, y si no, termina el script mostrando un error
if (!$imagen || !file_exists($imagen)) {
    die('La imagen no se encontró en: ' . $imagen);
}

// Comienza la construcción del contenido HTML para el reporte
$html = '
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reporte entradas</title>
    <link rel="icon" href="/views/icons/hexagon-fill.svg" type="image/x-icon">
    <style>
        body { font-family: Arial, sans-serif; }
        .container { width: 100%; padding: 10px; }
        .header-table { width: 100%; border-bottom: 2px solid #333; margin-bottom: 5px; }
        .header-table td { vertical-align: middle; padding: 2px; }
        .logo { width: 60px; height: auto; }
        .title { text-align: center; font-size: 14px; font-weight: bold; }
        .info { text-align: right; font-size: 12px; line-height: 1.2; }
        .table { width: 100%; font-size: 14px; border-collapse: collapse; margin-top: 5px; }
        .table th { border-bottom: 2px solid black; padding: 8px; text-align: center; font-weight: bold; }
        .table td { padding: 5px; text-align: center; }
    </style>
</head>
<body>
<div class="container">
    <table class="header-table">
        <tr>
            <td style="width: 15%;">
                <img src="file://' . $imagen . '" class="logo" />
            </td>
            <td style="width: 70%;" class="title">
                <p>SENA - SERVICIO NACIONAL DE APRENDIZAJE - 899999034-1<br>
                25. SENA - REGIONAL CUNDINAMARCA C. de Costo: 950910 CTR DE DESARROLLO AGROINDUSTRIAL Y <br>
                REPORTE DE ENTRADAS ' . ($fecha_inicio == $fecha_fin ? "DEL " . substr($fecha_inicio, 0, 10) : "DEL " . substr($fecha_inicio, 0, 10) . " AL " . substr($fecha_fin, 0, 10)) . '</p>
            </td>
            <td style="width: 15%;" class="info">
                <p><strong>Usuario:</strong> ' . $username . '</p>
                <p><strong>Fecha:</strong> ' . $fecha_actual . '</p>
                <p><strong>Hora:</strong> ' . $hora_actual . '</p>
            </td>
        </tr>
    </table>

    <table class="table">
        <tr>
            <th>Fecha</th>
            <th>Insumo</th>
            <th>Dependencia</th>
            <th>Responsable</th>
            <th>Cantidad anterior</th>
            <th>Cantidad ingresada</th>
            <th>Cantidad total</th>
            <th>Unidad de medida</th>
        </tr>';

// Itera sobre los insumos para generar una fila por cada uno
foreach ($insumos as $insumo) {
    $html .= '<tr>
        <td>' . htmlspecialchars($insumo["fecha"]) . '</td>
        <td>' . htmlspecialchars($insumo["insumo"]) . '</td>
        <td>' . htmlspecialchars($insumo["dependencia"]) . '</td>
        <td>' . htmlspecialchars($_SESSION['username']) . '</td>
        <td>' . (fmod($insumo["cantidad_anterior"], 1) == 0 ? number_format($insumo["cantidad_anterior"], 0) : number_format($insumo["cantidad_anterior"], 2)) . '</td>
        <td>' . (fmod($insumo["cantidad_ingresada"], 1) == 0 ? number_format($insumo["cantidad_ingresada"], 0) : number_format($insumo["cantidad_ingresada"], 2)) . '</td>
        <td>' . (fmod($insumo["cantidad_total"], 1) == 0 ? number_format($insumo["cantidad_total"], 0) : number_format($insumo["cantidad_total"], 2)) . '</td>
        <td>' . htmlspecialchars($insumo["unidad_medida"]) . '</td>
    </tr>';
}

// Cierra la tabla y el cuerpo del documento HTML
$html .= '</table></body></html>';

// Carga el contenido HTML en Dompdf
$dompdf->loadHtml($html);

// Establece el formato horizontal del documento PDF
$dompdf->setPaper('A4', 'landscape');

// Renderiza el PDF
$dompdf->render();

// Muestra el PDF en el navegador sin forzar la descarga
$dompdf->stream("ReporteEntradas_" . date('Ymd') . ".pdf", ['Attachment' => false]);
?>







