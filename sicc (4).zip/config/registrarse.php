<?php
// Habilita la visualización de todos los errores para facilitar la depuración
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Incluye el archivo de conexión a la base de datos
require_once '../models/conexion_bd.php';

// Verifica si la solicitud se hizo mediante el método POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Obtiene y limpia los datos recibidos desde el formulario
    $nombre = trim($_POST['username']); // Elimina espacios en blanco antes y después del nombre de usuario
    $telefono = trim($_POST['telefono']); // Elimina espacios en blanco antes y después del número de teléfono
    $correo = trim($_POST['correo']); // Elimina espacios en blanco antes y después del correo electrónico
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); // Encripta la contraseña con bcrypt
    $role_id = intval($_POST['rol_id']); // Convierte el rol a un valor entero

    try {
        // Establece la conexión a la base de datos
        $conexion = new Database();
        $pdo = $conexion->getConnection();

        // Consulta para verificar si el correo ya está registrado en la base de datos
        $sqlCheck = "SELECT correo FROM usuario WHERE correo = :correo";
        $stmtCheck = $pdo->prepare($sqlCheck);
        $stmtCheck->execute(['correo' => $correo]);

        // Si ya existe un usuario con ese correo, retorna un error en formato JSON
        if ($stmtCheck->fetch()) {
            echo json_encode(["status" => "error", "message" => "El correo ya está registrado."]);
            exit();
        }

        // Si el correo no está registrado, se procede a insertar el nuevo usuario en la base de datos
        $sql = "INSERT INTO usuario (nombre, telefono, correo, contraseña, role_id) 
                VALUES (:nombre, :telefono, :correo, :password, :role_id)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            'nombre'   => $nombre, // Nombre del usuario
            'telefono' => $telefono, // Número de teléfono
            'correo'   => $correo, // Correo electrónico
            'password' => $password, // Contraseña cifrada
            'role_id'  => $role_id // ID del rol del usuario
        ]);

        // Si todo sale bien, se envía una respuesta en formato JSON indicando éxito
        echo json_encode(["status" => "success"]);
    } catch (PDOException $e) {
        // En caso de error en la conexión o ejecución, se guarda el error en un archivo de log y se envía un mensaje de error
        error_log("Error en el registro: " . $e->getMessage(), 3, "../logs/errors.log");
        echo json_encode(["status" => "error", "message" => "Error en el registro."]);
    }
}
?>
