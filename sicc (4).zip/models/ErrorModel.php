<?php
require_once 'conexion_bd.php';

class ReporteError {
    private $db;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    public function registrar($usuario, $correo, $rol, $tipo_reporte, $mensaje, $nivel, $imagen, $navegador, $sistema, $resolucion) {
        try {
            $query = "INSERT INTO reportes_errores 
                (usuario, correo, rol, tipo_reporte, mensaje, nivel, imagen, navegador, sistema, resolucion)
                VALUES (:usuario, :correo, :rol, :tipo_reporte, :mensaje, :nivel, :imagen, :navegador, :sistema, :resolucion)";
            
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':usuario', $usuario);
            $stmt->bindParam(':correo', $correo);
            $stmt->bindParam(":rol", $rol, PDO::PARAM_STR);
            $stmt->bindParam(':tipo_reporte', $tipo_reporte);
            $stmt->bindParam(':mensaje', $mensaje);
            $stmt->bindParam(':nivel', $nivel);
            $stmt->bindParam(':imagen', $imagen);
            $stmt->bindParam(':navegador', $navegador);
            $stmt->bindParam(':sistema', $sistema);
            $stmt->bindParam(':resolucion', $resolucion);
            
            $stmt->execute();
            return true;
        } catch (Exception $e) {
            return false;
        }
    }
    public function Errores() {
        try {
            $query = "SELECT id, usuario, correo, rol, tipo_reporte, mensaje, nivel,solucionado, fecha, imagen FROM reportes_errores ORDER BY fecha DESC";
            $stmt = $this->db->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            return [];
        }
    }
    public function obtenerTodos() {
        try {
            $sql = "SELECT * FROM reportes_errores ORDER BY fecha DESC";
            $stmt = $this->db->prepare($sql);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }
}


