<?php
// Definición de la clase Database para manejar la conexión a la base de datos
class Database {
    // Propiedades privadas con los datos de conexión (host, nombre de base de datos, usuario y contraseña)
    private $host = "localhost";
    private $db_name = "u834726681_inventario_sen";
    private $username = "u834726681_sicc";
    private $password = "#sMocT77";
    public $conn; // Propiedad pública que almacenará la conexión PDO

    // Método público para obtener la conexión a la base de datos
    public function getConnection() {
        $this->conn = null; // Inicializa la conexión como nula

        try {
            // Intenta crear una nueva conexión PDO con los datos definidos
            $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
            // Configura el modo de error de PDO para que lance excepciones
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $exception) {
            // En caso de error, muestra el mensaje de excepción
            echo "Error de conexión: " . $exception->getMessage();
        }

        // Retorna la conexión (puede ser un objeto PDO o null si falló)
        return $this->conn;
    }
}
?>


