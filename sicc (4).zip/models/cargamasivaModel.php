<?php
require_once '../vendor/autoload.php';
require_once "conexion_bd.php";

use PhpOffice\PhpSpreadsheet\IOFactory;

class cargamasivaModel {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function cargarInventario($archivo, $origen) {
        try {
            // Determina la tabla según la vista de origen
            $tablas = [
                'Inv_dep' => 'inventario_deportes',
                'Inv_hos' => 'inventario_hospedaje',
                'Inv_bien' => 'inventario_bienestar'
            ];

            if (!isset($tablas[$origen])) {
                return false; // origen no válido
            }

            $tabla = $tablas[$origen];

            // Cargar archivo Excel
            $documento = IOFactory::load($archivo['tmp_name']);
            $hoja = $documento->getActiveSheet();
            $filas = $hoja->toArray();

            // Preparar la consulta según tabla
            $stmt = $this->conn->prepare("INSERT INTO {$tabla} (elemento, cantidad, unidad_medida, ubicacion) VALUES (?, ?, ?, ?)");

            foreach ($filas as $index => $fila) {
                if ($index == 0) continue;
                if (count($fila) < 4) continue;

                $elemento = $fila[0];
                $cantidad = $fila[1];
                $unidad_medida = $fila[2];
                $ubicacion = $fila[3];

                $stmt->execute([$elemento, $cantidad, $unidad_medida, $ubicacion]);
            }

            return true;
        } catch (Exception $e) {
            return false;
        }
    }
}
