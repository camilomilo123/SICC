<?php
require_once 'conexion_bd.php';

require_once __DIR__ . '/../librerias/PHPMailer/Exception.php';
require_once __DIR__ . '/../librerias/PHPMailer/PHPMailer.php';
require_once __DIR__ . '/../librerias/PHPMailer/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class SalidasModel {
    private $db;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    public function registrarSalida($dependencia, $producto, $cantidad_salida, $unidad_medida, $fecha, $descripcion, $responsable, $tipo) {
        try {
            $this->db->beginTransaction(); // Inicia la transacción

            $tipos_inventario = [
                "Laboratorio" => ["tabla" => "inventario_laboratorio", "columna" => "reactivo"],
                "Deportes"    => ["tabla" => "inventario_deportes", "columna" => "elemento"],
                "Hospedaje"   => ["tabla" => "inventario_hospedaje", "columna" => "insumo"],
                "Bienestar"   => ["tabla" => "inventario_bienestar", "columna" => "elemento"]
            ];

            if (!isset($tipos_inventario[$tipo])) {
                throw new Exception("Tipo de inventario no válido.");
            }

            $tabla = $tipos_inventario[$tipo]['tabla'];
            $columna = $tipos_inventario[$tipo]['columna'];

            $es_id = is_numeric($producto);
            if ($es_id) {
                $query = "SELECT id, cantidad, $columna AS nombre, unidad_medida FROM $tabla WHERE id = :producto FOR UPDATE";
            } else {
                $query = "SELECT id, cantidad, $columna AS nombre, unidad_medida FROM $tabla WHERE $columna = :producto FOR UPDATE";
            }

            $stmt = $this->db->prepare($query);
            $stmt->bindValue(":producto", $producto, $es_id ? PDO::PARAM_INT : PDO::PARAM_STR);
            $stmt->execute();
            $item = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$item) {
                throw new Exception("El producto '$producto' no se encontró en el inventario de $tipo.");
            }

            $id_producto = $item['id'];
            $nombre = $item['nombre'];
            $cantidad_actual = (float) $item['cantidad'];
            $unidad_bd = $item['unidad_medida'];

            // Intentar conversión de unidades
            try {
                $cantidad_convertida = $this->convertirUnidad($cantidad_salida, $unidad_medida, $unidad_bd);
            } catch (Exception $e) {
                return ["status" => "error", "message" => "Unidad de medida inválida: No se puede convertir de '$unidad_medida' a '$unidad_bd'."];
            }

            if ($cantidad_actual < $cantidad_convertida) {
                return ["status" => "error", "message" => "Stock insuficiente: necesitas $cantidad_convertida $unidad_bd pero solo hay $cantidad_actual $unidad_bd."];
            }

            $nueva_cantidad = round($cantidad_actual - $cantidad_convertida, 2);

            if ($nueva_cantidad < 0) {
                return ["status" => "error", "message" => "Stock insuficiente: no puedes retirar más cantidad de la disponible."];
            }

            // Actualizar inventario
            $update = "UPDATE $tabla SET cantidad = :nueva_cantidad WHERE id = :id";
            $stmtUpdate = $this->db->prepare($update);
            $stmtUpdate->bindParam(":nueva_cantidad", $nueva_cantidad);
            $stmtUpdate->bindParam(":id", $id_producto, PDO::PARAM_INT);
            $stmtUpdate->execute();

            // Registrar salida
           $insert = "INSERT INTO salidas (dependencia, insumo, unidad_medida, cantidad_salida, cantidad_total, cantidad_anterior, descripcion, fecha, responsable)
           VALUES (:dependencia, :insumo, :unidad_medida, :cantidad_salida, :cantidad_total, :cantidad_anterior, :descripcion, :fecha, :responsable)";

            $stmtInsert = $this->db->prepare($insert);
            $stmtInsert->bindParam(":dependencia", $dependencia);
            $stmtInsert->bindParam(":insumo", $nombre);
            $stmtInsert->bindParam(":unidad_medida", $unidad_medida);
            $stmtInsert->bindParam(":cantidad_salida", $cantidad_salida);
            $stmtInsert->bindParam(":cantidad_total", $nueva_cantidad);
            $stmtInsert->bindParam(":cantidad_anterior", $cantidad_actual);

            $stmtInsert->bindParam(":descripcion", $descripcion);
            $stmtInsert->bindParam(":fecha", $fecha);
            $stmtInsert->bindParam(":responsable", $responsable);
            $stmtInsert->execute();
            
            $mensaje_notificacion = "El usuario $responsable retiro $cantidad_salida $unidad_medida de $nombre en la dependencia $dependencia.";
    
            // Modificar la consulta para incluir el campo 'tipo'
            $insertNotificacion = "INSERT INTO notificaciones (mensaje, fecha, tipo, categoria) VALUES (:mensaje, NOW(), :tipo, :categoria)";
    
            // Preparar la consulta
            $stmtNotificacion = $this->db->prepare($insertNotificacion);
            // Vincular los parámetros
            $stmtNotificacion->bindParam(":mensaje", $mensaje_notificacion, PDO::PARAM_STR);
            $stmtNotificacion->bindParam(":tipo", $tipo, PDO::PARAM_STR);
            $stmtNotificacion->bindParam(":categoria", $categoria, PDO::PARAM_STR);
            // Establecer el valor de tipo como "salida"
            $tipo = "salida"; 
            $categoria = "laboratorio"; 
            // Ejecutar la consulta
            $stmtNotificacion->execute();

            // Umbrales
            $umbral_por_unidad = [
                "miligramos" => 120,
                "mililitros" => 120,
                "gramos" => 75,
                "kilogramos" => 0.12,
                "libras" => 0.12,
                "litros" => 0.12,
                "unidad" => 3
            ];

            if (isset($umbral_por_unidad[$unidad_bd]) && $nueva_cantidad < $umbral_por_unidad[$unidad_bd]) {
                $this->enviarCorreoSolicitud($nombre, $nueva_cantidad, $unidad_bd, $dependencia); // Ahora envía la cantidad ACTUALIZADA
            }

            $this->db->commit();
            return ["status" => "success", "message" => "Salida registrada correctamente en $tipo."];
        } catch (Exception $e) {
            $this->db->rollBack();
            return ["status" => "error", "message" => $e->getMessage()];
        }
    }

    private function enviarCorreoSolicitud($producto, $cantidad, $unidad, $dependencia) {
        try {
           

            $mensaje =
        <<<HTML
    <div style="height: 100vh; display: flex; justify-content: center; align-items: center; padding: 20px;">
        <div style="max-width: 600px; width: 100%; background-color: #ffffff; border-radius: 12px; padding: 30px; box-shadow: 0px 10px 25px rgba(0, 0, 0, 0.15); font-family: 'Arial', sans-serif; color: #333; text-align: center;">

            <!-- Encabezado con Logo -->
            <div style="padding-bottom: 20px; border-bottom: 2px solid #018b03;">
                <img src="https://siccsena.com/views/img/sena.png" alt="SENA Logo" style="max-width: 100px; display: block; margin: 0 auto;">
                <h2 style="color: #212529; font-size: 26px; margin-top: 10px; font-weight: bold;">📦 Solicitud Automatica de Reabastecimiento</h2>
            </div>

            <!-- Detalles del Producto -->
            <div style="padding: 20px; line-height: 1.6; text-align: left;">
                <p>👋 Hola,</p>
                <p>Se ha generado una solicitud de reabastecimiento automatico debido a la baja cantidad en inventario.</p>
                <ul style="list-style: none; padding-left: 0; font-size: 16px;">
                    <li><strong>🧪 Producto:</strong> $producto</li>
                    <li><strong>🔢 Cantidad actual:</strong>  $cantidad $unidad</li>
                    <li><strong>🏢 Dependencia:</strong> $dependencia</li>
                </ul>
                <p style="margin-top: 20px;">📩 Por favor, atienda esta solicitud y realice el reabastecimiento lo más pronto posible.</p>
                </div>

            <!-- Pie de Página con Información de Contacto -->
            <div style="margin-top: 20px; padding: 10px; background-color: #212529; color: white; border-radius: 0 0 12px 12px;">
                <p style="margin: 5px 0; font-size: 14px;">📍 Dirección: Cl. 2 #13 - 3, Villeta, Cundinamarca</p>
                <p style="margin: 5px 0; font-size: 14px;">📧 Correo: <a href="siccsena@gmail.com" style="color: #28a745; text-decoration: none;">siccsena@gmail.com</a></p>
            </div>

        </div>
    </div>
HTML;



            $mail = new PHPMailer(true);
            $mail->isSMTP();
            $mail->CharSet = 'UTF-8';
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'siccsena@gmail.com';
            $mail->Password = 'cmpccrehyddeoyde';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            $mail->Port = 465;

            $mail->setFrom('siccsena@gmail.com', 'Sistema de Inventario');
            $mail->addAddress('siccsena@gmail.com');

            $mail->isHTML(true); 
            $mail->Subject = '🔔 Solicitud de Reabastecimiento';
            $mail->Body = $mensaje;

            $mail->send(); // ya no se imprime salida
        } catch (Exception $e) {
            // Error de correo, pero no interferimos con el flujo de la app
            error_log("Error al enviar el correo: " . $e->getMessage());
        }
    }

    
     public function getSalida() {
        try {
            $query = "SELECT id, dependencia, responsable, descripcion, fecha, unidad_medida, cantidad_salida, cantidad_total, cantidad_anterior, insumo FROM salidas ORDER BY fecha DESC";
            $stmt = $this->db->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            return [];
        }
    }

    private function convertirUnidad($cantidad, $unidad_origen, $unidad_destino) {
        $conversiones = [
            "gramos" => ["kilogramos" => 0.001, "miligramos" => 1000, "libras" => 0.00220462],
            "kilogramos" => ["gramos" => 1000, "miligramos" => 1000000, "libras" => 2.20462],
            "miligramos" => ["gramos" => 0.001, "kilogramos" => 0.000001, "libras" => 0.00000220462],
            "libras" => ["gramos" => 453.592, "kilogramos" => 0.453592, "miligramos" => 453592],
            "mililitros" => ["litros" => 0.001],
            "litros" => ["mililitros" => 1000]
        ];

        if ($unidad_origen === $unidad_destino) {
            return $cantidad;
        }

        if (isset($conversiones[$unidad_origen][$unidad_destino])) {
            return $cantidad * $conversiones[$unidad_origen][$unidad_destino];
        }

        throw new Exception("No se puede convertir entre estas unidades: $unidad_origen y $unidad_destino.");
    }
}
?>
