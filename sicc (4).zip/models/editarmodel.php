<?php
require_once 'conexion_bd.php';

class EditarModel {
    private $db;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    public function registrarcambio($id, $tipo, $nombre = null, $formula = null, $estado = null, $fecha_vencimiento = null, $lote = null, $ubicacion = null, $codigo = null, $cantidad = null, $unidad_medida = null) {
        try {
            $this->db->beginTransaction(); // Iniciar la transacción

            // Determinar la tabla y la columna de nombre según el tipo
            if ($tipo === "Laboratorio") {
                $tabla = "inventario_laboratorio";
                $columna_nombre = "reactivo";
                $sql_select = "SELECT reactivo AS nombre, formula, estado, fecha_vencimiento, lote, unidad_medida, ubicacion, codigo_almacenamiento, cantidad FROM $tabla WHERE id = :id";
            } elseif ($tipo === "Deportes") {
                $tabla = "inventario_deportes";
                $columna_nombre = "elemento";
                $sql_select = "SELECT elemento AS nombre, unidad_medida, ubicacion, cantidad FROM $tabla WHERE id = :id";
            } elseif ($tipo === "Hospedaje") {
                $tabla = "inventario_hospedaje";
                $columna_nombre = "insumo";
                $sql_select = "SELECT insumo AS nombre, unidad_medida, ubicacion, cantidad FROM $tabla WHERE id = :id";
            } elseif ($tipo === "Bienestar") {
                $tabla = "inventario_bienestar";
                $columna_nombre = "elemento";
                $sql_select = "SELECT elemento AS nombre, unidad_medida, ubicacion, cantidad FROM $tabla WHERE id = :id";
            } else {
                throw new Exception("Tipo de inventario no válido.");
            }

            // Obtener los valores actuales
            $stmt_select = $this->db->prepare($sql_select);
            $stmt_select->execute([':id' => $id]);
            $datos_actuales = $stmt_select->fetch(PDO::FETCH_ASSOC);

            if (!$datos_actuales) {
                return ["status" => "error", "message" => "El registro no existe."];
            }

            // Mantener valores anteriores si no se envían nuevos
            $nombre = !empty($nombre) ? $nombre : $datos_actuales['nombre'];
            if ($tipo === "Laboratorio") {
                $formula = !empty($formula) ? $formula : $datos_actuales['formula'];
                $estado = !empty($estado) ? $estado : $datos_actuales['estado'];
                $fecha_vencimiento = !empty($fecha_vencimiento) ? $fecha_vencimiento : $datos_actuales['fecha_vencimiento'];
                $lote = !empty($lote) ? $lote : $datos_actuales['lote'];
                $unidad_medida = !empty($unidad_medida) ? $unidad_medida : $datos_actuales['unidad_medida'];
                $ubicacion = !empty($ubicacion) ? $ubicacion : $datos_actuales['ubicacion'];
                $codigo = !empty($codigo) ? $codigo : $datos_actuales['codigo_almacenamiento'];
            }

            $cantidad = (!empty($cantidad) || $cantidad === "0") ? (float)$cantidad : $datos_actuales['cantidad'];
            $unidad_medida = !empty($unidad_medida) ? $unidad_medida : $datos_actuales['unidad_medida'];
            $ubicacion = !empty($ubicacion) ? $ubicacion : $datos_actuales['ubicacion'];

            // Construir la consulta de actualización
            $sql_update = "UPDATE $tabla 
                           SET $columna_nombre = :nombre, unidad_medida = :unidad_medida, 
                               ubicacion = :ubicacion, cantidad = :cantidad";
            
            $params = [
                ':nombre' => $nombre,
                ':unidad_medida' => $unidad_medida,
                ':ubicacion' => $ubicacion,
                ':cantidad' => $cantidad,
                ':id' => $id
            ];

            if ($tipo === "Laboratorio") {
                $sql_update .= ", formula = :formula, estado = :estado, 
                                fecha_vencimiento = :fecha_vencimiento, lote = :lote, 
                                codigo_almacenamiento = :codigo";
                $params += [
                    ':formula' => $formula,
                    ':estado' => $estado,
                    ':fecha_vencimiento' => $fecha_vencimiento,
                    ':lote' => $lote,
                    ':codigo' => $codigo
                ];
            }

            $sql_update .= " WHERE id = :id";
            $stmt_update = $this->db->prepare($sql_update);
            $stmt_update->execute($params);

            $this->db->commit(); // Confirmar la transacción
            return ["status" => "success", "message" => "Registro actualizado correctamente."];

        } catch (PDOException $e) {
            $this->db->rollBack(); // Revertir los cambios si hay un error
            return ["status" => "error", "message" => "Error en la base de datos: " . $e->getMessage()];
        } catch (Exception $e) {
            return ["status" => "error", "message" => $e->getMessage()];
        }
    }
}
?>
