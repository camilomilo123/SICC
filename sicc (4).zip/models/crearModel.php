<?php
require_once "conexion_bd.php";

class CrearModel {
    private $pdo;

    public function __construct() {
        $conexiondb = new Database();
        $this->pdo = $conexiondb->getConnection();
    }

    public function agregarReactivo($datos) {
        try {
            $sql = "INSERT INTO inventario_laboratorio (reactivo, formula, estado, fecha_vencimiento, lote, unidad_medida, ubicacion, codigo_almacenamiento, cantidad) 
                    VALUES (:reactivo, :formula, :estado, :fecha_vencimiento, :lote, :unidad_medida, :ubicacion, :codigo, :cantidad)";
            $stmt = $this->pdo->prepare($sql);
            return $stmt->execute([
                ':reactivo' => $datos['reactivo'],
                ':formula' => $datos['formula'],
                ':estado' => $datos['estado'],
                ':fecha_vencimiento' => $datos['fecha_vencimiento'],
                ':lote' => $datos['lote'],
                ':unidad_medida' => $datos['unidad_medida'],
                ':ubicacion' => $datos['ubicacion'],
                ':codigo' => $datos['codigo'],
                ':cantidad' => $datos['cantidad']
            ]);
        } catch (PDOException $e) {
            die("Error en la base de datos: " . $e->getMessage());
        }
    }
}
?>