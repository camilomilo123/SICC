<?php
require_once "conexion_bd.php"; // Incluir la conexión a la base de datos

class EliminarModel {
    private $pdo;

    public function __construct() {
        $database = new Database();
        $this->pdo = $database->getConnection();
    }

    public function eliminarReactivo($id) {
        try {
            $this->pdo->beginTransaction();

            // Verificar si el reactivo existe en inventario_deportes antes de eliminar
            $sql_check = "SELECT id FROM inventario_deportes WHERE id = :id";
            $stmt_check = $this->pdo->prepare($sql_check);
            $stmt_check->bindParam(":id", $id, PDO::PARAM_INT);
            $stmt_check->execute();

            if ($stmt_check->rowCount() == 0) {
                return false; // No existe el ID en la tabla inventario_deportes
            }

            // Eliminar de la tabla inventario_laboratorio
            $sql = "DELETE FROM inventario_deportes WHERE id = :id";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindParam(":id", $id, PDO::PARAM_INT);
            $stmt->execute();

            $this->pdo->commit();
            return true;
        } catch (PDOException $e) {
            $this->pdo->rollBack();
            error_log("Error en eliminación: " . $e->getMessage()); // Registrar errores en log
            return false;
        }
    }
}
?>
