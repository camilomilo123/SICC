<?php
class InventarioModel {
    private $pdo;

    public function __construct($db) {
        $this->pdo = $db;
    }

    private function obtenerInventarioPorTabla($tabla, $campo, $busqueda = '') {
        try {
            if (!empty($busqueda)) {
                $stmt = $this->pdo->prepare("SELECT id, $campo FROM $tabla WHERE $campo LIKE :busqueda");
                $stmt->bindValue(':busqueda', "%$busqueda%", PDO::PARAM_STR);
            } else {
                $stmt = $this->pdo->prepare("SELECT id, $campo FROM $tabla");
            }

            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Error en la consulta a $tabla: " . $e->getMessage());
            return [];
        }
    }

    public function obtenerInventariolab($busqueda = '') {
        return $this->obtenerInventarioPorTabla('inventario_laboratorio', 'reactivo', $busqueda);
    }

    public function obtenerInventariodep($busqueda = '') {
        return $this->obtenerInventarioPorTabla('inventario_deportes', 'elemento', $busqueda);
    }

    public function obtenerInventariohospe($busqueda = '') {
        return $this->obtenerInventarioPorTabla('inventario_hospedaje', 'insumo', $busqueda);
    }

    public function obtenerInventarionbienes($busqueda = '') {
        return $this->obtenerInventarioPorTabla('inventario_bienestar', 'elemento', $busqueda);
    }

    // Método para obtener la unidad de medida de un insumo por su id
    public function obtenerUnidadMedida($id) {
        try {
            $stmt = $this->pdo->prepare("SELECT unidad_medida FROM inventario_laboratorio WHERE id = :id LIMIT 1");
            $stmt->bindValue(':id', $id, PDO::PARAM_INT);
            $stmt->execute();
            
            // Si se encuentra el insumo con ese id, retornamos la unidad de medida
            if ($stmt->rowCount() > 0) {
                $result = $stmt->fetch(PDO::FETCH_ASSOC);
                return $result['unidad_medida'];
            } else {
                return null; // Si no se encuentra, retornamos null
            }
        } catch (PDOException $e) {
            error_log("Error en la consulta de unidad de medida para id $id: " . $e->getMessage());
            return null;
        }
    }
}
?>
