<?php
require_once 'conexion_bd.php';

class EntradasModel {
    private $db;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        if (!$this->db) {
            die("Error: No se pudo conectar a la base de datos.");
        }
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    public function registrarEntrada($dependencia, $producto, $cantidad_entrada, $unidad_medida, $fecha, $responsable, $tipo) {
        try {
            $this->db->beginTransaction(); // Inicia la transacción

            // Determina la tabla de inventario y la columna de nombre según el tipo
            switch ($tipo) {
                case "Laboratorio":
                    $tabla_inventario = "inventario_laboratorio";
                    $columna_nombre = "reactivo";
                    break;
                case "Deportes":
                    $tabla_inventario = "inventario_deportes";
                    $columna_nombre = "elemento";
                    break;
                case "Hospedaje":
                    $tabla_inventario = "inventario_hospedaje";
                    $columna_nombre = "insumo";
                    break;
                case "Bienestar":
                    $tabla_inventario = "inventario_bienestar";
                    $columna_nombre = "elemento";
                    break;
                default:
                    throw new Exception("Tipo no válido.");
            }

            // Verificar si $producto es un ID numérico o un nombre de producto
            if (is_numeric($producto)) {
                $query = "SELECT id, cantidad, $columna_nombre AS nombre, unidad_medida FROM $tabla_inventario WHERE id = :producto FOR UPDATE";
                $stmt = $this->db->prepare($query);
                $stmt->bindParam(":producto", $producto, PDO::PARAM_INT);
            } else {
                $query = "SELECT id, cantidad, $columna_nombre AS nombre, unidad_medida FROM $tabla_inventario WHERE $columna_nombre = :producto FOR UPDATE";
                $stmt = $this->db->prepare($query);
                $stmt->bindParam(":producto", $producto, PDO::PARAM_STR);
            }
            $stmt->execute();
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$resultado) {
                throw new Exception("El producto '$producto' no existe en el inventario de $tipo.");
            }

            $id_producto = $resultado["id"];
            $cantidad_actual = (float) $resultado["cantidad"];
            $nombre_producto = $resultado["nombre"];
            $unidad_bd = $resultado["unidad_medida"];

            // Convertir la cantidad a la unidad de medida de la base de datos
            $cantidad_entrada_convertida = $this->convertirUnidades($cantidad_entrada, $unidad_medida, $unidad_bd);

            // Calcular la nueva cantidad total
            $nueva_cantidad = $cantidad_actual + $cantidad_entrada_convertida;

            // Actualizar el inventario
            $updateQuery = "UPDATE $tabla_inventario SET cantidad = :nueva_cantidad WHERE id = :id_producto";
            $stmtUpdate = $this->db->prepare($updateQuery);
            $stmtUpdate->bindParam(":nueva_cantidad", $nueva_cantidad, PDO::PARAM_STR);
            $stmtUpdate->bindParam(":id_producto", $id_producto, PDO::PARAM_INT);
            $stmtUpdate->execute();

            // Insertar la entrada
            $insertQuery = "INSERT INTO entradas (dependencia, insumo, fecha, cantidad_anterior, cantidad_ingresada, unidad_medida, responsable) 
                            VALUES (:dependencia, :insumo, :fecha, :cantidad_anterior, :cantidad_ingresada, :unidad_medida, :responsable)";
            $stmtInsert = $this->db->prepare($insertQuery);
            $stmtInsert->bindParam(":dependencia", $dependencia, PDO::PARAM_STR);
            $stmtInsert->bindParam(":insumo", $nombre_producto, PDO::PARAM_STR);
            $stmtInsert->bindParam(":fecha", $fecha, PDO::PARAM_STR);
            $stmtInsert->bindParam(":cantidad_anterior", $cantidad_actual, PDO::PARAM_STR);
            $stmtInsert->bindParam(":cantidad_ingresada", $cantidad_entrada_convertida, PDO::PARAM_STR);
            $unidad_bd = strtolower(trim($unidad_bd)); // convierte a minúsculas y quita espacios

            $stmtInsert->bindParam(":unidad_medida", $unidad_bd, PDO::PARAM_STR);
            $stmtInsert->bindParam(":responsable", $responsable, PDO::PARAM_STR);
            $stmtInsert->execute();

            
            $mensaje_notificacion = "El usuario $responsable ingreso $cantidad_entrada_convertida $unidad_medida de $nombre_producto en la dependencia $dependencia.";
            // Modificar la consulta para incluir el campo 'tipo'
            $insertNotificacion = "INSERT INTO notificaciones (mensaje, fecha, tipo, categoria) VALUES (:mensaje, NOW(), :tipo, :categoria)";
            // Preparar la consulta
            $stmtNotificacion = $this->db->prepare($insertNotificacion);
            // Vincular los parámetros
            $stmtNotificacion->bindParam(":mensaje", $mensaje_notificacion, PDO::PARAM_STR);
            $stmtNotificacion->bindParam(":tipo", $tipo, PDO::PARAM_STR);
            $stmtNotificacion->bindParam(":categoria", $dependencia, PDO::PARAM_STR);
            
            // Establecer el valor de tipo como "entrada"
            $tipo = "entrada";
            $categoria = "laboratorio"; 
            // Ejecutar la consulta
            $stmtNotificacion->execute();

            $this->db->commit();
            return ["status" => "success", "message" => "Entrada registrada correctamente."];

        } catch (Exception $e) {
            $this->db->rollBack();
            return ["status" => "error", "message" => $e->getMessage()];
        }
    }

    
    public function contarEntradas() {
        try {
            $query = "SELECT COUNT(*) AS total FROM entradas";
            $stmt = $this->db->prepare($query);
            $stmt->execute();
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
            return $resultado ? $resultado['total'] : 0;
        } catch (Exception $e) {
            return 0;
        }
    }
    public function ContarUsuarios() {
        try {
            $query = "SELECT COUNT(*) AS total FROM usuario";
            $stmt = $this->db->prepare($query);
            $stmt->execute();
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
            return $resultado ? $resultado['total'] : 0;
        } catch (Exception $e) {
            return 0;
        }
    }
    public function ContarUsuariosLab() {
        try {
            $query = "SELECT COUNT(*) AS total FROM usuario WHERE role_id = :role_id";
            $stmt = $this->db->prepare($query);
            $stmt->bindValue(':role_id', 2, PDO::PARAM_INT); 
            $stmt->execute();
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
            return $resultado ? $resultado['total'] : 0;
        } catch (Exception $e) {
            return 0;
        }
    }
    public function ContarUsuariosHos() {
        try {
            $query = "SELECT COUNT(*) AS total FROM usuario WHERE role_id = :role_id";
            $stmt = $this->db->prepare($query);
            $stmt->bindValue(':role_id', 5, PDO::PARAM_INT); 
            $stmt->execute();
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
            return $resultado ? $resultado['total'] : 0;
        } catch (Exception $e) {
            return 0;
        }
    }
    public function ContarUsuariosDep() {
        try {
            $query = "SELECT COUNT(*) AS total FROM usuario WHERE role_id = :role_id";
            $stmt = $this->db->prepare($query);
            $stmt->bindValue(':role_id', 3, PDO::PARAM_INT); 
            $stmt->execute();
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
            return $resultado ? $resultado['total'] : 0;
        } catch (Exception $e) {
            return 0;
        }
    }
    public function ContarUsuariosBie() {
        try {
            $query = "SELECT COUNT(*) AS total FROM usuario WHERE role_id = :role_id";
            $stmt = $this->db->prepare($query);
            $stmt->bindValue(':role_id', 4, PDO::PARAM_INT); 
            $stmt->execute();
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
            return $resultado ? $resultado['total'] : 0;
        } catch (Exception $e) {
            return 0;
        }
    }
    
    public function contarEntradasLab($dependencia) {
        try {
            $query = "SELECT COUNT(*) AS total FROM entradas WHERE dependencia = :dependencia";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(":dependencia", $dependencia, PDO::PARAM_STR);
            $stmt->execute();
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
            return $resultado ? $resultado['total'] : 0;
        } catch (Exception $e) {
            return 0;
        }
    }
    public function contarEntradasBie($dependencia) {
        try {
            $query = "SELECT COUNT(*) AS total FROM entradas WHERE dependencia = :dependencia";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(":dependencia", $dependencia, PDO::PARAM_STR);
            $stmt->execute();
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
            return $resultado ? $resultado['total'] : 0;
        } catch (Exception $e) {
            return 0;
        }
    }
    public function contarEntradasDep($dependencia) {
        try {
            $query = "SELECT COUNT(*) AS total FROM entradas WHERE dependencia = :dependencia";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(":dependencia", $dependencia, PDO::PARAM_STR);
            $stmt->execute();
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
            return $resultado ? $resultado['total'] : 0;
        } catch (Exception $e) {
            return 0;
        }
    }
    public function contarEntradasHos($dependencia) {
        try {
            $query = "SELECT COUNT(*) AS total FROM entradas WHERE dependencia = :dependencia";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(":dependencia", $dependencia, PDO::PARAM_STR);
            $stmt->execute();
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
            return $resultado ? $resultado['total'] : 0;
        } catch (Exception $e) {
            return 0;
        }
    }
    public function contarInsumosLab() {
        try {
            $query = "SELECT 
           (SELECT COUNT(*) FROM inventario_laboratorio)  AS total"; 
            $stmt = $this->db->prepare($query);
            $stmt->execute();
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
            return $resultado['total'] ?? 0;
        } catch (Exception $e) {
            return 0;
        }
    }
    public function contarInsumosHos() {
        try {
            $query = "SELECT 
           (SELECT COUNT(*) FROM inventario_hospedaje)  AS total"; 
            $stmt = $this->db->prepare($query);
            $stmt->execute();
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
            return $resultado['total'] ?? 0;
        } catch (Exception $e) {
            return 0;
        }
    }
    public function contarInsumosBie() {
        try {
            $query = "SELECT 
           (SELECT COUNT(*) FROM inventario_bienestar)  AS total"; 
            $stmt = $this->db->prepare($query);
            $stmt->execute();
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
            return $resultado['total'] ?? 0;
        } catch (Exception $e) {
            return 0;
        }
    }
    public function contarInsumosDep() {
        try {
            $query = "SELECT 
           (SELECT COUNT(*) FROM inventario_deportes)  AS total"; 
            $stmt = $this->db->prepare($query);
            $stmt->execute();
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
            return $resultado['total'] ?? 0;
        } catch (Exception $e) {
            return 0;
        }
    }
    public function contarSalidasLab($dependencia) {
        try {
            $query = "SELECT COUNT(*) AS total FROM salidas WHERE dependencia = :dependencia";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(":dependencia", $dependencia, PDO::PARAM_STR);
            $stmt->execute();
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
            return $resultado ? $resultado['total'] : 0;
        } catch (Exception $e) {
            return 0;
        }
    }
    public function contarSalidasHos($dependencia) {
        try {
            $query = "SELECT COUNT(*) AS total FROM salidas WHERE dependencia = :dependencia";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(":dependencia", $dependencia, PDO::PARAM_STR);
            $stmt->execute();
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
            return $resultado ? $resultado['total'] : 0;
        } catch (Exception $e) {
            return 0;
        }
    }
    public function contarSalidasBie($dependencia) {
        try {
            $query = "SELECT COUNT(*) AS total FROM salidas WHERE dependencia = :dependencia";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(":dependencia", $dependencia, PDO::PARAM_STR);
            $stmt->execute();
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
            return $resultado ? $resultado['total'] : 0;
        } catch (Exception $e) {
            return 0;
        }
    }
    public function contarSalidasDep($dependencia) {
        try {
            $query = "SELECT COUNT(*) AS total FROM salidas WHERE dependencia = :dependencia";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(":dependencia", $dependencia, PDO::PARAM_STR);
            $stmt->execute();
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
            return $resultado ? $resultado['total'] : 0;
        } catch (Exception $e) {
            return 0;
        }
    }
    
    public function contarSalidas() {
        try {
            $query = "SELECT COUNT(*) AS total FROM salidas"; 
            $stmt = $this->db->prepare($query);
            $stmt->execute();
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
            return $resultado['total'] ?? 0;
        } catch (Exception $e) {
            return 0;
        }
    }
    public function contarTotalInsumos() {
        try {
            $query = "SELECT 
                        (SELECT COUNT(*) FROM inventario_laboratorio) +
                        (SELECT COUNT(*) FROM inventario_deportes) AS total"; 
    
            $stmt = $this->db->prepare($query);
            $stmt->execute();
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
            return $resultado['total'] ?? 0;
        } catch (Exception $e) {
            return 0;
        }
    }

    


    public function getEntradas() {
        try {
            $query = "SELECT id, dependencia, responsable, fecha, unidad_medida, 
                             cantidad_anterior, cantidad_ingresada, 
                             (cantidad_anterior + cantidad_ingresada) AS cantidad_total,
                             insumo
                      FROM entradas
                      ORDER BY fecha DESC";
    
            $stmt = $this->db->prepare($query);
            $stmt->execute();
    
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            return [];
        }
    }
    
   
    

    private function convertirUnidades($cantidad, $unidad_origen, $unidad_destino) {
        $sin_conversion = ['unidad', 'unidades'];

    if ($unidad_origen === $unidad_destino || 
        (in_array($unidad_origen, $sin_conversion) && in_array($unidad_destino, $sin_conversion))) {
        return $cantidad;
    }
        $conversiones = [
            "gramos" => ["kilogramos" => 0.001, "miligramos" => 1000, "libras" => 0.00220462],
            "kilogramos" => ["gramos" => 1000, "miligramos" => 1000000, "libras" => 2.20462],
            "miligramos" => ["gramos" => 0.001, "kilogramos" => 0.000001, "libras" => 0.00000220462],
            "libras" => ["gramos" => 453.592, "kilogramos" => 0.453592, "miligramos" => 453592],
            "mililitros" => ["litros" => 0.001],
            "litros" => ["mililitros" => 1000]
        ];

        if ($unidad_origen === $unidad_destino) {
            return $cantidad;
        }

        if (isset($conversiones[$unidad_origen][$unidad_destino])) {
            return $cantidad * $conversiones[$unidad_origen][$unidad_destino];
        }

        throw new Exception("No se puede convertir entre estas unidades: $unidad_origen y $unidad_destino.");
    }
}
?>

