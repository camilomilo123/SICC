<?php
require_once __DIR__ . '/conexion_bd.php'; // Incluir la clase de conexión

class UsuarioModel {
    private $pdo;

    public function __construct() {
        // Crear una instancia de la conexión y obtener el PDO
        $conexion = new Database();
        $this->pdo = $conexion->getConnection();
    }

    public function obtenerUsuarios() {
        $sql = "SELECT u.id_usuario, u.nombre, u.telefono, u.correo, r.nombre as rol
                FROM usuario u
                INNER JOIN roles r ON u.role_id = r.id"; // Corrección aquí
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}


