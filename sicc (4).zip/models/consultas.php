<?php

class Consultas {
    public function InsertarReactivos($reactivo,$formula,$estado,$fecha_de_vencimiento,$lote,$unidad_medida,$ubicacion,$codigo_almacenamiento,$cantidad){
        $modelo =new Database();
        $conexion= $modelo->getConnection();
        $sql="INSERT INTO inventario_laboratorio(reactivo,formula,estado,fecha_de_vencimiento,lote,unidad_medida,ubicacion,codigo_almacenamiento,cantidad) values(:reactivo,:formula,estado,:fecha_de_vencimiento,:lote,:unidad_medida,:ubicacion,:codigo_almacenamiento,:cantidad)";
        $statement= $conexion->prepare($sql);
        $statement->bindParam(':reactivo',$reactivo);
        $statement->bindParam(':formula',$formula);
        $statement->bindParam(':estado',$estado);
        $statement->bindParam(':fecha_de_vencimiento',$fecha_de_vencimiento);
        $statement->bindParam(':lote',$lote);
        $statement->bindParam(':unidad_medida',$unidad_medida);
        $statement->bindParam(':ubicacion',$ubicacion);
        $statement->bindParam(':codigo_almacenamiento',$codigo_almacenamiento);
        $statement->bindParam(':cantidad',$cantidad);

        if(!$statement){
            return"error al crear registro";

        }else{
            $statement->execute();
            return"Registro creado";
        }
    
    
    
    
    }
    public function CargarReactivos(){
        $rows=null;
        $modelo =new Database();
        $conexion= $modelo->getConnection();
        $sql="SELECT * FROM inventario_laboratorio";
        $statement= $conexion->prepare($sql);
        $statement->execute();
        while($result=$statement->fetch()){
            $rows[]=$result;

        }
        return $rows;
    



    }
    



}