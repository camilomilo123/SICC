<?php
require_once '../vendor/autoload.php';
require_once "conexion_bd.php";

use PhpOffice\PhpSpreadsheet\IOFactory;

var_dump(class_exists('PhpOffice\PhpSpreadsheet\IOFactory'));

class cargarinventarioModel {
    private $conn;

    public function __construct() {
        // Instanciamos la clase Database y obtenemos la conexión
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function cargarInventario($archivo) {
        try {
            // Cargamos el archivo Excel
            $documento = IOFactory::load($archivo['tmp_name']);
            $hoja = $documento->getActiveSheet();
            $filas = $hoja->toArray();

            // Preparamos la consulta para insertar datos
            $stmt = $this->conn->prepare("INSERT INTO inventario_laboratorio (reactivo, formula, estado, fecha_vencimiento, lote, ubicacion, codigo_almacenamiento, cantidad, unidad_medida) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");

            // Omitimos la primera fila (encabezado)
            foreach ($filas as $index => $fila) {
                if ($index == 0) continue;  // Salta la primera fila (encabezado)

                // Comprobamos que haya suficientes columnas
                if (count($fila) < 9) continue;

                $reactivo = $fila[0];
                $formula = $fila[1];
                $estado = $fila[2];
                $fecha_vencimiento = $fila[3];
                $lote = $fila[4];
                $ubicacion = $fila[5];
                $codigo = $fila[6];
                $cantidad = $fila[7];
                $unidad = $fila[8];

                // Ejecutamos la consulta
                $stmt->execute([$reactivo, $formula, $estado, $fecha_vencimiento, $lote, $ubicacion, $codigo, $cantidad, $unidad]);
            }

            return true;
        } catch (Exception $e) {
            // Si ocurre un error, mostramos el mensaje
            return false;
        }
    }
}

