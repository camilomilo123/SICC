<?php
require_once 'conexion_bd.php';

class Prestamodel {
    private $db;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    public function registrarSalida($producto, $cantidad_prestada, $unidad_medida, $fecha, $prestado, $responsable, $tipo) {
        try {
            $this->db->beginTransaction();

            // Definir las tablas y columnas según el tipo de inventario
            $tipos_inventario = [
                "Laboratorio" => ["tabla" => "inventario_laboratorio", "columna" => "reactivo"],
                "Deportes"    => ["tabla" => "inventario_deportes", "columna" => "elemento"],
                "Hospedaje"   => ["tabla" => "inventario_hospedaje", "columna" => "insumo"],
                "Bienestar"   => ["tabla" => "inventario_bienestar", "columna" => "elemento"]
            ];

            // Verificar que el tipo de inventario es válido
            if (!isset($tipos_inventario[$tipo])) {
                throw new Exception("Tipo de inventario no válido.");
            }

            $tabla = $tipos_inventario[$tipo]['tabla'];
            $columna = $tipos_inventario[$tipo]['columna'];

            // Determinar si el producto es un ID numérico o un nombre
            $es_id = is_numeric($producto);
            $query = $es_id
                ? "SELECT id, cantidad, $columna AS nombre, unidad_medida FROM $tabla WHERE id = :producto FOR UPDATE"
                : "SELECT id, cantidad, $columna AS nombre, unidad_medida FROM $tabla WHERE $columna = :producto FOR UPDATE";

            // Consultar el inventario para obtener detalles del producto
            $stmt = $this->db->prepare($query);
            $stmt->bindValue(":producto", $producto, $es_id ? PDO::PARAM_INT : PDO::PARAM_STR);
            $stmt->execute();
            $item = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$item) {
                throw new Exception("El producto '$producto' no se encontró en el inventario de $tipo.");
            }

            // Datos del producto consultado
            $id_producto = $item['id'];
            $nombre = $item['nombre'];
            $cantidad_actual = (float)$item['cantidad'];
            $unidad_bd = $item['unidad_medida'];

            // Convertir la unidad de medida
            try {
                $cantidad_convertida = $this->convertirUnidad($cantidad_prestada, $unidad_medida, $unidad_bd);
            } catch (Exception $e) {
                return ["status" => "error", "message" => "No se puede convertir de '$unidad_medida' a '$unidad_bd'."];
            }

            // Verificar si hay suficiente stock
            if ($cantidad_actual < $cantidad_convertida) {
                return ["status" => "error", "message" => "Stock insuficiente: necesitas $cantidad_convertida $unidad_bd pero solo hay $cantidad_actual $unidad_bd."];
            }

            // Actualizar el inventario con la nueva cantidad
            $nueva_cantidad = round($cantidad_actual - $cantidad_convertida, 2);
            if ($nueva_cantidad < 0) {
                return ["status" => "error", "message" => "No puedes prestar más cantidad de la disponible."];
            }

            // Actualizar la cantidad en el inventario
            $update = "UPDATE $tabla SET cantidad = :nueva_cantidad WHERE id = :id";
            $stmtUpdate = $this->db->prepare($update);
            $stmtUpdate->bindParam(":nueva_cantidad", $nueva_cantidad);
            $stmtUpdate->bindParam(":id", $id_producto, PDO::PARAM_INT);
            $stmtUpdate->execute();

            // Registrar el préstamo en la tabla "prestamos"
            $sql = "INSERT INTO prestamos (insumo, cantidad_prestada, unidad_medida, fecha, prestado_a, responsable, dependencia)
                    VALUES (:insumo, :cantidad_prestada, :unidad_medida, :fecha, :prestado_a, :responsable, :dependencia)";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':insumo', $nombre);
            $stmt->bindParam(':cantidad_prestada', $cantidad_prestada);
            $stmt->bindParam(':unidad_medida', $unidad_bd);
            $stmt->bindParam(':fecha', $fecha);
            $stmt->bindParam(':prestado_a', $prestado);
            $stmt->bindParam(':responsable', $responsable);
            $stmt->bindParam(':dependencia', $tipo);
            $stmt->execute();

            // Confirmar la transacción
            $this->db->commit();
            return ["status" => "success", "message" => "Préstamo registrado exitosamente."];

        } catch (Exception $e) {
            // En caso de error, revertir la transacción
            $this->db->rollBack();
            return ["status" => "error", "message" => "Error al registrar el préstamo: " . $e->getMessage()];
        }
    }

    public function getPrestado() {
        try {
            $query = "SELECT id, dependencia, responsable, prestado_a, fecha, unidad_medida, cantidad_prestada, insumo FROM prestamos ORDER BY fecha DESC";
            $stmt = $this->db->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            return [];
        }
    }

    public function marcarRegresado($id_prestamo) {
        try {
            // Iniciar la transacción para asegurar que todo ocurra de manera atómica
            $this->db->beginTransaction();
    
            // Obtener el registro del préstamo
            $query = "SELECT insumo, cantidad_prestada, unidad_medida, dependencia FROM prestamos WHERE id = :id_prestamo";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(":id_prestamo", $id_prestamo, PDO::PARAM_INT);
            $stmt->execute();
            $prestamo = $stmt->fetch(PDO::FETCH_ASSOC);
    
            if (!$prestamo) {
                return ["status" => "error", "message" => "Préstamo no encontrado."];
            }
    
            // Datos del préstamo
            $producto = $prestamo['insumo'];
            $cantidad_prestada = $prestamo['cantidad_prestada'];
            $unidad_medida = $prestamo['unidad_medida'];
            $tipo_inventario = $prestamo['dependencia'];
    
            // Definir las tablas y columnas según el tipo de inventario
            $tipos_inventario = [
                "Laboratorio" => ["tabla" => "inventario_laboratorio", "columna" => "reactivo"],
                "Deportes"    => ["tabla" => "inventario_deportes", "columna" => "elemento"],
                "Hospedaje"   => ["tabla" => "inventario_hospedaje", "columna" => "insumo"],
                "Bienestar"   => ["tabla" => "inventario_bienestar", "columna" => "elemento"]
            ];
    
            if (!isset($tipos_inventario[$tipo_inventario])) {
                throw new Exception("Tipo de inventario no válido.");
            }
    
            // Recuperar la tabla y columna del inventario
            $tabla = $tipos_inventario[$tipo_inventario]['tabla'];
            $columna = $tipos_inventario[$tipo_inventario]['columna'];
    
            // Consultar la cantidad actual del producto en el inventario
            $queryInventario = "SELECT id, cantidad, unidad_medida FROM $tabla WHERE $columna = :producto FOR UPDATE";
            $stmtInventario = $this->db->prepare($queryInventario);
            $stmtInventario->bindParam(":producto", $producto, PDO::PARAM_STR);
            $stmtInventario->execute();
            $item = $stmtInventario->fetch(PDO::FETCH_ASSOC);
    
            if (!$item) {
                throw new Exception("Producto no encontrado en el inventario.");
            }
    
            // Restaurar la cantidad en el inventario
            $cantidad_actual = (float)$item['cantidad'];
            $nueva_cantidad = round($cantidad_actual + $cantidad_prestada, precision: 2);
    
            // Actualizar la cantidad en el inventario
            $update = "UPDATE $tabla SET cantidad = :nueva_cantidad WHERE id = :id";
            $stmtUpdate = $this->db->prepare($update);
            $stmtUpdate->bindParam(":nueva_cantidad", $nueva_cantidad);
            $stmtUpdate->bindParam(":id", $item['id'], PDO::PARAM_INT);
            $stmtUpdate->execute();
    
            // Eliminar el registro del préstamo
            $delete = "DELETE FROM prestamos WHERE id = :id_prestamo";
            $stmtDelete = $this->db->prepare($delete);
            $stmtDelete->bindParam(":id_prestamo", $id_prestamo, PDO::PARAM_INT);
            $stmtDelete->execute();
    
            // Confirmar la transacción
            $this->db->commit();
            return ["status" => "success", "message" => "Producto marcado como regresado y stock restaurado."];
    
        } catch (Exception $e) {
            // Si ocurre algún error, revertir la transacción
            $this->db->rollBack();
            return ["status" => "error", "message" => $e->getMessage()];
        }
    }

    private function convertirUnidad($cantidad, $unidad_origen, $unidad_destino) {
        // Definir las conversiones de unidades
        $conversiones = [
            "gramos" => ["kilogramos" => 0.001, "miligramos" => 1000, "libras" => 0.00220462],
            "kilogramos" => ["gramos" => 1000, "miligramos" => 1000000, "libras" => 2.20462],
            "miligramos" => ["gramos" => 0.001, "kilogramos" => 0.000001, "libras" => 0.00000220462],
            "libras" => ["gramos" => 453.592, "kilogramos" => 0.453592, "miligramos" => 453592],
            "mililitros" => ["litros" => 0.001],
            "litros" => ["mililitros" => 1000]
        ];

        // Si la unidad de origen y destino son iguales, no hace falta convertir
        if ($unidad_origen === $unidad_destino) {
            return $cantidad;
        }

        // Realizar la conversión si está definida
        if (isset($conversiones[$unidad_origen][$unidad_destino])) {
            return $cantidad * $conversiones[$unidad_origen][$unidad_destino];
        }

        // Si no se puede convertir, lanzar un error
        throw new Exception("No se puede convertir entre '$unidad_origen' y '$unidad_destino'.");
    }
}
?>
