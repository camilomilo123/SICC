<!DOCTYPE html> <!-- Define que el documento usa HTML5 -->
<html lang="es"> <!-- Idioma del contenido: Español -->
<head>
  <meta charset="UTF-8"> <!-- Codificación de caracteres (UTF-8) -->
  <title>403 - Acceso Denegado</title> <!-- Título que se muestra en la pestaña del navegador -->

  <!-- Hoja de estilos de Bootstrap desde CDN para diseño responsivo -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Estilos personalizados para la página de error 403 -->
  <link rel="stylesheet" href="/views/css/403.css">

  <style>
    /* Espacio reservado para estilos en línea adicionales (actualmente vacío) */
  </style>
</head>

<body>
  <!-- Contenedor centrado con margen superior -->
  <div class="text-center mt-5">

    <!-- Imagen que representa el error (candado) -->
    <div class="error-image">
      <img src="/views/icons/lock-fill.svg" alt="Candado de Acceso Denegado">
    </div>

    <!-- Código de error HTTP -->
    <div class="error-code">403</div>

    <!-- Mensaje principal del error -->
    <div class="error-message">Acceso Denegado</div>

    <!-- Descripción adicional -->
    <p>No tienes permisos para acceder a esta sección.</p>

    <!-- Botón para volver a la página anterior -->
    <a href="javascript:history.back()" class="btn-back">Volver</a>
  </div>
</body>
</html>


