<?php
// Incluir el archivo que contiene la clase de conexión a la base de datos
require_once "../models/conexion_bd.php";

// Establecer que el contenido que se va a enviar será en formato JSON con codificación UTF-8
header("Content-Type: application/json; charset=UTF-8");

// Crear una instancia de la clase Database para obtener la conexión a la base de datos
$conexiondb = new Database();
$pdo = $conexiondb->getConnection();

// Verificar si el tipo de solicitud HTTP es POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Recoger los datos enviados por el formulario mediante el método POST
    $id_usuario = $_POST['id_usuario'];   // ID del usuario a actualizar
    $nombre = $_POST['nombre'];           // Nuevo nombre del usuario
    $telefono = $_POST['telefono'];       // Nuevo número de teléfono del usuario
    $correo = $_POST['correo'];           // Nuevo correo electrónico del usuario
    $rol = $_POST['rol'];                 // Nuevo rol del usuario

    try {
        // Consulta SQL para actualizar los datos del usuario en la base de datos
        $query = "UPDATE usuario SET nombre = :nombre, telefono = :telefono, correo = :correo, role_id = :rol WHERE id_usuario = :id_usuario";
        
        // Preparar la consulta SQL
        $stmt = $pdo->prepare($query);
        
        // Vincular los parámetros de la consulta a los valores de las variables
        $stmt->bindParam(":id_usuario", $id_usuario, PDO::PARAM_INT);   // ID del usuario (entero)
        $stmt->bindParam(":nombre", $nombre, PDO::PARAM_STR);            // Nombre (cadena de texto)
        $stmt->bindParam(":telefono", $telefono, PDO::PARAM_STR);        // Teléfono (cadena de texto)
        $stmt->bindParam(":correo", $correo, PDO::PARAM_STR);            // Correo (cadena de texto)
        $stmt->bindParam(":rol", $rol, PDO::PARAM_INT);                  // Rol (entero)

        // Ejecutar la consulta
        if ($stmt->execute()) {
            // Si la ejecución es exitosa, devolver una respuesta JSON con el estado y un mensaje
            echo json_encode(["status" => "success", "message" => "Usuario actualizado correctamente"]);
        } else {
            // Si hubo un error al ejecutar la consulta, devolver una respuesta JSON con el estado de error y mensaje
            echo json_encode(["status" => "error", "message" => "Error al actualizar el usuario"]);
        }
    } catch (PDOException $e) {
        // Si ocurre una excepción durante la ejecución, devolver una respuesta JSON con el estado de error y el mensaje de la excepción
        echo json_encode(["status" => "error", "message" => $e->getMessage()]);
    }
}
?>

