<?php
// Requiere el archivo de conexión a la base de datos
require_once '../models/conexion_bd.php';

// Verifica si la solicitud es de tipo POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtiene el 'id' y 'solucionado' desde los datos POST, asignando un valor predeterminado si no se reciben
    $id = $_POST['id'] ?? 0;
    $solucionado = $_POST['solucionado'] ?? 0;

    // Crea una nueva instancia de la clase Database y obtiene la conexión a la base de datos
    $db = (new Database())->getConnection();

    // Prepara una consulta SQL para actualizar el campo 'solucionado' de la tabla 'reportes_errores'
    $stmt = $db->prepare("UPDATE reportes_errores SET solucionado = :solucionado WHERE id = :id");

    // Vincula los parámetros de la consulta SQL con las variables PHP
    $stmt->bindParam(':solucionado', $solucionado, PDO::PARAM_INT);  // Vincula el valor de 'solucionado' como un entero
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);  // Vincula el valor de 'id' como un entero

    // Ejecuta la consulta SQL y verifica si la ejecución fue exitosa
    if ($stmt->execute()) {
        // Si la consulta fue exitosa, retorna una respuesta en formato JSON con 'status' => 'success'
        echo json_encode(['status' => 'success']);
    } else {
        // Si hubo un error, retorna una respuesta en formato JSON con 'status' => 'error'
        echo json_encode(['status' => 'error']);
    }
}

