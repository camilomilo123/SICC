<?php 
require_once '../models/InventarioModel.php';
require_once '../models/conexion_bd.php';

class InventarioController {
    private $model;

    public function __construct() {
        $database = new Database();
        $db = $database->getConnection();
        $this->model = new InventarioModel($db);
    }

    public function listar($tipo, $busqueda = '') {
        $busqueda = isset($_GET['buscar']) ? trim(htmlspecialchars($_GET['buscar'])) : '';

        switch ($tipo) {
            case 'insumo':
                $datos = $this->model->obtenerInventariolab($busqueda);
                break;
            case 'elemento':
                $datos = $this->model->obtenerInventariodep($busqueda);
                break;
            case 'suministro':
                $datos = $this->model->obtenerInventariohospe($busqueda);
                break;
            case 'dotacion':
                $datos = $this->model->obtenerInventarionbienes($busqueda);
                break;
            default:
                $datos = [];
                break;
        }

        header('Content-Type: application/json');
        echo json_encode($datos);
    }

    // Método para obtener la unidad de medida por id
    public function obtenerUnidadMedida($id) {
        // Llamamos al modelo para obtener la unidad de medida
        $unidad_medida = $this->model->obtenerUnidadMedida($id);
        
        header('Content-Type: application/json');
        echo json_encode(['unidad_medida' => $unidad_medida]);
    }
}

// Verificar la acción que se ha solicitado
if (isset($_GET['action']) && $_GET['action'] === 'listar' && isset($_GET['tipo'])) {
    $controller = new InventarioController();
    $controller->listar($_GET['tipo']);
}

// Agregar una nueva acción para obtener la unidad de medida
if (isset($_GET['action']) && $_GET['action'] === 'obtenerUnidadMedida' && isset($_GET['id'])) {
    $controller = new InventarioController();
    $controller->obtenerUnidadMedida($_GET['id']);
}
?>

