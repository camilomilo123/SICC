<?php
// Incluir el archivo que maneja la conexión a la base de datos
require_once '../models/conexion_bd.php';

try {
    // Crear una instancia de la clase Database, que se encargará de la conexión a la base de datos
    $database = new Database();
    
    // Obtener la conexión de la base de datos
    $db = $database->getConnection();

    // Definir la consulta SQL para obtener los datos de los reactivos y su cantidad del inventario
    $query = "SELECT reactivo, cantidad FROM inventario_laboratorio";

    // Preparar la consulta SQL para evitar posibles inyecciones SQL
    $stmt = $db->prepare($query);

    // Ejecutar la consulta preparada
    $stmt->execute();

    // Obtener todos los resultados como un arreglo asociativo
    $resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Convertir los resultados en formato JSON y enviarlos como respuesta
    echo json_encode($resultados);
} catch (Exception $e) {
    // Si ocurre algún error en el proceso, se captura y se envía un mensaje de error en formato JSON
    echo json_encode(["error" => "Error al obtener los datos: " . $e->getMessage()]);
}
?>

