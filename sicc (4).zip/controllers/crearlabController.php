<?php
// Incluye el archivo del modelo que contiene la lógica para interactuar con la base de datos
require_once '../models/crearModel.php';

// Definición de la clase controladora CrearLabController
class CrearLabController {
    // Atributo privado que almacenará la instancia del modelo
    private $model;

    // Constructor de la clase, se ejecuta al crear una instancia del controlador
    public function __construct() {
        // Crea una instancia del modelo CrearModel y la asigna al atributo $model
        $this->model = new CrearModel();
    }

    // Método público que maneja la lógica para guardar un reactivo en el laboratorio
    public function guardarReactivo() {
        // Verifica si la solicitud HTTP es de tipo POST (lo cual indica que proviene de un formulario)
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Recoge los datos enviados por el formulario y los organiza en un array asociativo
            $datos = [
                'reactivo' => $_POST['reactivo'],  // Nombre del reactivo recibido desde el formulario
                'formula' => $_POST['formula'] ?? null,  // Fórmula del reactivo (si no está, se pone como null)
                'estado' => $_POST['estado'],  // Estado del reactivo (activo, inactivo, etc.)
                'fecha_vencimiento' => $_POST['fecha_vencimiento'] ?? null,  // Fecha de vencimiento (si no está, se pone como null)
                'lote' => $_POST['lote'] ?? null,  // Lote del reactivo (si no está, se pone como null)
                'unidad_medida' => $_POST['unidad_medida'] ?? null,  // Unidad de medida (si no está, se pone como null)
                'ubicacion' => $_POST['ubicacion'] ?? null,  // Ubicación del reactivo (si no está, se pone como null)
                'codigo' => $_POST['codigo'] ?? null,  // Código del reactivo (si no está, se pone como null)
                'cantidad' => $_POST['cantidad']  // Cantidad del reactivo
            ];

            // Llama al método agregarReactivo del modelo, pasando los datos recopilados
            if ($this->model->agregarReactivo($datos)) {
                // Si el método retorna true, redirige al usuario con un mensaje de éxito
                header("Location: ../views/admin/crearlab.php?success=1");
            } else {
                // Si el método falla, redirige al usuario con un mensaje de error
                header("Location: ../views/admin/crearlab.php?error=1");
            }
            // Finaliza la ejecución del script para evitar continuar ejecutando más código
            exit();
        }
    }
}

// Crea una instancia del controlador
$controller = new CrearLabController();
// Llama al método para guardar el reactivo
$controller->guardarReactivo();
?>

