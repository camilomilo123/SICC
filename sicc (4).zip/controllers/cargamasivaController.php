<?php
// Requiere los archivos necesarios para el manejo de la carga masiva y la librería de autoload
require_once '../models/cargamasivaModel.php';
require_once '../vendor/autoload.php';

// Configura la visualización de errores para la depuración
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Define las vistas permitidas a las que se puede acceder para cargar el inventario
$vistasPermitidas = ['Inv_dep', 'Inv_hos', 'Inv_bien'];

// Obtiene el origen de la carga, que es el nombre de la vista
$origen = isset($_POST['origen']) ? $_POST['origen'] : null;

// Verifica si el origen es válido (está en la lista de vistas permitidas)
if (!$origen || !in_array($origen, $vistasPermitidas)) {
    // Si el origen no es válido, redirige a la vista correspondiente con un mensaje de error
    header('Location: ../views/admin/Inv_dep.php?mensaje=vistainvalida');
    exit; // Detiene la ejecución del script
}

// Verifica si se ha enviado un archivo Excel y si no hubo errores al subirlo
if (isset($_FILES['excel_file']) && $_FILES['excel_file']['error'] === 0) {
    // Crea una instancia del modelo encargado de manejar la carga masiva
    $modelo = new cargamasivaModel();

    // Llama al método para cargar el inventario desde el archivo Excel
    $resultado = $modelo->cargarInventario($_FILES['excel_file'], $origen);

    // Verifica si la carga fue exitosa
    if ($resultado) {
        // Si la carga fue exitosa, redirige a la vista correspondiente con un mensaje de éxito
        header("Location: ../views/admin/{$origen}.php?mensaje=exito");
        exit; // Detiene la ejecución
    } else {
        // Si hubo un error en la carga, redirige a la vista correspondiente con un mensaje de error
        header("Location: ../views/admin/{$origen}.php?mensaje=error");
        exit; // Detiene la ejecución
    }
} else {
    // Si no se ha enviado un archivo o hubo un error en la carga, redirige con un mensaje indicando que no se seleccionó archivo
    header("Location: ../views/admin/{$origen}.php?mensaje=sinarchivo");
    exit; // Detiene la ejecución
}

