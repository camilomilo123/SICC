<?php
require_once "../models/conexion_bd.php";
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *"); // Evitar problemas de CORS
header("Access-Control-Allow-Methods: POST, GET");

// Conexión a la base de datos
$conexiondb = new Database();
$pdo = $conexiondb->getConnection();

try {
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $action = $_POST["action"] ?? "";

        if ($action === "eliminar" && isset($_POST["id"])) {
            // Eliminar un registro específico
            $id = $_POST["id"];

            $query = "DELETE FROM inventario_hospedaje WHERE id = :id";
            $stmt = $pdo->prepare($query);
            $stmt->bindParam(":id", $id, PDO::PARAM_INT);

            if ($stmt->execute()) {
                echo json_encode(["status" => "success", "message" => "Registro eliminado correctamente"]);
            } else {
                echo json_encode(["status" => "error", "message" => "Error al eliminar el registro"]);
            }
            exit;
        }
    }

    // Obtener los datos (siempre)
    $sql = "SELECT id, insumo, cantidad, unidad_medida, ubicacion FROM inventario_hospedaje";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $inventario = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(["data" => $inventario], JSON_UNESCAPED_UNICODE);
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
exit;