<?php
require_once '../models/cargarinventarioModel.php';
require_once '../vendor/autoload.php';
// Activa errores para depuración (puedes quitar esto en producción)
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Verifica que se haya subido un archivo correctamente
if (isset($_FILES['excel_file']) && $_FILES['excel_file']['error'] == 0) {
    $modelo = new cargarinventarioModel();
    $resultado = $modelo->cargarInventario($_FILES['excel_file']);

    if ($resultado) {
        // Redirige a la vista con mensaje de éxito
        header('Location: ../views/admin/Inv_lab.php?mensaje=exito');
        exit;
    } else {
        // Redirige con mensaje de error
        header('Location: ../views/admin/Inv_lab.php?mensaje=error');
        exit;
    }
} else {
    // Redirige si no se seleccionó ningún archivo
    header('Location: ../views/admin/Inv_lab.php?mensaje=sinarchivo');
    exit;
}
