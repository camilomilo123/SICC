<?php
session_start();
require_once '../models/SalidaModel.php';

class SalidaController {
    private $model;

    public function __construct() {
        $this->model = new SalidasModel();
    }
    

    public function registrarSalida($datos) {
       
        // Validación de sesión
        if (!isset($_SESSION['username']) || empty($_SESSION['username'])) {
            echo json_encode(["status" => "error", "message" => "Usuario no autenticado."]);
            return;
        }
       

        // Validación de datos obligatorios
        $dependencia = filter_input(INPUT_POST, 'dependencia', FILTER_SANITIZE_STRING);
        $unidad_medida = filter_input(INPUT_POST, 'unidad_medida', FILTER_SANITIZE_STRING);
        $cantidad_salida = filter_input(INPUT_POST, 'cantidad', FILTER_VALIDATE_FLOAT);
        $descripcion = filter_input(INPUT_POST, 'descripcion', FILTER_SANITIZE_STRING) ?? '';
        date_default_timezone_set('America/Bogota');
        $fecha = date("Y-m-d H:i:s");
        $responsable=$_SESSION['username'];
       

        if (!$dependencia || !$unidad_medida || !$cantidad_salida || $cantidad_salida <= 0) {
            echo json_encode(["status" => "error", "message" => "Todos los campos son obligatorios y deben ser válidos."]);
            return;
        }

        // Determinar el tipo de inventario y el ID del producto
        $id_producto = null;
        $tipo = null;

        if (isset($datos['insumo'])) {
            $tipo = "Laboratorio";
            $id_producto = filter_input(INPUT_POST, 'insumo', FILTER_VALIDATE_INT);
        } elseif (isset($datos['elemento'])) {
            $tipo = "Deportes";
            $id_producto = filter_input(INPUT_POST, 'elemento', FILTER_VALIDATE_INT);
        } elseif (isset($datos['suministro'])) {
            $tipo = "Hospedaje";
            $id_producto = filter_input(INPUT_POST, 'suministro', FILTER_VALIDATE_INT);
        } elseif (isset($datos['dotacion'])) {
            $tipo = "Bienestar";
            $id_producto = filter_input(INPUT_POST, 'dotacion', FILTER_VALIDATE_INT);
        }

        if (!$id_producto || !$tipo) {
            echo json_encode(["status" => "error", "message" => "Datos inválidos o producto no seleccionado."]);
            return;
        }

        // Registrar la salida en el modelo
        $resultado = $this->model->registrarSalida($dependencia, $id_producto, $cantidad_salida, $unidad_medida, $fecha, $descripcion, $responsable, $tipo);

        // Responder en formato JSON
        echo json_encode($resultado);
    }
}

// Manejo de la solicitud POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    header("Content-Type: application/json");
    $controller = new SalidaController();
    $controller->registrarSalida($_POST);
    exit;
}
?>