<?php
// Incluye el archivo del modelo que contiene la lógica para interactuar con la base de datos
require_once '../models/crearhosModel.php';

// Definición de la clase controladora CrearhosController
class CrearhosController {
    // Atributo privado que almacenará la instancia del modelo
    private $model;

    // Constructor de la clase, se ejecuta al crear una instancia del controlador
    public function __construct() {
        // Crea una instancia del modelo CrearhosModel y la asigna al atributo $model
        $this->model = new CrearhosModel();
    }

    // Método público que maneja la lógica para guardar un reactivo
    public function guardarReactivo() {
        // Verifica si la solicitud HTTP es de tipo POST (lo cual indica que proviene de un formulario)
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Recoge los datos enviados por el formulario y los organiza en un array asociativo
            $datos = [
                'insumo' => $_POST['insumo'],  // Nombre del insumo (reactivo) recibido desde el formulario
                'cantidad' => $_POST['cantidad'],  // Cantidad del insumo
                'unidad_medida' => $_POST['unidad_medida'] ?? null,  // Unidad de medida (si no está, se pone como null)
                'ubicacion' => $_POST['ubicacion'] ?? null,  // Ubicación (si no está, se pone como null)
            ];

            // Llama al método agregarReactivo del modelo, pasando los datos recopilados
            if ($this->model->agregarReactivo($datos)) {
                // Si el método retorna true, redirige al usuario con un mensaje de éxito
                header("Location: ../views/admin/crearhos.php?success=1");
            } else {
                // Si el método falla, redirige al usuario con un mensaje de error
                header("Location: ../views/admin/crearhos.php?error=1");
            }
            // Finaliza la ejecución del script para evitar continuar ejecutando más código
            exit();
        }
    }
}

// Crea una instancia del controlador
$controller = new CrearhosController();
// Llama al método para guardar el reactivo
$controller->guardarReactivo();
?>

