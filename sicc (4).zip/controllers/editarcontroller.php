<?php
// Incluir el archivo del modelo que contiene la lógica para editar datos
require_once '../models/editarmodel.php';

// Definición de la clase EditarController que manejará la lógica del controlador
class EditarController {
    private $model;

    // Constructor: crea una instancia del modelo EditarModel
    public function __construct() {
        $this->model = new EditarModel();
    }

    // Método principal para registrar cambios en un producto/insumo
    public function registrarcambio($datos) {
        // Verificar que se haya enviado la dependencia (campo obligatorio)
        if (empty($datos['dependencia'])) {
            return json_encode(["status" => "error", "message" => "La dependencia es obligatoria."]);
        }

        $dependencia = $datos['dependencia'];

        // Obtener el ID del elemento que se quiere editar, dependiendo del tipo (puede llamarse insumo, elemento, suministro o dotacion)
        $id = $datos['insumo'] ?? $datos['elemento'] ?? $datos['suministro'] ?? $datos['dotacion'] ?? null;

        // Verificar que se haya proporcionado un ID
        if (empty($id)) {
            return json_encode(["status" => "error", "message" => "ID del producto es obligatorio."]);
        }

        // Recolectar los demás datos opcionales enviados por el formulario
        $nombre = $datos['nombre'] ?? null;
        $formula = $datos['formula'] ?? null;
        $estado = $datos['estado'] ?? null;
        $fecha_vencimiento = $datos['fecha_vencimiento'] ?? null;
        $lote = $datos['lote'] ?? null;
        $ubicacion = $datos['ubicacion'] ?? null;
        $codigo = $datos['codigo'] ?? null;
        // Asegurarse de que cantidad sea numérico si se proporciona
        $cantidad = isset($datos['cantidad']) && $datos['cantidad'] !== '' ? (float) $datos['cantidad'] : null;
        $unidad_medida = $datos['unidad_medida'] ?? null;

        // Llamar al método del modelo para registrar el cambio con todos los datos recolectados
        $resultado = $this->model->registrarcambio(
            $id, $dependencia, $nombre, $formula, $estado,
            $fecha_vencimiento, $lote, $ubicacion, $codigo,
            $cantidad, $unidad_medida
        );

        // Devolver el resultado como una respuesta JSON
        return json_encode($resultado, JSON_UNESCAPED_UNICODE);
    }
}

// Manejo de la solicitud HTTP
// Verificar si se recibió una solicitud POST (por ejemplo, desde un formulario)
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Crear una instancia del controlador
    $controller = new EditarController();
    // Ejecutar el método para registrar el cambio pasando los datos POST y mostrar la respuesta
    echo $controller->registrarcambio($_POST);
}
?>

