<?php


require_once '../models/ErrorModel.php';

$model = new ReporteError();
$entradas = $model->Errores();

echo json_encode($entradas);
?>