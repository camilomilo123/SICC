<?php
require_once '../models/reporte.php';

class ReportesController {
    public function obtenerDatos() {
        $reporte = new Reporte();
        $datos = $reporte->obtenerDatos(); 
        echo json_encode($datos);
    }

    public function obtenerDatosGrafico_L() {
        $reporte = new Reporte();
        $datos = $reporte->obtenerDatosGrafico_Laboratorio(); 
        echo json_encode($datos);
    }
    public function obtenerDatosGrafico_D() {
        $reporte = new Reporte();
        $datos = $reporte->obtenerDatosGrafico_Deportes(); 
        echo json_encode($datos);
    }
    public function obtenerDatosGrafico_B() {
        $reporte = new Reporte();
        $datos = $reporte->obtenerDatosGrafico_Bienestar(); 
        echo json_encode($datos);
    }
    public function obtenerDatosGrafico_H() {
        $reporte = new Reporte();
        $datos = $reporte->obtenerDatosGrafico_Hospedaje(); 
        echo json_encode($datos);
    }
    

}


if (isset($_GET['action'])) {
    $controller = new ReportesController();

    if ($_GET['action'] === 'obtenerDatos') {
        $controller->obtenerDatos();
    } elseif ($_GET['action'] === 'obtenerDatosGrafico_L') {
        $controller->obtenerDatosGrafico_L();
    }elseif ($_GET['action'] === 'obtenerDatosGrafico_D') {
        $controller->obtenerDatosGrafico_D();
    }elseif ($_GET['action'] === 'obtenerDatosGrafico_B') {
        $controller->obtenerDatosGrafico_B();
    }elseif ($_GET['action'] === 'obtenerDatosGrafico_H') {
        $controller->obtenerDatosGrafico_H();
    }
    
}
?>

