<?php
// Iniciar la sesión
session_start();

// Incluir el modelo que maneja las operaciones con la base de datos
require_once '../models/EntradasModel.php';

// Definir la clase EntradasController
class EntradasController
{
    private $model;

    // Constructor para crear una instancia del modelo
    public function __construct()
    {
        $this->model = new EntradasModel();  // Crear el objeto del modelo
    }

    // Registrar una nueva entrada de inventario
    public function registrarEntrada($datos)
    {
        // Validar si el usuario está autenticado
        if (!isset($_SESSION['username']) || empty($_SESSION['username'])) {
            echo json_encode(["status" => "error", "message" => "Usuario no autenticado."]);
            return;
        }

        // Validar y sanitizar los datos recibidos a través del formulario
        $dependencia = filter_input(INPUT_POST, 'dependencia', FILTER_SANITIZE_STRING);
        $unidad_medida = strtolower(filter_input(INPUT_POST, 'unidad_medida', FILTER_SANITIZE_STRING));
        $cantidad_entrada = filter_input(INPUT_POST, 'cantidad', FILTER_VALIDATE_FLOAT);
        
        // Establecer la zona horaria y capturar la fecha actual
        date_default_timezone_set('America/Bogota');
        $fecha = date("Y-m-d H:i:s");
        $responsable = $_SESSION['username']; // Usuario responsable de la entrada

        // Validar si los datos requeridos están presentes y son válidos
        if (!$dependencia || !$unidad_medida || !$cantidad_entrada || $cantidad_entrada <= 0) {
            echo json_encode(["status" => "error", "message" => "Todos los campos son obligatorios y deben ser válidos."]);
            return;
        }

        // Determinar el tipo de producto y su nombre/ID según el formulario
        $producto = null;
        $tipo = null;

        // Validar el tipo de inventario y producto según el tipo de entrada
        if (!empty($datos['insumo'])) {
            $tipo = "Laboratorio";
            $producto = filter_var($datos['insumo'], FILTER_SANITIZE_STRING);
        } elseif (!empty($datos['elemento'])) {
            $tipo = "Deportes";
            $producto = filter_var($datos['elemento'], FILTER_SANITIZE_STRING);
        } elseif (!empty($datos['suministro'])) {
            $tipo = "Hospedaje";
            $producto = filter_var($datos['suministro'], FILTER_SANITIZE_STRING);
        } elseif (!empty($datos['dotacion'])) {
            $tipo = "Bienestar";
            $producto = filter_var($datos['dotacion'], FILTER_SANITIZE_STRING);
        }

        // Validar si el producto y el tipo han sido seleccionados correctamente
        if (!$producto || !$tipo) {
            echo json_encode(["status" => "error", "message" => "Datos inválidos o producto no seleccionado."]);
            return;
        }

        // Registrar la entrada en la base de datos llamando al método del modelo
        $resultado = $this->model->registrarEntrada($dependencia, $producto, $cantidad_entrada, $unidad_medida, $fecha, $responsable, $tipo);
        echo json_encode($resultado);  // Devolver el resultado como JSON
    }

    // Obtener el total de entradas registradas
    public function contarEntradas(): void
    {
        $totalEntradas = $this->model->contarEntradas();
        echo json_encode(["total" => $totalEntradas]);
    }

    // Obtener el total de insumos de laboratorio
    public function contarInsumosLaboratorio()
    {
        $total = $this->model->contarInsumosLab();
        echo json_encode(["total_insumos" => $total]);
    }

    // Obtener el total de insumos de deportes
    public function ObtenerInsumosDeportes()
    {
        $total = $this->model->contarInsumosDep();
        echo json_encode(["total_insumos" => $total]);
    }

    // Obtener el total de insumos de bienestar
    public function ObtenerInsumosBienestar()
    {
        $total = $this->model->contarInsumosBie();
        echo json_encode(["total_insumos" => $total]);
    }

    // Obtener el total de insumos de hospedaje
    public function ObtenerInsumosHos()
    {
        $total = $this->model->contarInsumosHos();
        echo json_encode(["total_insumos" => $total]);
    }

    // Obtener el total de salidas registradas
    public function contarSalidas(): void
    {
        $total = $this->model->contarSalidas();
        echo json_encode(["total" => $total]);
    }

    // Obtener el total de entradas de laboratorio
    public function contarEntradasLaboratorio(): void
    {
        $totalEntradas = $this->model->contarEntradasLab("Laboratorio");
        echo json_encode(["total" => $totalEntradas]);
    }

    // Obtener el total de entradas de deportes
    public function contarEntradasDeportes(): void
    {
        $totalEntradas = $this->model->contarEntradasDep("Deportes");
        echo json_encode(["total" => $totalEntradas]);
    }

    // Obtener el total de entradas de bienestar
    public function contarEntradasBienestar(): void
    {
        $totalEntradas = $this->model->contarEntradasBie("Bienestar");
        echo json_encode(["total" => $totalEntradas]);
    }

    // Obtener el total de entradas de hospedaje
    public function contarEntradasHospedaje(): void
    {
        $totalEntradas = $this->model->contarEntradasHos("Hospedaje");
        echo json_encode(["total" => $totalEntradas]);
    }

    // Obtener el total de salidas de laboratorio
    public function contarSalidasLaboratorio(): void
    {
        $totalEntradas = $this->model->contarSalidasLab("Laboratorio");
        echo json_encode(["total" => $totalEntradas]);
    }

    // Obtener el total de salidas de bienestar
    public function contarSalidasBienestar(): void
    {
        $totalEntradas = $this->model->contarSalidasBie("Bienestar");
        echo json_encode(["total" => $totalEntradas]);
    }

    // Obtener el total de salidas de deportes
    public function ObtenerSalidasDeportes(): void
    {
        $totalEntradas = $this->model->contarSalidasDep("Deportes");
        echo json_encode(["total" => $totalEntradas]);
    }

    // Obtener el total de salidas de hospedaje
    public function ObtenerSalidasHospedaje(): void
    {
        $totalEntradas = $this->model->contarSalidasHos("Hospedaje");
        echo json_encode(["total" => $totalEntradas]);
    }

    // Obtener el total de insumos registrados en general
    public function obtenerTotalInsumos()
    {
        $total = $this->model->contarTotalInsumos();
        echo json_encode(["total_insumos" => $total]);
    }

    // Obtener el total de usuarios registrados
    public function ObtenerUsuarios(): void
    {
        $totalUsuarios = $this->model->ContarUsuarios();
        echo json_encode(["total" => $totalUsuarios]);
    }

    // Obtener el total de usuarios de laboratorio
    public function ObtenerUsuariosLab(): void
    {
        $totalUsuarios = $this->model->ContarUsuariosLab();
        echo json_encode(["total" => $totalUsuarios]);
    }

    // Obtener el total de usuarios de hospedaje
    public function ObtenerUsuariosHos(): void
    {
        $totalUsuarios = $this->model->ContarUsuariosHos();
        echo json_encode(["total" => $totalUsuarios]);
    }

    // Obtener el total de usuarios de bienestar
    public function ObtenerUsuariosBie(): void
    {
        $totalUsuarios = $this->model->ContarUsuariosBie();
        echo json_encode(["total" => $totalUsuarios]);
    }

    // Obtener el total de usuarios de deportes
    public function ObtenerUsuariosDep(): void
    {
        $totalUsuarios = $this->model->ContarUsuariosDep();
        echo json_encode(["total" => $totalUsuarios]);
    }
}

// Crear una instancia del controlador EntradasController
$controller = new EntradasController();

// Lógica para manejar las solicitudes POST y GET
// Verificar si el método de la solicitud es POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Establecer el tipo de contenido a JSON
    header('Content-Type: application/json');
    
    // Llamar al método registrarEntrada del controlador con los datos del formulario ($_POST)
    echo $controller->registrarEntrada($_POST);
} 
// Verificar si el método de la solicitud es GET y si se ha proporcionado una acción en la URL
elseif ($_SERVER["REQUEST_METHOD"] === "GET" && isset($_GET['action'])) {
    // Establecer el tipo de contenido a JSON
    header('Content-Type: application/json');
    
    // Dependiendo del valor de 'action' en la URL, se ejecutará un caso específico
    switch ($_GET['action']) {
        case 'contarEntradas': // Contar el total de entradas
            $controller->contarEntradas();
            break;
        case 'contarSalidas': // Contar el total de salidas
            $controller->contarSalidas();
            break;
        case 'contarEntradasLaboratorio': // Contar las entradas de laboratorio
            $controller->contarEntradasLaboratorio();
            break;
        case 'contarEntradasDeportes': // Contar las entradas de deportes
            $controller->ObtenerEntradasDeportes();
            break;
        case 'contarEntradasBienestar': // Contar las entradas de bienestar
            $controller->contarEntradasBienestar();
            break;
        case 'contarEntradasHospedaje': // Contar las entradas de hospedaje
            $controller->contarEntradasHospedaje(); // Registrar Entrada (comentado con 'Registrar Entrada')
            break;
        case 'contarSalidasLaboratorio': // Contar las salidas de laboratorio
            $controller->contarSalidasLaboratorio();
            break;
        case 'contarSalidasBienestar': // Contar las salidas de bienestar
            $controller->contarSalidasBienestar();
            break;
        case 'contarSalidasHospedaje': // Contar las salidas de hospedaje
            $controller->ObtenerSalidasHospedaje(); // Registrar Entrada (comentado con 'Registrar Entrada')
            break;
        case 'ContarSalidasDeportes': // Contar las salidas de deportes
            $controller->ObtenerSalidasDeportes();
            break;
        case 'obtenerTotalInsumos': // Obtener el total de insumos
            $controller->obtenerTotalInsumos();
            break;
        case 'ObtenerUsuarios': // Obtener el total de usuarios
            $controller->ObtenerUsuarios();
            break;
        case 'contarInsumosLaboratorio': // Contar los insumos de laboratorio
            $controller->contarInsumosLaboratorio();
            break;
        case 'contarInsumosDeportes': // Contar los insumos de deportes
            $controller->ObtenerInsumosDeportes();
            break;
        case 'contarInsumosHospedaje': // Contar los insumos de hospedaje
            $controller->ObtenerInsumosHos(); // Registrar Entrada (comentado con 'Registrar Entrada')
            break;
        case 'contarInsumosBienestar': // Contar los insumos de bienestar
            $controller->ObtenerInsumosBienestar();
            break;
        case 'ObtenerUsuariosLab': // Obtener los usuarios de laboratorio
            $controller->ObtenerUsuariosLab();
            break;
        case 'ObtenerUsuariosHospedaje': // Obtener los usuarios de hospedaje
            $controller->ObtenerUsuariosHos(); // Registrar Entrada (comentado con 'Registrar Entrada')
            break;
        case 'ObtenerUsuariosDep': // Obtener los usuarios de deportes
            $controller->ObtenerUsuariosDep();
            break;
        case 'ObtenerUsuariosBie': // Obtener los usuarios de bienestar
            $controller->ObtenerUsuariosBie();
            break;
        // Si la acción no es válida, se devuelve un error
        default:
            http_response_code(400); // Código de error para solicitud incorrecta
            echo json_encode(["error" => "Acción no válida."]);
            break;
    }
} 
// Si el método no es ni GET ni POST, se devuelve un error 405
else {
    http_response_code(405); // Método no permitido
    echo json_encode(["error" => "Método no permitido."]);
}
