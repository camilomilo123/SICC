<?php
// Mostrar errores durante el desarrollo
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Incluir el archivo del modelo 'prestamodel.php' que contiene la lógica de negocio
require_once '../models/prestamodel.php';

// Verificar que la solicitud es de tipo POST y que el parámetro 'id' está presente
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    // Obtener el valor de 'id' y asegurarse de que sea un número entero
    $id = intval($_POST['id']);

    // Crear una instancia del modelo Prestamodel
    $model = new Prestamodel();

    // Llamar al método 'marcarRegresado' pasando el ID recibido
    // Este método probablemente actualiza el estado de un objeto (como un artículo prestado)
    $resultado = $model->marcarRegresado($id);

    // Devolver el resultado en formato JSON
    echo json_encode($resultado);
} else {
    // Si la solicitud no es válida (no es POST o falta el 'id'), devolver un mensaje de error en formato JSON
    echo json_encode(["status" => "error", "message" => "Petición inválida."]);
}
?>

