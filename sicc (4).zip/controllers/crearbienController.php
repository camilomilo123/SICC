<?php
// Se requiere el archivo que contiene el modelo para crear un nuevo bien (reactivo)
require_once '../models/crearbienModel.php';

// Se define la clase CrearbienController
class CrearbienController {
    // Se define una propiedad privada $model que almacenará la instancia del modelo
    private $model;

    // El constructor de la clase, que crea una instancia del modelo cuando se instancia el controlador
    public function __construct() {
        // Se asigna una nueva instancia del modelo CrearbienModel a la propiedad $model
        $this->model = new CrearbienModel();
    }

    // Función para guardar un reactivo en el sistema
    public function guardarReactivo() {
        // Se verifica que la solicitud sea de tipo POST (es decir, que se haya enviado un formulario)
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Se recogen los datos enviados desde el formulario en un array asociativo
            $datos = [
                'elemento' => $_POST['elemento'],  // Nombre del reactivo
                'cantidad' => $_POST['cantidad'],  // Cantidad del reactivo
                'unidad_medida' => $_POST['unidad_medida'] ?? null,  // Unidad de medida (puede ser nula)
                'ubicacion' => $_POST['ubicacion'] ?? null,  // Ubicación (puede ser nula)
            ];

            // Se intenta agregar el reactivo usando el modelo
            if ($this->model->agregarReactivo($datos)) {
                // Si el reactivo se agrega correctamente, redirige al usuario con un mensaje de éxito
                header("Location: ../views/admin/crearbien.php?success=1");
            } else {
                // Si ocurre un error al agregar el reactivo, redirige al usuario con un mensaje de error
                header("Location: ../views/admin/crearbien.php?error=1");
            }
            exit();  // Termina la ejecución del script después de la redirección
        }
    }
}

// Se instancia el controlador
$controller = new CrearbienController();
// Se llama a la función para guardar el reactivo
$controller->guardarReactivo();
?>

