<?php
// Se requiere el archivo que contiene el modelo para obtener los errores
require_once '../models/ErrorModel.php';

// Se crea una instancia del modelo ReporteError
$modelo = new ReporteError();

// Se obtienen todos los errores registrados a través del método obtenerTodos()
$errores = $modelo->obtenerTodos();

// Se filtran los errores para obtener solo los que no han sido solucionados
// Se usa array_filter para crear un nuevo array con errores cuyo campo 'solucionado' sea igual a 0
$noSolucionados = array_filter($errores, function($error) {
    return $error['solucionado'] == 0;
});

// Se imprime el número total de errores no solucionados en formato JSON
echo json_encode(['total' => count($noSolucionados)]);



