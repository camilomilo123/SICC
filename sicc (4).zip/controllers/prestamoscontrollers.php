<?php
session_start();
require_once '../models/prestamodel.php';

class PrestamoController {
    private $model;

    public function __construct() {
        $this->model = new Prestamodel();
    }

    public function registrarPrestamo($datos) {
        // Validación de sesión
        if (!isset($_SESSION['username']) || empty($_SESSION['username'])) {
            echo json_encode(["status" => "error", "message" => "Usuario no autenticado."]);
            return;
        }

        // Recolección y validación básica de datos
        $prestado = filter_var($datos['prestado_a'] ?? '', FILTER_SANITIZE_STRING);
        $unidad_medida = filter_var($datos['unidad_medida'] ?? '', filter: FILTER_SANITIZE_STRING);
        $cantidad_prestada = filter_var($datos['cantidad'] ?? '', FILTER_VALIDATE_FLOAT);
        date_default_timezone_set('America/Bogota');
        $fecha = date("Y-m-d H:i:s");
        $responsable = $_SESSION['username'];

        // Verificación de campos vacíos o inválidos
        if (!$prestado || !$unidad_medida || !$cantidad_prestada || $cantidad_prestada <= 0) {
            echo json_encode(["status" => "error", "message" => "Todos los campos son obligatorios y deben ser válidos."]);
            return;
        }

        // Determinar tipo de inventario y producto
        $tipos_inventario = [
            "Laboratorio" => "insumo",
            "Deportes" => "elemento",
            "Hospedaje" => "suministro",
            "Bienestar" => "dotacion"
        ];

        $tipo = null;
        $producto = null;

        // Recorremos para determinar el tipo de inventario
        foreach ($tipos_inventario as $tipoInventario => $key) {
            if (isset($datos[$key]) && !empty($datos[$key])) {
                $tipo = $tipoInventario;
                $producto = $datos[$key]; // puede ser ID o nombre
                break;
            }
        }

        // Validación de producto o tipo no especificado
        if (!$producto || !$tipo) {
            echo json_encode(["status" => "error", "message" => "Producto o tipo de inventario no especificado correctamente."]);
            return;
        }

        // Registrar el préstamo (salida con posibilidad de devolución)
        $resultado = $this->model->registrarSalida($producto, $cantidad_prestada, $unidad_medida, $fecha, $prestado, $responsable, $tipo);

        if ($resultado['status'] === 'success') {
            // Si el préstamo fue registrado correctamente
            echo json_encode([
                "status" => "success",
                "message" => "¡Préstamo registrado con éxito!"
            ]);
        } else {
            // Si hubo un error al registrar
            echo json_encode([
                "status" => "error",
                "message" => "Hubo un error al registrar el préstamo. Intenta nuevamente."
            ]);
        }
    }
}

// Manejo de solicitud POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    header('Content-Type: application/json');
    
    $controller = new PrestamoController();
    $controller->registrarPrestamo($_POST);
    exit;
}
?>
