<?php
require_once "../models/conexion_bd.php";
require_once "../models/EntradasModel.php";
require_once "../models/SalidaModel.php";

class NotificacionesController {
    private $db;

    public function __construct() {
        $conexion = new Database(); // Instancia de la conexión
        $this->db = $conexion->getConnection(); 
    }

    public function obtenerNotificaciones() {
        try {
            // Verificar si se envió una categoría en la petición GET
            $categoria = isset($_GET['categoria']) ? $_GET['categoria'] : null;

            // Consulta base para obtener notificaciones
            $query = "SELECT id, mensaje, tipo, leida, categoria FROM notificaciones";

            // Agregar condición si se especifica una categoría
            if ($categoria) {
                $query .= " WHERE categoria = :categoria";
            }

            $query .= " ORDER BY fecha DESC LIMIT 10";

            $stmt = $this->db->prepare($query);

            // Bind de parámetro si hay categoría
            if ($categoria) {
                $stmt->bindParam(":categoria", $categoria, PDO::PARAM_STR);
            }

            $stmt->execute();
            $resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Contador de notificaciones no leídas
            $noLeidas = array_filter($resultados, fn($n) => $n["leida"] == 0);

            echo json_encode([
                "notificaciones" => $resultados,
                "contador" => count($noLeidas)
            ]);
        } catch (Exception $e) {
            echo json_encode(["error" => $e->getMessage()]);
        }
    }

    public function marcarLeida() {
        try {
            $datos = json_decode(file_get_contents("php://input"), true);
            $id = $datos["id"] ?? null;

            if (!$id) {
                echo json_encode(["error" => "ID no válido"]);
                return;
            }

            $query = "UPDATE notificaciones SET leida = 1 WHERE id = :id";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(":id", $id, PDO::PARAM_INT);
            $stmt->execute();

            echo json_encode(["success" => true]);
        } catch (Exception $e) {
            echo json_encode(["error" => $e->getMessage()]);
        }
    }
}

// Manejo de las peticiones AJAX
if (isset($_GET['action'])) {
    $controller = new NotificacionesController();

    if ($_GET['action'] === 'obtenerNotificaciones') {
        $controller->obtenerNotificaciones();
    } elseif ($_GET['action'] === 'marcarLeida' && $_SERVER["REQUEST_METHOD"] === "POST") {
        $controller->marcarLeida();
    }
}

    
    

