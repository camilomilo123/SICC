<?php
require_once "../models/conexion_bd.php";
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Conexión a la base de datos
$conexiondb = new Database();
$pdo = $conexiondb->getConnection();

try {
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $action = $_POST["action"] ?? "";

        if ($action === "eliminar" && isset($_POST["id_usuario"])) {
            // Eliminar un registro específico
            $id = $_POST["id_usuario"];

            $query = "DELETE FROM usuario WHERE id_usuario= :id";
            $stmt = $pdo->prepare($query);
            $stmt->bindParam(":id", $id, PDO::PARAM_INT);

            if ($stmt->execute()) {
                echo json_encode(["status" => "success", "message" => "Registro eliminado correctamente"]);
                exit;  // Detenemos la ejecución para evitar más salidas
            } else {
                echo json_encode(["status" => "error", "message" => "Error al eliminar el registro"]);
                exit;  // Detenemos la ejecución
            }
        }
    }

    // Obtener los datos (sin información sensible)
    $sql = "SELECT id_usuario, nombre, telefono, correo, role_id FROM usuario"; // sin contraseña

    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Enviamos solo los datos que son necesarios para la vista
    echo json_encode(["data" => $usuarios], JSON_UNESCAPED_UNICODE);  
    exit;  // Detenemos la ejecución después de enviar la respuesta
} catch (PDOException $e) {
    echo json_encode(["status" => "error", "message" => $e->getMessage()]);
    exit;  // Detenemos la ejecución en caso de error
}
