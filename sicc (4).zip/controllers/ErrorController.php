<?php
session_start();

require_once '../models/ErrorModel.php';

$roles = [
    1 => 'Administrador',
    2 => 'Laboratorio',
    3 => 'Deportes',
    4 => 'Bienestar',
    5 => 'Hospedaje'
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = $_SESSION['username'] ?? 'Desconocido';
    $correo = $_SESSION['correo'] ?? '';
    $role_id = $_SESSION['role_id'] ?? 0;
    $nombreRol = $roles[$role_id] ?? 'Desconocido';

    // Usar el nombre del rol como tipo de reporte
    $tipo_reporte = $nombreRol;

    $mensaje = $_POST['mensaje'] ?? '';
    $nivel = $_POST['nivel'] ?? '';
    $navegador = $_POST['navegador'] ?? '';
    $sistema = $_POST['sistema'] ?? '';
    $resolucion = $_POST['resolucion'] ?? '';

    // Subir imagen
    $imagen = null;
    $directorioDestino = __DIR__ . '/../views/img/error/'; 

    // Crear carpeta si no existe
    if (!is_dir($directorioDestino)) {
        if (!mkdir($directorioDestino, 0775, true)) {
            echo json_encode(['status' => 'error', 'message' => 'No se pudo crear la carpeta destino.']);
            exit;
        }
    }

    if (!empty($_FILES['imagen']['name'])) {
        $archivo = $_FILES['imagen'];

        // Validar tipo MIME
        $tiposPermitidos = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        if (!in_array($archivo['type'], $tiposPermitidos)) {
            echo json_encode(['status' => 'error', 'message' => 'Tipo de imagen no permitido: ' . $archivo['type']]);
            exit;
        }

        // Validar tamaño (max 5MB)
        if ($archivo['size'] > 5 * 1024 * 1024) {
            echo json_encode(['status' => 'error', 'message' => 'La imagen excede el tamaño permitido (5MB).']);
            exit;
        }

        // Guardar archivo con nombre único
        $nombreArchivo = time() . '_' . basename($archivo['name']);
        $ruta = $directorioDestino . $nombreArchivo;

        if (move_uploaded_file($archivo['tmp_name'], $ruta)) {
            $imagen = $nombreArchivo;
        } else {
            echo json_encode([
                'status' => 'error',
                'message' => 'Error al mover la imagen. tmp_name: ' . $archivo['tmp_name'] . ' | destino: ' . $ruta
            ]);
            exit;
        }
    }

    $modelo = new ReporteError();
    $resultado = $modelo->registrar(
        $usuario,
        $correo,
        $nombreRol,
        $tipo_reporte,
        $mensaje,
        $nivel,
        $imagen,
        $navegador,
        $sistema,
        $resolucion
    );

    header('Content-Type: application/json');
    echo json_encode([
        'status' => $resultado ? 'success' : 'error',
        'message' => $resultado ? 'Reporte enviado correctamente.' : 'Error al registrar el reporte.'
    ]);
}