<?php 
require_once __DIR__ . '/../models/conexion_bd.php';
require_once __DIR__ . '/../librerias/PHPMailer/Exception.php';
require_once __DIR__ . '/../librerias/PHPMailer/PHPMailer.php';
require_once __DIR__ . '/../librerias/PHPMailer/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dependencia = filter_input(INPUT_POST, 'dependencia', FILTER_SANITIZE_STRING);
    $unidad_medida = filter_input(INPUT_POST, 'unidad_medida', FILTER_SANITIZE_STRING);
    $cantidad = filter_input(INPUT_POST, 'cantidad', FILTER_VALIDATE_FLOAT);

    if (!$dependencia || !$unidad_medida || !$cantidad || $cantidad <= 0) {
        echo json_encode(["success" => false, "message" => "Todos los campos son obligatorios y deben ser válidos."]);
        exit;
    }

    // Detectar producto y tipo
    $producto = null;
    $tipo = null;

    if (!empty($_POST['insumo']) || !empty($_POST['insumo_nombre'])) {
        $tipo = "Laboratorio";
        $producto = $_POST['insumo'] ?: $_POST['insumo_nombre'];
        
    } elseif (!empty($_POST['elemento']) || !empty($_POST['elemento_nombre'])) {
        $tipo = "Deportes";
        $producto = $_POST['elemento'] ?: $_POST['elemento_nombre'];

    } elseif (!empty($_POST['suministro']) || !empty($_POST['suministro_nombre'])) {
        $tipo = "Hospedaje";
        $producto = $_POST['suministro'] ?: $_POST['suministro_nombre'];

    } elseif (!empty($_POST['dotacion']) || !empty($_POST['dotacion_nombre'])) {
        $tipo = "Bienestar";
        $producto = $_POST['dotacion'] ?: $_POST['dotacion_nombre'];
    }

    if (!$producto || !$tipo) {
        echo json_encode(["success" => false, "message" => "Datos inválidos o producto no seleccionado."]);
        exit;
    }

    echo registro($dependencia, $producto, $cantidad, $unidad_medida, $tipo);
}

function registro($dependencia, $producto, $cantidad, $unidad_medida, $tipo) {
    try {
        $database = new Database();
        $db = $database->getConnection();

        // Definir las tablas y columnas según el tipo de inventario
        $tipos_inventario = [
            "Laboratorio" => ["tabla" => "inventario_laboratorio", "columna" => "reactivo"],
            "Deportes"    => ["tabla" => "inventario_deportes", "columna" => "elemento"],
            "Hospedaje"   => ["tabla" => "inventario_hospedaje", "columna" => "insumo"],
            "Bienestar"   => ["tabla" => "inventario_bienestar", "columna" => "elemento"]
        ];

        if (!isset($tipos_inventario[$tipo])) {
            throw new Exception("Tipo de inventario no válido.");
        }

        $tabla = $tipos_inventario[$tipo]['tabla'];
        $columna = $tipos_inventario[$tipo]['columna'];

        // Verificar si el producto es un ID numérico o un nombre
        $es_id = is_numeric($producto);
        $query = $es_id
            ? "SELECT id, cantidad, $columna AS nombre, unidad_medida FROM $tabla WHERE id = :producto"
            : "SELECT id, cantidad, $columna AS nombre, unidad_medida FROM $tabla WHERE $columna = :producto";

        $stmt = $db->prepare($query);
        $stmt->bindValue(":producto", $producto, $es_id ? PDO::PARAM_INT : PDO::PARAM_STR);
        $stmt->execute();
        $item = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$item) {
            throw new Exception("El producto '$producto' no se encontró en el inventario de $tipo.");
        }

        $nombre = $item['nombre'];
        $unidad_bd = $item['unidad_medida'];

        // Generar mensaje para el correo
        $mensaje = generarMensaje($nombre, $cantidad, $unidad_medida, $dependencia);

        // Configuración y envío del correo
        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->CharSet = 'UTF-8';
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'siccsena@gmail.com';
        $mail->Password = 'cmpccrehyddeoyde';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port = 465;

        $mail->setFrom('siccsena@gmail.com', 'Sistema de Inventario SICC');
        $mail->addAddress('siccsena@gmail.com');
        $mail->isHTML(true);
        $mail->Subject = '🔔 Petición de Reabastecimiento';
        $mail->Body = $mensaje;

        $mail->send();

        return json_encode(['success' => true, 'message' => 'Solicitud enviada con éxito.']);

    } catch (Exception $e) {
        return json_encode(['success' => false, 'message' => 'Excepción: ' . $e->getMessage()]);
    }
}

function generarMensaje($producto, $cantidad, $unidad_medida, $dependencia) {
    return <<<HTML
    <div style="height: 100vh; display: flex; justify-content: center; align-items: center; padding: 20px;">
        <div style="max-width: 600px; width: 100%; background-color: #ffffff; border-radius: 12px; padding: 30px; box-shadow: 0px 10px 25px rgba(0, 0, 0, 0.15); font-family: 'Arial', sans-serif; color: #333; text-align: center;">

            <!-- Encabezado con Logo -->
            <div style="padding-bottom: 20px; border-bottom: 2px solid #018b03;">
                <img src="https://siccsena.com/views/img/sena.png" alt="SENA Logo" style="max-width: 100px; display: block; margin: 0 auto;">
                <h2 style="color: #212529; font-size: 26px; margin-top: 10px; font-weight: bold;">📦 Petición de Reabastecimiento</h2>
            </div>

            <!-- Detalles del Producto -->
            <div style="padding: 20px; line-height: 1.6; text-align: left;">
            <p>👋 Hola,</p>
            <p>Se ha realizado una petición para reabastecer debido a la baja cantidad en inventario.</p>
                <ul style="list-style: none; padding-left: 0; font-size: 16px;">
                    <li><strong>🧪 Producto:</strong> $producto</li>
                    <li><strong>🔢 Cantidad Solicitada:</strong> $cantidad $unidad_medida</li>
                    <li><strong>🏢 Dependencia:</strong> $dependencia</li>
                </ul>
                <p style="margin-top: 20px;">📩 Por favor, atienda esta solicitud y realice el reabastecimiento lo más pronto posible.</p>
                </div>

            <!-- Pie de Página con Información de Contacto -->
            <div style="margin-top: 20px; padding: 10px; background-color: #212529; color: white; border-radius: 0 0 12px 12px;">
                <p style="margin: 5px 0; font-size: 14px;">📍 Dirección: Cl. 2 #13 - 3, Villeta, Cundinamarca</p>
                <p style="margin: 5px 0; font-size: 14px;">📧 Correo: <a href="siccsena@gmail.com" style="color: #28a745; text-decoration: none;">siccsena@gmail.com</a></p>
            </div>

        </div>
    </div>
    HTML;
}
