<!DOCTYPE html> <!-- Define que el documento está escrito en HTML5 -->
<html lang="es"> <!-- Idioma principal del contenido: Español -->
<head>
  <meta charset="UTF-8"> <!-- Codificación de caracteres UTF-8 -->
  <title>404 - Página no encontrada</title> <!-- Título que aparece en la pestaña del navegador -->

  <!-- Hoja de estilos de Bootstrap desde CDN -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Fuente Inter desde Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700&display=swap" rel="stylesheet">

  <!-- Estilos personalizados para la página 404 -->
  <link rel="stylesheet" href="/views/css/404.css">
</head>

<body>
  <!-- Contenedor de logotipos (SENA y SICC) -->
  <div class="logo-container">
    <img src="/views/img/sena.png" alt="SENA"> <!-- Logo institucional -->
    <div class="separator"></div> <!-- Separador visual entre logos -->
    <img src="/views/icons/hexagon-fill.svg" alt="SICC"> <!-- Icono del sistema SICC -->
  </div>

  <!-- Contenedor principal del mensaje de error -->
  <div class="error-container">
    <div class="error-code">404</div> <!-- Código de error HTTP -->
    <div class="error-message">Página no encontrada</div> <!-- Mensaje principal -->
    
    <!-- Mensaje secundario explicando el error -->
    <p class="error-subtext">Lo sentimos, la página que buscas no existe o fue movida.</p>

    <!-- Botón para volver a la página anterior -->
    <a href="javascript:history.back()" class="btn btn-sicc">
      <i class="bi bi-house-fill"></i> Volver 
    </a>
  </div>
</body>
</html>

