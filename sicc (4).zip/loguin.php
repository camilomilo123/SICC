<!DOCTYPE html> <!-- Define que el documento es HTML5 -->
<html lang="es"> <!-- Idioma principal del documento: Español -->
<head>
    <meta charset="UTF-8"> <!-- Codificación de caracteres UTF-8 -->
    <link rel="icon" type="image/x-icon" href="/assets/logo-vt.svg"> <!-- Ícono del sitio (favicon) -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- Compatibilidad con Internet Explorer -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Escala para dispositivos móviles -->
    <title>Login</title> <!-- Título de la página -->
    <link rel="icon" href="../../views/icons/hexagon-fill.svg" type="image/x-icon"> <!-- Otro favicon (puede sobrescribir el anterior) -->
    <link rel="stylesheet" href="views/css/index.css"> <!-- Hoja de estilos personalizada -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet"> <!-- Hoja de estilos de Bootstrap -->
</head>

<body class="bg-light d-flex justify-content-center align-items-center vh-100">
    <!-- Contenedor del formulario de inicio de sesión -->
    <div class="bg-white p-5 rounded-5 text-secondary shadow" style="width: 25rem">
        
        <!-- Logo centrado -->
        <div class="d-flex justify-content-center">
            <img src="views/icons/hexagon-fill.svg" alt="login-icon" style="height: 7rem">
        </div>

        <!-- Nombre del sistema -->
        <div class="text-center fs-1 bold">SICC</div>

        <!-- FORMULARIO -->
        <form action="config/InicioSesion.php" method="POST" >
            
            <!-- Campo de correo electrónico -->
            <div class="input-group mt-4">
                <div class="input-group-text bg-success">
                    <img src="views/icons/user-icon.svg" alt="username-icon" style="height: 1rem">
                </div>
                <input class="form-control bg-light " type="email" name="correo" placeholder="Correo" required>
            </div>

            <!-- Campo de contraseña -->
            <div class="input-group mt-3">
                <div class="input-group-text bg-success">
                    <img src="views/icons/password-icon.svg" alt="password-icon" style="height: 1rem">
                </div>
                <input class="form-control bg-light " type="password" name="password" placeholder="Contraseña" required>
            </div>

            <!-- Botón de envío del formulario -->
            <button type="submit" class="btn btn-success text-white w-100 mt-4 thin">Iniciar Sesión</button>

            <!-- Línea divisoria -->
            <hr class="my-4">

            <!-- Enlace para recuperación de contraseña -->
            <a href="views/recuperar_contrasena/olvido_contrasena.php" class="text-success d-block text-center thin">¿Olvidaste tu contraseña?</a>
        </form>

    </div>
</body>
</html>
