<?php
session_start();
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");



if (!isset($_SESSION['correo'])) {
    header("Location: ../../index.php");
    exit();
}

if ($_SESSION['role_id'] != 1) {
    header("Location: /SICC/403.php");
    exit();
}

$username = isset($_SESSION['username']) ? $_SESSION['username'] : 'Usuario';




// Si el usuario es admin, continúa con la carga del contenido
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SICC</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="icon" href="../../views/icons/hexagon-fill.svg" type="image/x-icon">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.2/css/buttons.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>



    <link href="https://cdn.lineicons.com/4.0/lineicons.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/administrador.css">
    <link rel="stylesheet" href="../css/Notificaciones.css">
</head>

<body>
    <div class="wrapper ">

        <aside id="sidebar" class="expand">
            <div class="d-flex">
                <button class="toggle-btn" type="button">
                    <i class="bi bi-hexagon-fill"></i>
                </button>
                <div class="sidebar-logo">
                    <a href="#" style="font-size: 25px;">SICC</a>
                </div>
            </div>

            <ul class="sidebar-nav">
                <li class="sidebar-item">
                    <a href="administrador.php" class="sidebar-link">
                        <i class="bi bi-house-door-fill"></i>
                        <span>Inicio</span>
                    </a>
                </li>

                <li class="sidebar-item">
                    <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
                        data-bs-target="#auth" aria-expanded="false" aria-controls="auth">

                        <i class="bi bi-grid-fill"></i>
                        <span> Dependencias</span>
                    </a>

                    <ul id="auth" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">

                        <!-- Laboratorio -->
                        <li class="sidebar-item">
                            <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
                                data-bs-target="#lab-options" aria-expanded="false" aria-controls="lab-options">
                                <i class="bi bi-thermometer-high"></i>Laboratorio
                            </a>
                            <ul id="lab-options" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#auth">
                                <li class="sidebar-item">
                                    <a href="Inv_lab.php" class="sidebar-link"><i class="bi bi-clipboard-fill"></i>Inventario</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="Lab_admin_entrada.php" class="sidebar-link"><i class="bi bi-caret-up"></i>Entradas</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="Lab_admin_salida.php" class="sidebar-link"> <i class="bi bi-caret-down"></i>Salidas</a>
                                </li>
                            </ul>
                        </li>

                        <!-- Deportes -->
                        <li class="sidebar-item">
                            <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
                                data-bs-target="#deportes-options" aria-expanded="false" aria-controls="deportes-options">
                                <i class="bi bi-trophy-fill"></i>Deportes
                            </a>
                            <ul id="deportes-options" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#auth">
                                <li class="sidebar-item">
                                    <a href="Inv_dep.php" class="sidebar-link"><i class="bi bi-clipboard-fill"></i>Inventario</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="Dep_admin_entrada.php" class="sidebar-link"><i class="bi bi-caret-up"></i>Entradas</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="Dep_admin_salida.php" class="sidebar-link"> <i class="bi bi-caret-down"></i>Salidas</a>
                                </li>
                            </ul>
                        </li>

                        <!-- Bienestar -->
                        <li class="sidebar-item">
                            <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
                                data-bs-target="#bienestar-options" aria-expanded="false" aria-controls="bienestar-options">
                                <i class="bi bi-person-arms-up"></i>Bienestar
                            </a>
                            <ul id="bienestar-options" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#auth">
                                <li class="sidebar-item">
                                    <a href="Inv_bien.php" class="sidebar-link"><i class="bi bi-clipboard-fill"></i>Inventario</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="Biene_admin_entradas.php" class="sidebar-link"><i class="bi bi-caret-up"></i>Entradas</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="Biene_admin_salida.php" class="sidebar-link"> <i class="bi bi-caret-down"></i>Salidas</a>
                                </li>
                            </ul>
                        </li>


                        <!-- Hospedaje -->
                        <li class="sidebar-item">
                            <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
                                data-bs-target="#hospedaje-options" aria-expanded="false" aria-controls="hospedaje-options">
                                <i class="bi bi-buildings-fill"></i>Hospedaje
                            </a>
                            <ul id="hospedaje-options" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#auth">
                                <li class="sidebar-item">
                                    <a href="Inv_hos.php" class="sidebar-link"><i class="bi bi-clipboard-fill"></i>Inventario</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="Hospe_admin_entradas.php" class="sidebar-link"><i class="bi bi-caret-up"></i>Entradas</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="Hospe_admin_salida.php" class="sidebar-link"> <i class="bi bi-caret-down"></i>Salidas</a>
                                </li>
                            </ul>
                        </li>
                    </ul>


                </li>


                <li class="sidebar-item">
                    <a href="usuarios.php" class="sidebar-link">
                        <i class="bi bi-people-fill"></i>
                        <span>Usuarios</span>
                    </a>
                </li>

                <li class="sidebar-item">
                    <a href="ReportarErrores.php" class="sidebar-link">
                        <i class="bi bi-exclamation-circle-fill"></i>
                        <span>Reportar errores</span>
                    </a>
                </li>



                <div class="sidebar-item">
                    <a href="#" class="sidebar-link" id="logout">
                        <i class="lni lni-exit"></i>
                        <span>Salir</span>
                    </a>
                </div>
                <script src="../js/cerrarsesion.js"></script>

        </aside>


        <div class="main p-3 bold">
            <div class="row page-titles mx-0">
                <div class="col-sm-6 p-md-0">
                    <div class="welcome-text d-flex align-items-center">
                        <img src="../img/sena.png" style="width: 60px; height: auto;" alt="" class="me-3">
                        <div>
                            <h4 style="color: black;" class="bold" st>Bienvenido a <strong class="bold" style="color: green;">sistema de consumo controlado</strong></h4>
                            <p class="mb-0">¡La solución inteligente para gestionar entradas y salidas!</p>
                        </div>
                    </div>
                </div>


                <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                    <a href="ReportarErrores.php#Tabla_Errores" id="iconoErroresLink" class="position-relative d-none">
                        <i id="iconoErrores" class="bi bi-exclamation-circle-fill text-black" style="font-size: 25px; padding-right: 10px;"></i>
                        <span id="contadorErrores" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger d-none">
                            0
                        </span>
                    </a>
                    <script src="../js/NotificacionesErrores.js"></script>


                    <a class="nav-link position-relative" href="#" id="notificacionesDropdown" role="button" data-bs-toggle="dropdown">
                        <i class="bi bi-bell-fill" style="font-size: 25px; padding-right: 10px;"></i>
                        <span id="notificacionesContador" class="position-absolute top-3 start-10 translate-middle badge rounded-pill bg-danger d-none">
                            0
                        </span>
                    </a>
                    <ul id="notificacionesLista" class="dropdown-menu dropdown-menu-end">
                        <li>
                            <p class="dropdown-item text-center">No hay notificaciones</p>
                        </li>
                    </ul>
                    <script src="../js/NotificacionesLabAdmin.js"></script>




                    <ol class="breadcrumb bold" style="font-size:20px;">
                        <?php echo htmlspecialchars($_SESSION['username']); ?>
                        <i class="bi bi-person-fill"></i>
                    </ol>
                </div>
            </div>
            <div id="AlertaErrror" class="alert alert-info  py-1 px-2" role="alert">
                <script src="../js/avisos/Aviso.js"></script>

                <h5 class="alert-heading mb-0">
                    <div class="text-decoration-none text-dark d-flex justify-content-between align-items-center clickable" onclick="toggleCollapse()">
                        <span id="textoAclaracion"><i class="fas fa-info-circle"></i> Aclaración importante</span>
                        <i class="fas fa-chevron-down" id="toggleIcon"></i>
                    </div>
                </h5>
                <div class="collapse mt-3" id="infoCollapse">
                    <hr>
                    <p class="mb-0 text-justify">
                        En esta sección se pueden crear nuevos usuarios asignados a cada una de las dependencias. Además, se visualiza una tabla con la información clave de cada usuario registrado.
                    </p>
                    <p class="mb-0 mt-2 text-justify">
                        La tabla mostrará los siguientes datos: nombre de usuario, correo electrónico, número de teléfono y el rol asignado. Esta información es esencial para la gestión de acceso y organización por áreas dentro del sistema.
                    </p>
                    <p class="mb-0 mt-2 text-justify">
                        Cada registro permite identificar claramente a los usuarios pertenecientes a cada dependencia, facilitando un control ordenado y segmentado por rol o área funcional.
                    </p>

                </div>
            </div>
            <div>
                <h2><strong style="color: green;">Usuarios</strong></h2>
                <br>
                <form action="../../config/registrarse.php" id="registroForm" method="POST">

                    <div class="row g-2 align-items-center">
                        <!-- Usuario -->
                        <div class="col-lg-2 col-md-6">
                            <div class="input-group">
                                <div id="icono_user" class="input-group-text ">
                                    <img src="../icons/user-icon.svg" alt="username-icon" style="height: 1rem">
                                </div>
                                <input class="form-control bg-light" type="text" name="username" placeholder="Usuario" required>
                            </div>
                        </div>

                        <!-- Teléfono -->
                        <div class="col-lg-2 col-md-6">
                            <div class="input-group">
                                <div id="icono_user" class="input-group-text ">
                                    <img src="../icons/telephone-fill.svg" alt="phone-icon" style="height: 1rem">
                                </div>
                                <input class="form-control bg-light" type="text" name="telefono" placeholder="Teléfono" required>
                            </div>
                        </div>

                        <!-- Correo -->
                        <div class="col-lg-3 col-md-6">
                            <div class="input-group">
                                <div id="icono_user" class="input-group-text ">
                                    <img src="../icons/envelope-at-fill.svg" alt="email-icon" style="height: 1rem">
                                </div>
                                <input class="form-control bg-light" type="email" name="correo" placeholder="Correo" required>
                            </div>
                        </div>

                        <!-- Contraseña -->
                        <div class="col-lg-2 col-md-6">
                            <div class="input-group">
                                <div id="icono_user" class="input-group-text ">
                                    <img src="../icons/password-icon.svg" alt="password-icon" style="height: 1rem">
                                </div>
                                <input class="form-control bg-light" type="password" name="password" placeholder="Contraseña" required>
                            </div>
                        </div>

                        <!-- Rol -->
                        <div class="col-lg-3 col-md-6">
                            <div class="input-group">
                                <div id="icono_user" class="input-group-text ">
                                    <img src="../icons/person-badge-fill.svg" alt="role-icon" style="height: 1rem">
                                </div>
                                <select class="form-select bg-light" name="rol_id" required>
                                    <option value="" disabled selected>Seleccione un rol</option>
                                    <option value="1">Administrador</option>
                                    <option value="2">Laboratorio</option>
                                    <option value="3">Deportes</option>
                                    <option value="4">Bienestar</option>
                                    <option value="5">Hospedaje</option>
                                </select>
                            </div>
                        </div>

                        <!-- Botón -->
                        <div class="col-lg-12 col-md-6">
                            <button id="registrar_usuario" type="submit" class="btn btn-success text-white w-100 fw-semibold shadow-sm" value="registrar">
                                Registrar Usuario
                            </button>
                            <script src="../js/registrarU.js"></script>
                        </div>
                    </div>
                </form>
                <br>
                <hr>
                <table id="Tabla_usuarios" class="table table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Usuario</th>
                            <th>Teléfono</th>
                            <th>Correo</th>
                            <th>Rol</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <script src="../js/Tabla_usuarios.js"></script>
                        <!-- Los datos se cargarán dinámicamente con DataTables -->
                    </tbody>
                </table>

                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
                <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
                <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
                <script src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
                <script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.html5.min.js"></script>
                <script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.print.min.js"></script>


</body>

</html>