$(document).ready(function () {
    $('#Tabla_inventario').DataTable({
        "ajax": {
            "url": "../../controllers/ObtenerEntradas.php",
            "type": "GET",
            "dataSrc": function (json) {
                // Filtrar solo los que tienen dependencia "Laboratorio"
                return json.filter(function (item) {
                    return item.dependencia === "Laboratorio";
                });
            }
        },
        "columns": [
            { "data": "fecha" },
            { "data": "dependencia" },
            { "data": "responsable" },
            { "data": "insumo" },
            { "data": "cantidad_anterior", "render": $.fn.dataTable.render.number('.', ',', 0) },
            { "data": "cantidad_ingresada", "render": $.fn.dataTable.render.number('.', ',', 0) },
            { "data": "cantidad_total", "render": $.fn.dataTable.render.number('.', ',', 0) },
            { "data": "unidad_medida" }
        ],
        "order": [[0, "desc"]],
        "paging": true,
        "searching": true,
        "ordering": true,
        "info": true,
        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por página",
            "zeroRecords": "No se encontraron resultados",
            "info": "Mostrando _START_ a _END_ de _TOTAL_ registros",
            "infoEmpty": "No hay registros disponibles",
            "infoFiltered": "(filtrado de _MAX_ registros totales)",
            "search": "Buscar:",
            "paginate": {
                "first": "Primero",
                "last": "Último",
                "next": "Siguiente",
                "previous": "Anterior"
            }
        }
        
    });
});


