$(document).ready(function() {
    $('#formulario-restablecer').on('submit', function(event) {
        event.preventDefault();

        var token = $("input[name='token']").val();
        var nueva_contrasena = $("#nueva_contrasena").val();

        $.ajax({
            type: 'POST',
            url: '../../controllers/restablecercontroller.php',
            data: { restablecer: true, token: token, nueva_contrasena: nueva_contrasena },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    if (response.message === 'cambiada') {
                        Swal.fire({
                            icon: 'success',
                            title: 'Contraseña cambiada con éxito',
                            text: 'Haz clic en "Aceptar" para volver a iniciar sesión.',
                            confirmButtonColor: '#008f39'
                        }).then((result) => {
                            if (result.isConfirmed) {
                                window.location.href = "../../loguin.php";
                            }
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Hubo un problema al cambiar la contraseña. Intenta nuevamente.',
                            confirmButtonColor: '#d33'
                        });
                    }
                }
            }
        });
    });
});
