$(document).ready(function() {
    $('#Tab_invlaboratorio').DataTable({
        "ajax": {
            "url": "../../controllers/InvLabController.php",
            "type": "POST",
            
        },
        "columns": [
            { "data": "id" },
            { "data": "reactivo" },
            { "data": "formula" },
            { "data": "estado" },
            { "data": "codigo_almacenamiento" },
            { "data": "cantidad" },
            { "data": "unidad_medida" },
            { "data": "fecha_vencimiento" },
            { "data": "lote" },
            { "data": "ubicacion" }
        ],
        "paging": true,
        "searching": true,
        "ordering": true,
        "info": true,
        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por página",
            "zeroRecords": "No se encontraron resultados",
            "info": "Mostrando _START_ a _END_ de _TOTAL_ registros",
            "infoEmpty": "No hay registros disponibles",
            "infoFiltered": "(filtrado de _MAX_ registros totales)",
            "search": "Buscar:",
            "paginate": {
                "first": "Primero",
                "last": "Último",
                "next": "Siguiente",
                "previous": "Anterior"
            }
        },
        
        
    });
});
