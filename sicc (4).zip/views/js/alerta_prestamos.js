$("#formulario").submit(function(e) {
    e.preventDefault(); // Evita que el formulario se envíe automáticamente

    Swal.fire({
        title: '¿Confirmar préstamo?',
        text: 'El producto será descontado del inventario hasta su devolución.',
        icon: 'warning',
        showCancelButton: true,
        cancelButtonText: 'Cancelar',
        confirmButtonText: 'Sí, registrar',
        confirmButtonColor: '#008f39',
        cancelButtonColor: '#d33' 
    }).then((result) => {
        if (result.isConfirmed) {
            // Muestra un loader mientras se realiza la solicitud al servidor
          

            // Serializa los datos del formulario para enviarlos por AJAX
            var formData = $("#formulario").serialize();

            $.ajax({
                url: "../../controllers/prestamoscontrollers.php", // Ruta al controlador PHP
                type: "POST",
                data: formData,
                dataType: "json",
                success: function(response) {
                    Swal.close(); // Oculta el loader

                    if (response.status === "success") {
                        Swal.fire({
                            title: '¡Registrado!',
                            text: response.message || 'Préstamo guardado correctamente.',
                            icon: 'success',
                            confirmButtonColor: '#008f39'
                        }).then(() => {
                            location.reload(); // Recarga la página para mostrar los cambios
                        });
                    } else {
                        // Mostrar el mensaje de error del modelo PHP
                        Swal.fire({
                            title: 'Error',
                            html: response.message || 'No se pudo registrar el préstamo.', // Se usa `html` para mostrar el mensaje completo
                            icon: 'error',
                            confirmButtonColor: '#d33'
                        });
                    }
                },
                error: function(xhr, status, error) {
                    Swal.close();
                    console.error("Error de conexión:", status, error, xhr.responseText);
                    Swal.fire({
                        title: 'Sin conexión',
                        text: 'Intenta nuevamente.',
                        icon: 'error',
                        confirmButtonColor: '#d33'
                    });
                }
            });
        }
    });
});
