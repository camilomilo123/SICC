document.addEventListener("DOMContentLoaded", function() {
    fetch("../../controllers/EntradasController.php?action=contarInsumosBienestar")
        .then(response => response.json())
        .then(data => {
            document.getElementById("TotalInsumosBie").textContent = data.total_insumos.toLocaleString();
        })
        .catch(error => {
            console.error("Error al obtener las insumos:", error);
            return error.text().then(text => console.error("Detalles del error:", text));
        });
});