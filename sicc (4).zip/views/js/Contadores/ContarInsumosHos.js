document.addEventListener("DOMContentLoaded", function() {
    fetch("../../controllers/EntradasController.php?action=contarInsumosHospedaje")
        .then(response => response.json())
        .then(data => {
            document.getElementById("TotalInsumosHos").textContent = data.total_insumos.toLocaleString();
        })
        .catch(error => {
            console.error("Error al obtener las insumos:", error);
            return error.text().then(text => console.error("Detalles del error:", text));
        });
});