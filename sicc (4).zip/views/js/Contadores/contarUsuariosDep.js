document.addEventListener("DOMContentLoaded", function() {
    fetch("../../controllers/EntradasController.php?action=ObtenerUsuariosDep")
        .then(response => response.json())
        .then(data => {
            document.getElementById("TotalUsuariosLab").textContent = data.total.toLocaleString(); 
        })
        .catch(error => console.error("Error al obtener las entradas:", error));
});