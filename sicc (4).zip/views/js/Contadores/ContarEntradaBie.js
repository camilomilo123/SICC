document.addEventListener("DOMContentLoaded", function() {
    fetch("../../controllers/EntradasController.php?action=contarEntradasBienestar") // Acción corregida
        .then(response => response.json())
        .then(data => {
            if (data && typeof data.total !== "undefined") {
                document.getElementById("totalEntradas").textContent = data.total.toLocaleString();
            } else {
                console.error("Respuesta inesperada del servidor:", data);
            }
        })
        .catch(error => console.error("Error al obtener las entradas:", error));
});