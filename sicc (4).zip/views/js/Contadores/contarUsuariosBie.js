document.addEventListener("DOMContentLoaded", function() {
    fetch("../../controllers/EntradasController.php?action=ObtenerUsuariosBie")
        .then(response => response.json())
        .then(data => {
            document.getElementById("TotalUsuariosBie").textContent = data.total.toLocaleString(); 
        })
        .catch(error => console.error("Error al obtener las entradas:", error));
});