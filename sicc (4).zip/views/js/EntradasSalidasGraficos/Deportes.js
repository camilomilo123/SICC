document.addEventListener("DOMContentLoaded", function () {
    // Función para cargar el primer gráfico (doughnut)
    function cargarGraficoEntradasSalidasLaboratorio() {
        fetch("../../controllers/ReporteController.php?action=obtenerDatosGrafico_D")
            .then(response => response.json())
            .then(data => {
                const ctx = document.getElementById("graficoDeportes").getContext("2d");

                new Chart(ctx, {
                    type: "doughnut", // Gráfico circular
                    data: {
                        labels: ["Entradas", "Salidas"],
                        datasets: [{
                            data: [data.entradas, data.salidas],
                            backgroundColor: ["#007832", "#00304D"], 
                            borderColor: ["green", "#00304D"], // Azul para entradas, rojo para salidas
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            legend: {
                                position: "top"
                            }
                        }
                    }
                });
            })
            .catch(error => console.error("Error al obtener datos del gráfico de entradas y salidas:", error));
    }

    // Función para cargar el segundo gráfico (por ejemplo, gráfico de barras)
    
    // Llamar a ambas funciones para cargar los gráficos
    cargarGraficoEntradasSalidasLaboratorio();
    
});