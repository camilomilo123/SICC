
    document.addEventListener("DOMContentLoaded", function () {
        document.getElementById("registroForm").addEventListener("submit", function (event) {
            event.preventDefault(); // Evitar envío directo

            Swal.fire({
                title: "¿Estás seguro?",
                text: "El usuario será registrado en el sistema",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#007832",
                cancelButtonColor: "#d33",
                confirmButtonText: "Sí, registrar",
                cancelButtonText: "Cancelar"
            }).then((result) => {
                if (result.isConfirmed) {
                    // Enviar el formulario con AJAX
                    let formData = new FormData(this);

                    fetch("../../config/registrarse.php", {
                        method: "POST",
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === "success") {
                            Swal.fire({
                                title: "¡Registro exitoso!",
                                text: "El usuario fue registrado correctamente",
                                icon: "success"
                            }).then(() => {
                                window.location.href = 'usuarios.php';
                            });
                        } else {
                            Swal.fire({
                                title: "Error",
                                text: "No se pudo registrar el usuario: " + data.message,
                                icon: "error"
                            });
                        }
                    })
                    .catch(error => console.error("Error:", error));
                }
            });
        });
    });






