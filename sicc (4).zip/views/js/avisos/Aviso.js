function toggleCollapse() {
    const collapseEl = document.getElementById('infoCollapse');
    const icon = document.getElementById('toggleIcon');

    const bsCollapse = new bootstrap.Collapse(collapseEl, {
      toggle: false // No se activa automáticamente
    });

    if (collapseEl.classList.contains('show')) {
      bsCollapse.hide();
      icon.classList.remove('fa-chevron-up');
      icon.classList.add('fa-chevron-down');
    } else {
      bsCollapse.show();
      icon.classList.remove('fa-chevron-down');
      icon.classList.add('fa-chevron-up');
    }
  }