$("#formulario").submit(function(e) {
    e.preventDefault(); 

    Swal.fire({
        title: '¿Deseas enviar la solicitud?',
        text: "Estás a punto de solicitar el reabastecimiento del producto.",
        icon: 'warning',
        showCancelButton: true,
        cancelButtonText: 'Cancelar',
        confirmButtonText: 'Sí, enviar',
        confirmButtonColor: '#008f39', 
        cancelButtonColor: '#d33'
    }).then((result) => {
        if (result.isConfirmed) {
            // Mostrar indicador de carga
            Swal.fire({
                title: 'Enviando...',
                allowOutsideClick: false,
                didOpen: () => {
                    Swal.showLoading();
                },
                customClass: {
                    title: 'swal-title',
                    content: 'swal-content',
                    confirmButton: 'swal-confirm-btn',
                    cancelButton: 'swal-cancel-btn'
                }
            });

            var formData = $("#formulario").serialize();

            $.ajax({
                url: "../../controllers/solicitar_produc_manu.php",
                type: "POST",
                data: formData,
                dataType: "json",
                success: function(response) {
                    Swal.close(); // Cerrar el indicador de carga

                    if (response.success) {
                        Swal.fire({
                            title: '✅ Solicitud enviada',
                            text: response.message,
                            icon: 'success',
                            confirmButtonColor: '#008f39'
                        }).then(() => {
                            location.reload(); 
                        });
                    } else {
                        Swal.fire({
                            title: '❌ Error',
                            text: response.message,
                            icon: 'error',
                            confirmButtonColor: '#d33'
                        });
                    }
                },
                error: function() {
                    Swal.close(); // Cerrar el indicador de carga
                    Swal.fire({
                        title: '⚠️ Error de conexión',
                        text: 'No se pudo conectar con el servidor.',
                        icon: 'error',
                        confirmButtonColor: '#d33'
                    });
                }
            });
        }
    });
});
