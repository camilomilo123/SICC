(function () { // Encapsula todo el código para evitar conflictos globales
    let currentPageReactivos = 1;
    let currentPageDeportes = 1;
    const itemsPerPage = 4;
    const itemsPerPageD=4;
    let chartInstance = null;
    let sportsChartInstance = null;

    document.addEventListener("DOMContentLoaded", function () {
        function cargarDatosReactivos(page) {
            fetch("../../controllers/get_chart_data.php")
                .then(response => response.json())
                .then(data => {
                    const start = (page - 1) * itemsPerPage;
                    const end = start + itemsPerPage;
                    const paginatedData = data.slice(start, end);

                    const labels = paginatedData.map(item => item.reactivo);
                    const cantidades = paginatedData.map(item => item.cantidad);

                    const ctx = document.getElementById('myChart').getContext('2d');
                    if (chartInstance) chartInstance.destroy();

                    chartInstance = new Chart(ctx, {
                        type: 'bar',
                        data: {
                            labels: labels,
                            datasets: [{
                                label: 'Cantidad Disponible laboratorio',
                                data: cantidades,
                                backgroundColor: '#00304D',
                                borderColor: '#50E5F9',
                                borderWidth: 1
                            }]
                        },
                        options: {
                            responsive: true,
                            scales: { y: { beginAtZero: true } }
                        }
                    });

                    document.getElementById("prevPageReactivos").style.display = page === 1 ? 'none' : 'inline-block';
                    document.getElementById("nextPageReactivos").style.display = end >= data.length ? 'none' : 'inline-block';
                })
                .catch(error => console.error("Error al obtener los datos:", error));
        }

        function cargarDatosDeportes(page) {
            fetch("../../controllers/get_chart_data_D.php")
                .then(response => response.json())
                .then(data => {
                    const start = (page - 1) * itemsPerPageD;
                    const end = start + itemsPerPageD;
                    const paginatedData = data.slice(start, end);

                    const labels = paginatedData.map(item => item.elemento);
                    const cantidades = paginatedData.map(item => item.cantidad);

                    const ctx = document.getElementById('myChartSports').getContext('2d');
                    if (sportsChartInstance) sportsChartInstance.destroy();

                    sportsChartInstance = new Chart(ctx, {
                        type: 'bar',
                        data: {
                            labels: labels,
                            datasets: [{
                                label: 'Cantidad de Elementos Deportivos',
                                data: cantidades,
                                backgroundColor: ['#00304D'],
                                borderColor: '#50E5F9',
                                borderWidth: 1
                            }]
                        },
                        options: {
                            responsive: true,
                            scales: { y: { beginAtZero: true } }
                        }
                    });

                    document.getElementById("prevPageDeportes").style.display = page === 1 ? 'none' : 'inline-block';
                    document.getElementById("nextPageDeportes").style.display = end >= data.length ? 'none' : 'inline-block';
                })
                .catch(error => console.error("Error al obtener los datos de deportes:", error));
        }

        // Eventos de paginación para Reactivos
        document.getElementById("nextPageReactivos").addEventListener("click", function () {
            currentPageReactivos++;
            cargarDatosReactivos(currentPageReactivos);
        });

        document.getElementById("prevPageReactivos").addEventListener("click", function () {
            if (currentPageReactivos > 1) {
                currentPageReactivos--;
                cargarDatosReactivos(currentPageReactivos);
            }
        });

        // Eventos de paginación para Deportes
        document.getElementById("nextPageDeportes").addEventListener("click", function () {
            currentPageDeportes++;
            cargarDatosDeportes(currentPageDeportes);
        });

        document.getElementById("prevPageDeportes").addEventListener("click", function () {
            if (currentPageDeportes > 1) {
                currentPageDeportes--;
                cargarDatosDeportes(currentPageDeportes);
            }
        });

        // Cargar la primera página de datos al cargar la página
        cargarDatosReactivos(currentPageReactivos);
        cargarDatosDeportes(currentPageDeportes);
    });
})();


