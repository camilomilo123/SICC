document.addEventListener("DOMContentLoaded", function() {
    fetch("../../controllers/EntradasController.php?action=ObtenerUsuarios")
        .then(response => response.json())
        .then(data => {
            document.getElementById("TotalUsuarios").textContent = data.total.toLocaleString(); 
        })
        .catch(error => console.error("Error al obtener las entradas:", error));
});