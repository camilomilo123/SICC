$("#formulario").submit(function(e) {
    e.preventDefault();

    Swal.fire({
        title: '¿Deseas confirmar esta edición?',
        text: "Estás a punto de modificar los datos de un insumo o elemento.",
        icon: 'warning',
        showCancelButton: true,
        cancelButtonText: 'Cancelar',
        confirmButtonText: 'Sí, confirmar edición',
        confirmButtonColor: '#007932', 
        cancelButtonColor: '#00304D' 
    }).then((result) => {
        if (result.isConfirmed) {
            var formData = $("#formulario").serialize();

            $.ajax({
                url: "../../controllers/editarcontroller.php",
                type: "POST",
                data: formData,
                dataType: "json",
                success: function(response) {
                    if (response.status === "success") {
                        Swal.fire({
                            title: '¡Edición exitosa!',
                            text: 'Los datos han sido actualizados correctamente.',
                            icon: 'success',
                            confirmButtonColor: '#007932'
                        }).then(() => {
                            location.reload();
                        });
                    } else {
                        Swal.fire({
                            title: 'Error al actualizar',
                            text: response.message,
                            icon: 'error',
                            confirmButtonColor: '#d33'
                        });
                    }
                },
                error: function() {
                    Swal.fire({
                        title: 'Error de conexión',
                        text: 'Hubo un problema con el servidor. Intenta nuevamente.',
                        icon: 'error',
                        confirmButtonColor: '#d33'
                    });
                }
            });
        }
    });
});