function confirmarEliminacion(id) {
    Swal.fire({
        title: '¿Estás seguro?',
        text: "¡No podrás revertir esto!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: "#d33",
        confirmButtonText: '¡Sí, eliminar!',
        cancelButtonText: 'Cancelar',
        reverseButtons: true
    }).then((result) => {
        if (result.isConfirmed) {
            // Enviar la solicitud al controlador usando Fetch API
            fetch(`../../controllers/eliminarController.php?id=${id}`)
                .then(response => response.text())
                .then(data => {
                    // Si el servidor devuelve éxito, mostramos la alerta y luego redirigimos
                    Swal.fire({
                        title: '¡Eliminado!',
                        text: 'El reactivo ha sido eliminado correctamente.',
                        icon: 'success',
                        timer: 2000, // Espera 2 segundos antes de redirigir
                        showConfirmButton: false
                    }).then(() => {
                        window.location.href = '../../views/admin/Inv_lab.php';
                    });
                })
                .catch(error => {
                    Swal.fire(
                        'Error',
                        'Ocurrió un error al eliminar el reactivo.',
                        'error'
                    );
                });
        } else {
            Swal.fire(
                'Eliminación cancelada',
                'El reactivo no fue eliminado.',
                'error'
            );
        }
    });
}