$(document).ready(function () {
    function buscarInventario(tipo, inputID, listaID, hiddenID, unidadMedidaID) {
        $(inputID).on('keyup', function () {
            let busqueda = $(this).val().trim();

            if (busqueda.length === 0) {
                $(listaID).empty().hide();
                $(hiddenID).val('');
                $(unidadMedidaID).val('');
                return;
            }

            $.ajax({
                url: `../../controllers/InventarioController.php?action=listar&tipo=${tipo}`,
                type: 'GET',
                data: { buscar: busqueda },
                dataType: 'json',
                success: function (data) {
                    $(listaID).empty();

                    if (data.length === 0) {
                        $(listaID).append('<li class="dropdown-item text-muted">No hay resultados</li>').show();
                        return;
                    }

                    data.forEach(function (item) {
                        let nombre = item.reactivo || item.elemento || item.insumo || item.dotacion;
                        $(listaID).append(`<li class="dropdown-item" data-id="${item.id}">${nombre}</li>`);
                    });

                    $(listaID).show();
                },
                error: function () {
                    $(listaID).hide();
                }
            });
        });

        $(document).on('click', `${listaID} li`, function () {
            let seleccionado = $(this).text();
            let idSeleccionado = $(this).data('id');

            $(inputID).val(seleccionado).css('background-color', '#d3d3d3');
            $(hiddenID).val(idSeleccionado);
            $(listaID).hide();

            // Establecer la unidad de medida según el tipo
            if (tipo === 'insumo') {
                obtenerUnidadDeMedida(idSeleccionado, unidadMedidaID);
            } else {
                $(unidadMedidaID).val('unidad');
            }
        });

        $('form').on('submit', function () {
            let inputVal = $(inputID).val().trim();
            let hiddenVal = $(hiddenID).val().trim();
            if (inputVal !== '' && hiddenVal === '') {
                $(hiddenID).val(inputVal); // Guardar texto como valor
            }
        });

        $(document).on('click', function (e) {
            if (!$(inputID).is(e.target) && !$(listaID).is(e.target) && $(listaID).has(e.target).length === 0) {
                $(listaID).hide();
            }
        });
    }

    function obtenerUnidadDeMedida(insumoId, unidadMedidaID) {
        $.ajax({
            url: `../../controllers/InventarioController.php?action=obtenerUnidadMedida&id=${insumoId}`,
            type: 'GET',
            dataType: 'json',
            success: function (data) {
                if (data.unidad_medida) {
                    $(unidadMedidaID).val(data.unidad_medida);
                } else {
                    $(unidadMedidaID).val('');
                }
            },
            error: function () {
                $(unidadMedidaID).val('');
            }
        });
    }

    // Llamadas para cada tipo
    buscarInventario('insumo', '#buscar_insumo', '#lista_insumo', '#insumo', '#unidad_medida');
    buscarInventario('elemento', '#buscar_elemento', '#lista_elemento', '#elemento', '#unidad_medida');
    buscarInventario('suministro', '#buscar_suministro', '#lista_suministro', '#suministro', '#unidad_medida');
    buscarInventario('dotacion', '#buscar_dotacion', '#lista_dotacion', '#dotacion', '#unidad_medida');
});
