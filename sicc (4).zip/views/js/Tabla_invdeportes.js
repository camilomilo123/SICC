$(document).ready(function () {
    var tabla = $('#Tabla_invdeportes').DataTable({
        "ajax": {
            "url": "../../controllers/InvDepController.php",
            "type": "POST"
        },
        "columns": [
            { "data": "id" },
            { "data": "elemento" },
            { "data": "cantidad" },
            { "data": "unidad_medida" },
            { "data": "ubicacion" },
            {
                "data": null,
                "render": function (data, type, row) {
                    return `
                        <button class="btn btn-danger btnEliminar" data-id="${row.id}">
                            <i class="bi bi-trash-fill"></i>
                        </button>
                        <button style="background-color: #00304D; border: 2px solid #00304D; color: white;" 
                            class="btn btn-info btnEditar" 
                            data-id="${row.id}" 
                            data-elemento="${row.elemento}" 
                            data-ubicacion="${row.ubicacion}">
                            <i class="bi bi-pencil-square"></i>
                        </button>
                    `;
                }
            }
        ],
        "paging": true,
        "searching": true,
        "ordering": true,
        "info": true,
        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por página",
            "zeroRecords": "No se encontraron resultados",
            "info": "Mostrando _START_ a _END_ de _TOTAL_ registros",
            "infoEmpty": "No hay registros disponibles",
            "infoFiltered": "(filtrado de _MAX_ registros totales)",
            "search": "Buscar:",
            "paginate": {
                "first": "Primero",
                "last": "Último",
                "next": "Siguiente",
                "previous": "Anterior"
            }
        },
       dom: 'lfrtipB',
        buttons: [
            {
                extend: 'excelHtml5',
                title: 'Inventario Deportes',
                exportOptions: {
                    columns: ':visible:not(:last-child)'
                },
                className: 'd-none' // Esto oculta el botón original
            }
        ]
    });

    // Cuando se hace click en el botón HTML
    $('#btnExportarExcel').on('click', function() {
        tabla.button('.buttons-excel').trigger();
    });



    // Al hacer click en el botón del HTML
    $('#btnExportarExcel').on('click', function() {
        // Creamos un botón de exportar a Excel "virtualmente" y lo disparamos
        tabla.button().add(0, {
            extend: 'excelHtml5',
            title: 'Inventario Deportes',
            exportOptions: {
                columns: ':visible:not(:last-child)'
            }
        }).trigger();
        
        // Opcional: eliminar el botón extra después de usarlo para no crear muchos botones ocultos
        tabla.buttons(0).remove();
    });

    // Evento para editar
    $('#Tabla_invdeportes').on('click', '.btnEditar', function () {
        const id = $(this).data('id');
        const elemento = $(this).data('elemento');
        const ubicacion = $(this).data('ubicacion');

        Swal.fire({
           title: 'Editar Insumo',
            width: '800px',
            html:
              `<div style="display: flex; flex-direction: column; gap: 12px;">
          
                <div style="display: flex; align-items: center; gap: 10px;">
                  <label for="swal-elemento" style="width: 150px;">Nombre del Insumo:</label>
                  <input id="swal-elemento" class="swal2-input" value="${elemento}" readonly style="flex: 1;">
                </div>
          
                
          
                <div style="display: flex; align-items: center; gap: 10px;">
                  <label for="swal-ubicacion" style="width: 150px;">Ubicación:</label>
                  <input id="swal-ubicacion" class="swal2-input" value="${ubicacion}" style="flex: 1;">
                </div>
          
              </div>`,
            focusConfirm: false,
            showCancelButton: true,
            confirmButtonColor: "#39A900",
            confirmButtonText: 'Actualizar',
            cancelButtonColor: "#00304D",
            cancelButtonText: 'Cancelar',
            preConfirm: () => {
                const nombre = document.getElementById('swal-elemento').value;
                const ubicacion = document.getElementById('swal-ubicacion').value;

                if (!nombre || !ubicacion) {
                    Swal.showValidationMessage('Todos los campos son obligatorios');
                    return false;
                }

                return {
                    insumo: id,
                    nombre: nombre,
                    ubicacion: ubicacion,
                    dependencia: 'Deportes'
                };
            }
        }).then((result) => {
            if (result.isConfirmed && result.value) {
                $.ajax({
                    url: "../../controllers/editarcontroller.php",
                    type: "POST",
                    data: result.value,
                    dataType: "json",
                    success: function (response) {
                        if (response.status === "success") {
                            Swal.fire({
                                title: '¡Actualizado!',
                                text: response.message,
                                icon: 'success',
                                confirmButtonColor: '#39A900'
                            }).then(() => {
                                tabla.ajax.reload(null, false);
                            });
                        } else {
                            Swal.fire('Error', response.message, 'error');
                        }
                    },
                    error: function (xhr, status, error) {
                        console.log(xhr.responseText);
                        Swal.fire('Error', 'Ocurrió un problema con la petición', 'error');
                    }
                });
            }
        });
    });

    // Evento para eliminar
    $('#Tabla_invdeportes').on('click', '.btnEliminar', function () {
        let id = $(this).data('id');

        Swal.fire({
            title: '¿Estás seguro?',
            text: "¡Esta acción eliminará el elemento de forma permanente!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#00304D',
            confirmButtonText: 'Sí, eliminar',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: "../../controllers/InvDepController.php",
                    type: "POST",
                    data: { action: "eliminar", id: id },
                    dataType: "json",
                    success: function (response) {
                        if (response.status === "success") {
                            Swal.fire(
                                '¡Eliminado!',
                                response.message,
                                'success'
                            );
                            tabla.ajax.reload(null, false);
                        } else {
                            Swal.fire(
                                'Error',
                                'No se pudo eliminar: ' + response.message,
                                'error'
                            );
                        }
                    },
                    error: function (xhr, status, error) {
                        console.log(xhr.responseText);
                        Swal.fire(
                            'Error',
                            'Ocurrió un problema con la petición: ' + error,
                            'error'
                        );
                    }
                });
            }
        });
    });
});
