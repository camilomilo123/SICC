$(document).ready(function () {
    $('#Tabla_usuarios').DataTable({
"ajax": {
    "url": "../../controllers/get_usuarios.php",
    "dataSrc": "data"
},
"columns": [
    { "data": "id_usuario" },
    { "data": "nombre" },
    { "data": "telefono" },
    { "data": "correo" },
    { "data": "rol" } ,
    {
                "data": "id_usuario",
                "render": function(data, type, row) {
                    return `
                        <button class="btn btn-danger btnEliminar" data-id="${data}"><i class="bi bi-trash-fill"></i></button>
                        <button style="background-color: #00304D; border: 2px solid #00304D; color: white;"  class="btn btn-info btnEditar" data-id="${data}" data-nombre="${row.nombre}" data-telefono="${row.telefono}" data-correo="${row.correo}" data-rol="${row.rol}"><i class="bi bi-pencil-square"></i></button>
                    `;
                }
            }
],
"order": [[0, "asc"]], 
"paging": true,
        "searching": true,
        "ordering": true,
        "info": true,
        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por página",
            "zeroRecords": "No se encontraron resultados",
            "info": "Mostrando _START_ a _END_ de _TOTAL_ registros",
            "infoEmpty": "No hay registros disponibles",
            "infoFiltered": "(filtrado de _MAX_ registros totales)",
            "search": "Buscar:",
            "paginate": {
                "first": "Primero",
                "last": "Último",
                "next": "Siguiente",
                "previous": "Anterior"
            }
        },
});
$('#Tabla_usuarios').on('click', '.btnEliminar', function() {
        let id = $(this).data('id');

        Swal.fire({
            title: '¿Estás seguro?',
            text: "¡Esta acción eliminará el usuario de forma permanente!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#00304D',
            confirmButtonText: 'Sí, eliminar',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: "../../controllers/InvUsuController.php",
                    type: "POST",
                    data: { action: "eliminar", id_usuario: id },
                    dataType: "json",
                    success: function(response) {
                        if (response.status === "success") {
                            Swal.fire({
                                title: '¡Eliminado!',
                                text: response.message,
                                icon: 'success',
                                confirmButtonColor: '#39A900'
                            }).then(() => {
                                location.reload();  // Recargar la página
                            });
                        }else {
                            Swal.fire(
                                'Error',
                                'No se pudo eliminar: ' + response.message,
                                'error'
                            );
                        }
                    },
                    error: function(xhr, status, error) {
                        console.log(xhr.responseText);
                        Swal.fire(
                            'Error',
                            'Ocurrió un problema con la petición: ' + error,
                            'error'
                        );
                    }
                });
            }
        });
    });
    $('#Tabla_usuarios').on('click', '.btnEditar', function () {
        const id = $(this).data('id');
        const nombre = $(this).data('nombre');
        const telefono = $(this).data('telefono');
        const correo = $(this).data('correo');
        const rol = $(this).data('rol');
    
        Swal.fire({
            title: 'Editar Usuario',
html:
    `<label for="swal-nombre">Nombre</label>
    <input id="swal-nombre" class="swal2-input" placeholder="Nombre" value="${nombre}">` +

    `<label for="swal-telefono">Teléfono</label>
    <input id="swal-telefono" class="swal2-input" placeholder="Teléfono" value="${telefono}">` +

    `<label for="swal-correo">Correo</label>
    <input id="swal-correo" class="swal2-input" placeholder="Correo" value="${correo}">` +

    `<div style="margin-top: 10px;">
        <label for="swal-rol">Rol</label>
        <select id="swal-rol" class="swal2-input" style="width: 100%;">
            <option value="1" ${rol == 1 ? 'selected' : ''}>Administrador</option>
            <option value="2" ${rol == 2 ? 'selected' : ''}>Laboratorio</option>
            <option value="3" ${rol == 3 ? 'selected' : ''}>Deportes</option>
            <option value="4" ${rol == 4 ? 'selected' : ''}>Bienestar</option>
            <option value="5" ${rol == 5 ? 'selected' : ''}>Hospedaje</option>
        </select>
    </div>`,

            focusConfirm: false,
            showCancelButton: true,
            confirmButtonColor: "#39A900",
            confirmButtonText: 'Actualizar',
            cancelButtonColor: "#00304D",
            cancelButtonText: 'Cancelar',
            preConfirm: () => {
                const nuevoNombre = document.getElementById('swal-nombre').value;
                const nuevoTelefono = document.getElementById('swal-telefono').value;
                const nuevoCorreo = document.getElementById('swal-correo').value;
                const nuevoRol = document.getElementById('swal-rol').value;
    
                if (!nuevoNombre || !nuevoTelefono || !nuevoCorreo) {
                    Swal.showValidationMessage('Todos los campos son obligatorios');
                    return false;
                }
    
                return {
                    id_usuario: id,
                    nombre: nuevoNombre,
                    telefono: nuevoTelefono,
                    correo: nuevoCorreo,
                    rol: nuevoRol
                };
            }
        }).then((result) => {
            if (result.isConfirmed && result.value) {
                $.ajax({
                    url: "../../controllers/editar_usuario.php",
                    type: "POST",
                    data: result.value,
                    dataType: "json",
                    success: function (response) {
                        if (response.status === "success") {
                            Swal.fire({
                                title: '¡Actualizado!',
                                text: response.message,
                                icon: 'success',
                                confirmButtonColor: '#39A900'
                            }).then(() => {
                                location.reload();  // Recargar la página
                            });
                        } else {
                            Swal.fire('Error', response.message, 'error');
                        }
                    },
                    error: function (xhr, status, error) {
                        console.log(xhr.responseText);
                        Swal.fire('Error', 'Ocurrió un problema con la petición', 'error');
                    }
                });
            }
        });
    });
});

