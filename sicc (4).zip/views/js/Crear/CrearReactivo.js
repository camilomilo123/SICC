document.getElementById("formulario").addEventListener("submit", function(e) {
    e.preventDefault(); // Evitar que el formulario se envíe de forma predeterminada

    // Alerta de confirmación antes de crear el insumo
    Swal.fire({
        title: '¿Estás seguro?',
        text: "¿Quieres crear este nuevo insumo?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#007932',
        cancelButtonColor: '#00304D',
        cancelButtonText: 'Cancelar',
        confirmButtonText: 'Sí, crear'
        
    }).then((result) => {
        if (result.isConfirmed) {
            // Si el usuario confirma, muestra la alerta de éxito
            Swal.fire({
                title: '¡Reactivo Insumo!',
                text: 'El reactivo ha sido creado correctamente.',
                icon: 'success',
                confirmButtonColor: '#007932',
                confirmButtonText: 'Aceptar'

            }).then(() => {
                // Luego, envía el formulario
                this.submit();
            });
        } else {
            // Si el usuario cancela, muestra la alerta de cancelación
            Swal.fire({
                title: '¡No se creó el insumo!',
                text: 'El reactivo no fue creado.',
                icon: 'error',
                confirmButtonColor: '#007932',
                confirmButtonText: 'Aceptar'
            });
        }
    });
});

// El botón de volver no depende del estado del formulario
document.querySelectorAll('a[href="Inv_lab.php"]').forEach(button => {
    button.addEventListener('click', function(event) {
        event.preventDefault();
        window.location.href = "Inv_lab.php";
    });
});