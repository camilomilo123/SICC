document.addEventListener("DOMContentLoaded", () => {
  // Detectar sistema
  const navegador = navigator.userAgent;
  const sistema = navigator.platform;
  const resolucion = `${screen.width}x${screen.height}`;

  document.getElementById('navegador').value = navegador;
  document.getElementById('sistema').value = sistema;
  document.getElementById('resolucion').value = resolucion;

  document.getElementById("form-reporte").addEventListener("submit", async (e) => {
    e.preventDefault();

    // Mostrar confirmación
    const confirmacion = await Swal.fire({
      title: "¿Estás seguro?",
      text: "¿Deseas enviar este reporte de error?",
      icon: "question",
      showCancelButton: true,
      confirmButtonColor: "#d33",
      cancelButtonColor: "#00304D",
      confirmButtonText: "Sí, enviar",
      cancelButtonText: "Cancelar"
    });

    if (confirmacion.isConfirmed) {
      const formData = new FormData(e.target);

      try {
        const response = await fetch("../../controllers/ErrorController.php", {
          method: "POST",
          body: formData
        });

        const data = await response.json();

        if (data.status === "success") {
  Swal.fire({
    icon: "success",
    title: "Reporte enviado",
    text: data.message,
    confirmButtonColor: "#00304D" // Cambia este color al que prefieras
  }).then(() => {
    location.reload(); // Recarga la página tras cerrar el modal
  });
} else {
          Swal.fire({
            icon: "error",
            title: "Error",
            text: data.message
          });
        }
      } catch (error) {
        Swal.fire({
          icon: "error",
          title: "Error de conexión",
          text: "No se pudo enviar el reporte."
        });
      }
    }
  });
});
