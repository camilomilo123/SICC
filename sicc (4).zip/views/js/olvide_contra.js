$(document).ready(function() {
    $('#formulario-recuperar').submit(function(e) {
        e.preventDefault();

        Swal.fire({
            title: '¿Deseas recibir instrucciones?',
            text: 'Se enviarán instrucciones a tu correo electrónico.',
            icon: 'question',
            showCancelButton: true,
            cancelButtonText: 'Cancelar',
            confirmButtonText: 'Sí, enviar',
            confirmButtonColor: '#008f39',
            cancelButtonColor: '#d33'
        }).then((result) => {
            if (result.isConfirmed) {
                Swal.fire({
                    title: 'Enviando...',
                    allowOutsideClick: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });

                $.ajax({
                    url: '../../controllers/restablecercontroller.php',
                    type: 'POST',
                    data: $('#formulario-recuperar').serialize() + '&recuperar=1',
                    dataType: 'json',
                    success: function(response) {
                        Swal.close();
                        if (response.success) {
                            Swal.fire({
                                icon: 'success',
                                title: 'Correo enviado con éxito',
                                text: response.message,
                                confirmButtonColor: '#008f39'
                            });
                            $('#formulario-recuperar')[0].reset();
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: response.message,
                                confirmButtonColor: '#d33'
                            });
                        }
                    },
                    error: function(xhr, status, error) {
                        Swal.close();
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Ha ocurrido un error en la solicitud.',
                            confirmButtonColor: '#d33'
                        });
                    }
                });
            }
        });
    });
});
