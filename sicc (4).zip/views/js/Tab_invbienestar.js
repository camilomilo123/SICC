$(document).ready(function() {
    var tabla = $('#Tabla_invbienestar').DataTable({
        "ajax": {
            "url": "../../controllers/InvBienController.php",
            "type": "POST",
        },
        "columns": [
            { "data": "id" },
            { "data": "elemento" },
            { "data": "cantidad" },
            { "data": "unidad_medida" },
            { "data": "ubicacion" }
           
        ],
        "paging": true,
        "searching": true,
        "ordering": true,
        "info": true,
        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por página",
            "zeroRecords": "No se encontraron resultados",
            "info": "Mostrando _START_ a _END_ de _TOTAL_ registros",
            "infoEmpty": "No hay registros disponibles",
            "infoFiltered": "(filtrado de _MAX_ registros totales)",
            "search": "Buscar:",
            "paginate": {
                "first": "Primero",
                "last": "Último",
                "next": "Siguiente",
                "previous": "Anterior"
            }
        }
    });

    // Evento para eliminar
    
});

