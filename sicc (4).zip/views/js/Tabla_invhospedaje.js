$(document).ready(function () {
    var tabla = $('#Tabla_invhospedaje').DataTable({
        "ajax": {
            "url": "../../controllers/InvHosController.php",
            "type": "POST",
        },
        "columns": [
            { "data": "id" },
            { "data": "insumo" },
            { "data": "cantidad" },
            { "data": "unidad_medida" },
            { "data": "ubicacion" },
            {
                "data": null,
                "render": function (data) {
                    return `
                        <button style="background-color: #00304D; border: 2px solid #00304D; color: white;" class="btn btn-info btnEditar"
                            data-id="${data.id}"
                            data-insumo="${data.insumo}"
                            data-ubicacion="${data.ubicacion}">
                            <i class="bi bi-pencil-square"></i>
                        </button>
                        <button class="btn btn-danger btnEliminar" data-id="${data.id}">
                            <i class="bi bi-trash-fill"></i>
                        </button>
                    `;
                }
            }
        ],
        "paging": true,
        "searching": true,
        "ordering": true,
        "info": true,
        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por página",
            "zeroRecords": "No se encontraron resultados",
            "info": "Mostrando _START_ a _END_ de _TOTAL_ registros",
            "infoEmpty": "No hay registros disponibles",
            "infoFiltered": "(filtrado de _MAX_ registros totales)",
            "search": "Buscar:",
            "paginate": {
                "first": "Primero",
                "last": "Último",
                "next": "Siguiente",
                "previous": "Anterior"
            }
        }
    });

    // Evento para editar
    $('#Tabla_invhospedaje').on('click', '.btnEditar', function () {
        const id = $(this).data('id');
        const insumo = $(this).data('insumo');
        const ubicacion = $(this).data('ubicacion');

        Swal.fire({
           title: 'Editar Insumo',
            width: '800px',
            html:
              `<div style="display: flex; flex-direction: column; gap: 12px;">
          
                <div style="display: flex; align-items: center; gap: 10px;">
                  <label for="swal-insumo" style="width: 150px;">Nombre del Insumo:</label>
                  <input id="swal-insumo" class="swal2-input" value="${insumo}" readonly style="flex: 1;">
                </div>
          
                
          
                <div style="display: flex; align-items: center; gap: 10px;">
                  <label for="swal-ubicacion" style="width: 150px;">Ubicación:</label>
                  <input id="swal-ubicacion" class="swal2-input" value="${ubicacion}" style="flex: 1;">
                </div>
          
              </div>`,
            focusConfirm: false,
            showCancelButton: true,
            confirmButtonColor: "#39A900",
            confirmButtonText: 'Actualizar',
            cancelButtonColor: "#00304D",
            cancelButtonText: 'Cancelar',
            preConfirm: () => {
                const nombre = document.getElementById('swal-insumo').value;
                const ubicacion = document.getElementById('swal-ubicacion').value;

                if (!nombre || !ubicacion) {
                    Swal.showValidationMessage('Todos los campos son obligatorios');
                    return false;
                }

                return {
                    insumo: id,
                    nombre: nombre,
                    ubicacion: ubicacion,
                    dependencia: 'Hospedaje'
                };
            }
        }).then((result) => {
            if (result.isConfirmed && result.value) {
                $.ajax({
                    url: "../../controllers/editarcontroller.php",
                    type: "POST",
                    data: result.value,
                    dataType: "json",
                    success: function (response) {
                        if (response.status === "success") {
                            Swal.fire({
                                title: '¡Actualizado!',
                                text: response.message,
                                icon: 'success',
                                confirmButtonColor: '#39A900'
                            }).then(() => {
                                tabla.ajax.reload(null, false);
                            });
                        } else {
                            Swal.fire('Error', response.message, 'error');
                        }
                    },
                    error: function (xhr, status, error) {
                        console.log(xhr.responseText);
                        Swal.fire('Error', 'Ocurrió un problema con la petición', 'error');
                    }
                });
            }
        });
    });

    // Evento para eliminar
    $('#Tabla_invhospedaje').on('click', '.btnEliminar', function () {
        let id = $(this).data('id');

        Swal.fire({
            title: '¿Estás seguro?',
            text: "¡Esta acción eliminará el insumo de forma permanente!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#00304D',
            confirmButtonText: 'Sí, eliminar',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: "../../controllers/InvHosController.php",
                    type: "POST",
                    data: { action: "eliminar", id: id },
                    dataType: "json",
                    success: function (response) {
                        if (response.status === "success") {
                            Swal.fire(
                                '¡Eliminado!',
                                response.message,
                                'success'
                            );
                            tabla.ajax.reload(null, false);
                        } else {
                            Swal.fire(
                                'Error',
                                'No se pudo eliminar: ' + response.message,
                                'error'
                            );
                        }
                    },
                    error: function (xhr, status, error) {
                        console.log(xhr.responseText);
                        Swal.fire(
                            'Error',
                            'Ocurrió un problema con la petición: ' + error,
                            'error'
                        );
                    }
                });
            }
        });
    });
});
