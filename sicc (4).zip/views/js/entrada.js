document.getElementById("EntradaForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Evitar el envío automático del formulario

    Swal.fire({
        title: "¿Estás seguro?",
        text: "¿Deseas confirmar la entrada del insumo?",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#39A900",
        confirmButtonText: "Sí, registrar",
        cancelButtonColor: "#00304D",
        cancelButtonText: "Cancelar"
    }).then((result) => {
        if (result.isConfirmed) {
            let formData = new FormData(document.getElementById("EntradaForm"));

            fetch("../../controllers/EntradasController.php", {
                method: "POST",
                body: formData
            })
            .then(response => response.text()) // Capturar la respuesta en texto
            .then(text => {
                console.log("Respuesta cruda del servidor:", text); 
                try {
                    let data = JSON.parse(text); // Intentar convertir a JSON
                    return data;
                } catch (error) {
                    throw new Error("La respuesta del servidor no es un JSON válido.");
                }
            })
            .then(data => {
                if (data.status === "success") {
                    Swal.fire({
                        title: "¡Registrado!",
                        text: data.message,
                        icon: "success",
                        timer: 1500, // Mensaje visible por 1.5 segundos
                        showConfirmButton: false
                    }).then(() => {
                        location.reload(); // Recargar la página después del registro
                    });

                } else {
                    Swal.fire("Error", data.message, "error");
                }
            })
            .catch(error => {
                Swal.fire("Error", "Hubo un problema con el registro.", "error");
                console.error("Error detectado:", error);
            });
        }
    });
});

