
$(document).ready(function () {
    const tabla = $('#Tabla_inventario').DataTable({
        "ajax": {
            "url": "../../controllers/prestamostabla.php",
            "type": "GET",
            "dataSrc": function (json) {
                // Filtrar solo los que tienen dependencia "Laboratorio"
                return json.filter(function (item) {
                    return item.dependencia === "Deportes";
                });
            }
        },
        "columns": [
            { "data": "fecha" },
            { "data": "insumo" },
            { "data": "dependencia" },
            { "data": "responsable" },
            { "data": "prestado_a" },
            { "data": "cantidad_prestada" },
            { "data": "unidad_medida" },
            {
                "data": null,
                "render": function (data, type, row) {
                    return `
                        <button class="btn btn-success btn-sm confirmar-devolucion" data-id="${row.id}">
                            <i class="bi bi-box-arrow-in-left"></i> Devolver
                        </button>`;
                }
            }
        ],
        "order": [[0, "desc"]],
        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por página",
            "zeroRecords": "No se encontraron resultados",
            "info": "Mostrando _START_ a _END_ de _TOTAL_ registros",
            "infoEmpty": "No hay registros disponibles",
            "infoFiltered": "(filtrado de _MAX_ registros totales)",
            "search": "Buscar:",
            "paginate": {
                "first": "Primero",
                "last": "Último",
                "next": "Siguiente",
                "previous": "Anterior"
            }
        }
    });

   
});

$('#Tabla_inventario tbody').on('click', '.confirmar-devolucion', function () {
    const id = $(this).data('id');

    Swal.fire({
        title: '¿Confirmar devolución?',
        text: "Esta acción eliminará el registro del préstamo.",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#00843D', // Verde SENA
        cancelButtonColor: '#d33',
        confirmButtonText: 'Sí, devolver',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: '../../controllers/eliminar_prestamo.php',
                method: 'POST',
                data: { id: id },
                success: function (response) {
                    Swal.fire({
                        title: '¡Devuelto!',
                        text: 'El préstamo fue reintegrado al inventario.',
                        icon: 'success',
                        confirmButtonColor: '#00843D'
                    }).then(() => {
                        location.reload(); // Recargar la página después de dar OK
                    });
                },
                error: function () {
                    Swal.fire({
                        title: 'Error',
                        text: 'No se pudo eliminar.',
                        icon: 'error',
                        confirmButtonColor: '#d33'
                    });
                }
            });
        }
    });
});
