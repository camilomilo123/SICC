$(document).ready(function () {
    $('#Tabla_Errores').DataTable({
        "ajax": {
            "url": "../../controllers/ObtenerErrores.php",
            "type": "GET",
            "dataSrc": ""
        },
        "columns": [
            { "data": "usuario" },
            { "data": "correo" },
            { "data": "rol" },
            { "data": "mensaje" },
            { "data": "nivel" },
            {
                "data": "imagen",
                "render": function (data) {
                    if (data) {
                        return `<a href="../../views/img/error/${data}" target="_blank">
                                    <i class="fas fa-image fa-lg text-info"></i> ver
                                </a>`;
                    } else {
                        return '<span class="text-muted">Sin imagen</span>';
                    }
                }
            },
            { "data": "fecha" },
            {
                "data": "solucionado",
                "render": function (data, type, row) {
                    const checked = data == 1 ? 'checked' : '';
                    return `
                        <input type="checkbox" class="marcar-solucionado" data-id="${row.id}" ${checked}>
                    `;
                },
                "orderable": false,
                "searchable": false
            }
        ],
        "paging": true,
        "searching": true,
        "ordering": true,
        "info": true,
        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por página",
            "zeroRecords": "No se encontraron resultados",
            "info": "Mostrando _START_ a _END_ de _TOTAL_ registros",
            "infoEmpty": "No hay registros disponibles",
            "infoFiltered": "(filtrado de _MAX_ registros totales)",
            "search": "Buscar:",
            "paginate": {
                "first": "Primero",
                "last": "Último",
                "next": "Siguiente",
                "previous": "Anterior"
            }
        }
    });

    // Manejar clic en el checkbox para actualizar el estado
    $('#Tabla_Errores').on('change', '.marcar-solucionado', function () {
        const checkbox = $(this);
        const id = checkbox.data('id');
    
        // Si ya está marcado (solucionado), impedir desmarcar
        if (checkbox.prop('checked')) {
            Swal.fire({
                title: '¿Marcar como solucionado?',
                text: "No podrás deshacer esta acción.",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#00304D',
                confirmButtonText: 'Sí, marcar',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: '../../controllers/ActualizarSolucionado.php',
                        type: 'POST',
                        data: { id, solucionado: 1 },
                        success: function (response) {
                            Swal.fire({
                                title: 'Actualizado',
                                text: 'El reporte fue marcado como solucionado.',
                                icon: 'success',
                                confirmButtonColor: '#00304D' // color personalizado para el botón OK
                            });
                            
    
                            // Deshabilitar para evitar cambios futuros
                            checkbox.prop('disabled', true);
                        },
                        error: function () {
                            Swal.fire(
                                'Error',
                                'No se pudo actualizar el estado.',
                                'error'
                            );
                            // Revertir checkbox en caso de error
                            checkbox.prop('checked', false);
                        }
                    });
                } else {
                    // Si se cancela, volver al estado anterior
                    checkbox.prop('checked', false);
                }
            });
        } else {
            // Impedir desmarcar si ya estaba marcado
            checkbox.prop('checked', true);
        }
    });
});


