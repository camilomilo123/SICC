document.addEventListener('DOMContentLoaded', async () => {
    try {
        const response = await fetch('../../controllers/ContarErroresNoSolucionados.php');
        const data = await response.json();

        const icono = document.getElementById('iconoErrores');
        const contador = document.getElementById('contadorErrores');
        const contenedor = document.getElementById('iconoErroresLink');

        if (data.total > 0) {
            contador.textContent = data.total;
            contador.classList.remove('d-none');
            contenedor.classList.remove('d-none');
        } else {
            contenedor.classList.add('d-none');
        }
    } catch (error) {
        console.error('Error al cargar notificaciones de errores:', error);
    }
});
