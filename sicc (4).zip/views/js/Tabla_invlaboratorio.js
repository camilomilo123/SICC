$(document).ready(function() {
    let tabla = $('#Tabla_invlaboratorio').DataTable({
        "ajax": {
            "url": "../../controllers/InvLabController.php",
            "type": "POST",
            "dataSrc": "data"
        },
        "columns": [
            { "data": "id" },
            { "data": "reactivo" },
            { "data": "formula" },
            { "data": "estado" },
            { "data": "codigo_almacenamiento" },
            { "data": "cantidad" },
            { "data": "unidad_medida" },
            { "data": "fecha_vencimiento" },
            { "data": "lote" },
            { "data": "ubicacion" },
            {
                "data": "id",
                    "render": function(data,  type, row) {
                        return `
                            <button class="btn btn-danger btnEliminar" data-id="${data}"><i class="bi bi-trash-fill"></i></button>
                            <button style="background-color: #00304D; border: 2px solid #00304D; color: white;"  class="btn btn-info btnEditar" data-id="${data}" data-reactivo="${row.reactivo}" data-formula="${row.formula}" data-estado="${row.estado}" data-codigo_almacenamiento="${row.codigo_almacenamiento}"  data-fecha_vencimiento="${row.fecha_vencimiento}" data-lote="${row.lote}" data-ubicacion="${row.ubicacion}"><i class="bi bi-pencil-square"></i></button>
                       `;
                }
            }
        ],
        "order": [[0, "asc"]], // Ordena por "reactivo" alfabéticamente
        "paging": true,
        "searching": true,
        "ordering": true,
        "info": true,
        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por página",
            "zeroRecords": "No se encontraron resultados",
            "info": "Mostrando _START_ a _END_ de _TOTAL_ registros",
            "infoEmpty": "No hay registros disponibles",
            "infoFiltered": "(filtrado de _MAX_ registros totales)",
            "search": "Buscar:",
            "paginate": {
                "first": "Primero",
                "last": "Último",
                "next": "Siguiente",
                "previous": "Anterior"
            }
        },
        dom: 'lfrtipB',
        buttons: [
            {
                extend: 'excelHtml5',
                title: 'Inventario Laboraorio',
                exportOptions: {
                    columns: ':visible:not(:last-child)'
                },
                className: 'd-none' // Esto oculta el botón original
            }
        ]
    });

    // Cuando se hace click en el botón HTML
    $('#btnExportarExcel').on('click', function() {
        tabla.button('.buttons-excel').trigger();
    });



    // Al hacer click en el botón del HTML
    $('#btnExportarExcel').on('click', function() {
        // Creamos un botón de exportar a Excel "virtualmente" y lo disparamos
        tabla.button().add(0, {
            extend: 'excelHtml5',
            title: 'Inventario Laboraorio',
            exportOptions: {
                columns: ':visible:not(:last-child)'
            }
        }).trigger();
        
        // Opcional: eliminar el botón extra después de usarlo para no crear muchos botones ocultos
        tabla.buttons(0).remove();
    });

    $('#Tabla_invlaboratorio').on('click', '.btnEditar', function () {
        const id = $(this).data('id');
        const reactivo = $(this).data('reactivo');
        const formula = $(this).data('formula');
        const estado = $(this).data('estado');
        const codigo = $(this).data('codigo_almacenamiento');
        const fecha = $(this).data('fecha_vencimiento');
        const lote = $(this).data('lote');
        const ubicacion = $(this).data('ubicacion');
    
        Swal.fire({
            title: 'Editar Insumo',
            width: '800px',
            html:
              `<div style="display: flex; flex-direction: column; gap: 12px;">
          
                <div style="display: flex; align-items: center; gap: 10px;">
                  <label for="swal-reactivo" style="width: 150px;">Nombre del Insumo:</label>
                  <input id="swal-reactivo" class="swal2-input" value="${reactivo}" readonly style="flex: 1;">
                </div>
          
                <div style="display: flex; align-items: center; gap: 10px;">
                  <label for="swal-formula" style="width: 150px;">Fórmula:</label>
                  <input id="swal-formula" class="swal2-input" value="${formula}" readonly style="flex: 1;">
                </div>
          
                <div style="display: flex; align-items: center; gap: 10px;">
                  <label for="swal-estado" style="width: 150px;">Estado:</label>
                  <input id="swal-estado" class="swal2-input" value="${estado}" readonly style="flex: 1;">
                </div>
          
                <div style="display: flex; align-items: center; gap: 10px;">
                  <label for="swal-codigo" style="width: 150px;">Código:</label>
                  <input id="swal-codigo" class="swal2-input" value="${codigo}" readonly style="flex: 1;">
                </div>
          
                <div style="display: flex; align-items: center; gap: 10px;">
                  <label for="swal-fecha" style="width: 150px;">Fecha:</label>
                  <input id="swal-fecha" class="swal2-input" type="date" value="${fecha}" readonly style="flex: 1;">
                </div>
          
                <div style="display: flex; align-items: center; gap: 10px;">
                  <label for="swal-lote" style="width: 150px;">Lote:</label>
                  <input id="swal-lote" class="swal2-input" value="${lote}" readonly style="flex: 1;">
                </div>
          
                <div style="display: flex; align-items: center; gap: 10px;">
                  <label for="swal-ubicacion" style="width: 150px;">Ubicación:</label>
                  <input id="swal-ubicacion" class="swal2-input" value="${ubicacion}" style="flex: 1;">
                </div>
          
              </div>`,
            focusConfirm: false,
            showCancelButton: true,
            confirmButtonColor: "#39A900",
            confirmButtonText: 'Actualizar',
            cancelButtonColor: "#00304D",
            cancelButtonText: 'Cancelar',
            preConfirm: () => {
                const nombre = document.getElementById('swal-reactivo').value;
                const formula = document.getElementById('swal-formula').value;
                const estado = document.getElementById('swal-estado').value;
                const codigo = document.getElementById('swal-codigo').value;
                const fecha = document.getElementById('swal-fecha').value;
                const lote = document.getElementById('swal-lote').value;
                const ubicacion = document.getElementById('swal-ubicacion').value;
    
                if (!nombre || !estado || !codigo) {
                    Swal.showValidationMessage('Los campos con * son obligatorios');
                    return false;
                }
    
                return {
                    insumo: id,
                    nombre: nombre,
                    formula: formula,
                    estado: estado,
                    codigo: codigo,
                    fecha_vencimiento: fecha,
                    lote: lote,
                    ubicacion: ubicacion,
                    dependencia: 'Laboratorio'
                };
            }
        }).then((result) => {
            if (result.isConfirmed && result.value) {
                $.ajax({
                    url: "../../controllers/editarcontroller.php",
                    type: "POST",
                    data: result.value,
                    dataType: "json",
                    success: function (response) {
                        if (response.status === "success") {
                            Swal.fire({
                                title: '¡Actualizado!',
                                text: response.message,
                                icon: 'success',
                                confirmButtonColor: '#39A900'
                            }).then(() => {
                                location.reload();
                            });
                        } else {
                            Swal.fire('Error', response.message, 'error');
                        }
                    },
                    error: function (xhr, status, error) {
                        console.log(xhr.responseText);
                        Swal.fire('Error', 'Ocurrió un problema con la petición', 'error');
                    }
                });
            }
        });
    });

    // Evento para eliminar
    $('#Tabla_invlaboratorio').on('click', '.btnEliminar', function() {
        let id = $(this).data('id');
    
        Swal.fire({
            title: '¿Estás seguro?',
            text: "¡Esta acción eliminará el insumo de forma permanente!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#00304D',
            confirmButtonText: 'Sí, eliminar',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: "../../controllers/InvLabController.php",
                    type: "POST",
                    data: { action: "eliminar", id: id },
                    dataType: "json",
                    success: function(response) {
                        if (response.status === "success") {
                            Swal.fire({
                                title: '¡Eliminado!',
                                text: response.message,
                                icon: 'success',
                                confirmButtonColor: '#28a745' // Color verde para el botón de confirmación
                            }).then(() => {
                                tabla.ajax.reload(null, false); // Recargar sin perder paginación
                            });
                        } else {
                            Swal.fire(
                                'Error',
                                'No se pudo eliminar: ' + response.message,
                                'error'
                            );
                        }
                    },
                    error: function(xhr, status, error) {
                        console.log(xhr.responseText);
                        Swal.fire(
                            'Error',
                            'Ocurrió un problema con la petición: ' + error,
                            'error'
                        );
                    }
                });
            }
        });
    });
});


