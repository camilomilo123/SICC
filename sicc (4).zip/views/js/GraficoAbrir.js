document.addEventListener("DOMContentLoaded", function () {
    const verMasBtn = document.getElementById("verMasBtn");
    const contenedorExtraGraficos = document.getElementById("contenedorExtraGraficos");

    verMasBtn.addEventListener("click", function () {
        if (contenedorExtraGraficos.style.opacity === "0" || contenedorExtraGraficos.style.visibility === "hidden") {
            // Calcular altura real antes de mostrarlo
            contenedorExtraGraficos.style.height = "auto";
            let height = contenedorExtraGraficos.scrollHeight + "px";

            contenedorExtraGraficos.style.height = "0"; // Reiniciar altura antes de animar
            contenedorExtraGraficos.style.visibility = "visible";

            setTimeout(() => {
                contenedorExtraGraficos.style.opacity = "1";
                contenedorExtraGraficos.style.height = height; // Aplicar altura real para animación
            }, 10);

            verMasBtn.innerHTML = "Ver menos gráficos <i class='bi bi-caret-up-fill'></i>";
        } else {
            // Ocultar con animación
            contenedorExtraGraficos.style.opacity = "0";
            contenedorExtraGraficos.style.height = "0";

            setTimeout(() => {
                contenedorExtraGraficos.style.visibility = "hidden";
            }, 400); // Esperar la animación antes de ocultarlo completamente

            verMasBtn.innerHTML = "Ver más gráficos <i class='bi bi-caret-down-fill'></i>";
        }
    });
});