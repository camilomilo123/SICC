<div class="wrapper ">
   
    
    <aside id="sidebar" class="expand">
        <div class="d-flex">
            <button class="toggle-btn" type="button">
                <i class="bi bi-hexagon-fill"></i>
            </button>
            <div class="sidebar-logo">
                <a href="#" style="font-size: 25px;">SICC</a>
            </div>
        </div>

        <ul class="sidebar-nav">
            <li class="sidebar-item">
                <a href="administrador.php" class="sidebar-link">
                    <i class="bi bi-house-door-fill"></i>
                    <span>Inicio</span>
                </a>
            </li>

            <li class="sidebar-item">
                <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
                    data-bs-target="#auth" aria-expanded="false" aria-controls="auth">

                    <i class="bi bi-grid-fill"></i>
                    <span> Dependencias</span>
                </a>

                <ul id="auth" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">

                    <!-- Laboratorio -->
                    <li class="sidebar-item">
                        <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
                            data-bs-target="#lab-options" aria-expanded="false" aria-controls="lab-options">
                            <i class="bi bi-thermometer-high"></i>Laboratorio
                        </a>
                        <ul id="lab-options" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#auth">
                            <li class="sidebar-item">
                                <a href="Inv_lab.php" class="sidebar-link"><i class="bi bi-clipboard-fill"></i>Inventario</a>
                            </li>
                            <li class="sidebar-item">
                                <a href="Lab_admin_entrada.php" class="sidebar-link"><i class="bi bi-caret-up"></i>Entradas</a>
                            </li>
                            <li class="sidebar-item">
                                <a href="Lab_admin_salida.php" class="sidebar-link"> <i class="bi bi-caret-down"></i>Salidas</a>
                            </li>
                        </ul>
                    </li>

                    <!-- Deportes -->
                    <li class="sidebar-item">
                        <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
                            data-bs-target="#deportes-options" aria-expanded="false" aria-controls="deportes-options">
                            <i class="bi bi-trophy-fill"></i>Deportes
                        </a>
                        <ul id="deportes-options" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#auth">
                            <li class="sidebar-item">
                                <a href="Inv_dep.php" class="sidebar-link"><i class="bi bi-clipboard-fill"></i>Inventario</a>
                            </li>
                            <li class="sidebar-item">
                                <a href="Dep_admin_entrada.php" class="sidebar-link"><i class="bi bi-caret-up"></i>Entradas</a>
                            </li>
                            <li class="sidebar-item">
                                <a href="Dep_admin_salida.php" class="sidebar-link"> <i class="bi bi-caret-down"></i>Salidas</a>
                            </li>
                        </ul>
                    </li>

                    <!-- Bienestar -->
                    <li class="sidebar-item">
                        <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
                            data-bs-target="#bienestar-options" aria-expanded="false" aria-controls="bienestar-options">
                            <i class="bi bi-person-arms-up"></i>Bienestar
                        </a>
                        <ul id="bienestar-options" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#auth">
                            <li class="sidebar-item">
                                <a href="Inv_bien.php" class="sidebar-link"><i class="bi bi-clipboard-fill"></i>Inventario</a>
                            </li>
                            <li class="sidebar-item">
                                <a href="Biene_admin_entradas.php" class="sidebar-link"><i class="bi bi-caret-up"></i>Entradas</a>
                            </li>
                            <li class="sidebar-item">
                                <a href="Biene_admin_salida.php" class="sidebar-link"> <i class="bi bi-caret-down"></i>Salidas</a>
                            </li>
                        </ul>
                    </li>


                    <!-- Hospedaje -->
                    <li class="sidebar-item">
                        <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
                            data-bs-target="#hospedaje-options" aria-expanded="false" aria-controls="hospedaje-options">
                            <i class="bi bi-buildings-fill"></i>Hospedaje
                        </a>
                        <ul id="hospedaje-options" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#auth">
                            <li class="sidebar-item">
                                <a href="Inv_hos.php" class="sidebar-link"><i class="bi bi-clipboard-fill"></i>Inventario</a>
                            </li>
                            <li class="sidebar-item">
                                <a href="Hospe_admin_entradas.php" class="sidebar-link"><i class="bi bi-caret-up"></i>Entradas</a>
                            </li>
                            <li class="sidebar-item">
                                <a href="Hospe_admin_salida.php" class="sidebar-link"> <i class="bi bi-caret-down"></i>Salidas</a>
                            </li>
                        </ul>
                    </li>
                </ul>


            </li>


            <li class="sidebar-item">
                <a href="usuarios.php" class="sidebar-link">
                    <i class="bi bi-people-fill"></i>
                    <span>Usuarios</span>
                </a>
            </li>

            <li class="sidebar-item">
                <a href="ReportarErrores.php" class="sidebar-link">
                    <i class="bi bi-exclamation-circle-fill"></i>
                    <span>Reportar errores</span>
                </a>
            </li>



            <div class="sidebar-item">
                <a href="#" class="sidebar-link" id="logout">
                    <i class="lni lni-exit"></i>
                    <span>Salir</span>
                </a>
            </div>
    </aside>
</div>
<script src="../js/cerrarsesion.js"></script>