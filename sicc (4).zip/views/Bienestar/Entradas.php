<?php
session_start();
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");



if (!isset($_SESSION['correo'])) {
    header("Location: ../../index.php");
    exit();
}

if ($_SESSION['role_id'] != 4) {
    header("Location: /SICC/403.php");
    exit();
}

$username = isset($_SESSION['username']) ? $_SESSION['username'] : 'Usuario';




// Si el usuario es admin, continúa con la carga del contenido
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SICC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="icon" href="../../views/icons/hexagon-fill.svg" type="image/x-icon">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.2/css/buttons.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>




    <link href="https://cdn.lineicons.com/4.0/lineicons.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/administrador.css">
    <link rel="stylesheet" href="../css/Notificaciones.css">
</head>

<body>

    <div class="wrapper">

        <aside id="sidebar" class="expand">
            <div class="d-flex">
                <button class="toggle-btn" type="button">
                    <i class="bi bi-hexagon-fill"></i>
                </button>
                <div class="sidebar-logo">
                    <a href="#" style="font-size: 25px;">Bienestar</a>
                </div>
            </div>

            <ul class="sidebar-nav">
                <li class="sidebar-item">
                    <a href="bienestar.php" class="sidebar-link">
                        <i class="bi bi-house-door-fill"></i>
                        <span>Inicio</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse" data-bs-target="#lab-options">
                        <i class="bi bi-grid-fill"></i> Operaciones</a>

                    <ul id="lab-options" class="sidebar-dropdown list-unstyled collapse">
                        <li class="sidebar-item">
                            <a href="Inventario.php" class="sidebar-link"><i class="bi bi-clipboard-fill"></i>Inventario</a>
                        </li>
                        <li class="sidebar-item">
                            <a href="Entradas.php" class="sidebar-link">
                                <i class="bi bi-caret-up"></i> Entradas
                            </a>
                        </li>
                        
                        <li class="sidebar-item">
                            <a href="prestamos.php" class="sidebar-link">
                                <i class="bi bi-journal-arrow-down"></i> Prestamos
                            </a>
                        </li>


                        <li class="sidebar-item">
                            <a href="Salidas.php" class="sidebar-link">
                                <i class="bi bi-caret-down"></i> Salidas
                            </a>
                        </li>
                    </ul>
                </li>
                
                

                <li class="sidebar-item">
                    <a href="ReporteErrores.php" class="sidebar-link">
                        <i class="bi bi-exclamation-circle-fill"></i>
                        <span>Reportar errores</span>
                    </a>
                </li>


                <li class="sidebar-item">
                    <a href="#" class="sidebar-link" id="logout">
                        <i class="lni lni-exit"></i>
                        <span>Salir</span>
                    </a>
                </li>
            </ul>

            <script src="../js/cerrarsesion.js"></script>

        </aside>


        <div class="main p-3 bold">
            <div class="row page-titles mx-0">
                <div class="col-sm-6 p-md-0">
                    <div class="welcome-text d-flex align-items-center">
                        <img src="../img/sena.png" style="width: 60px; height: auto;" alt="" class="me-3">
                        <div>
                            <h4 style="color: black;" class="bold" st>Bienvenido a <strong class="bold" style="color: green;">sistema de consumo controlado</strong></h4>
                            <p class="mb-0">¡La solución inteligente para gestionar entradas y salidas!</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                    <a class="nav-link position-relative" href="#" id="notificacionesDropdown" role="button" data-bs-toggle="dropdown">
                        <i class="bi bi-bell-fill" style="font-size: 25px; padding-right: 10px;"></i>
                        <span id="notificacionesContador" class="position-absolute top-3 start-10 translate-middle badge rounded-pill bg-danger d-none">
                            0
                        </span>
                    </a>
                    <ul id="notificacionesLista" class="dropdown-menu dropdown-menu-end">
                        <li>
                            <p class="dropdown-item text-center">No hay notificaciones</p>
                        </li>
                    </ul>
                    <script src="../js/Notificaciones/Bienestar.js"></script>




                    <ol class="breadcrumb bold" style="font-size:20px;">
                        <?php echo htmlspecialchars($_SESSION['username']); ?>
                        <i class="bi bi-person-fill"></i>
                    </ol>
                </div>
            </div>
            <script src="../js/avisos/Aviso.js"></script>
            <div id="AlertaErrror" class="alert alert-info border-start py-1 px-2" role="alert">

                <h5 class="alert-heading mb-0">
                    <div class="text-decoration-none text-dark d-flex justify-content-between align-items-center clickable" onclick="toggleCollapse()">
                        <span id="textoAclaracion"><i class="fas fa-info-circle"></i> Aclaración importante</span>
                        <i class="fas fa-chevron-down" id="toggleIcon"></i>
                    </div>
                </h5>
                <div class="collapse mt-3" id="infoCollapse">
                    <hr>
                    <p class="mb-0 text-justify">
                        En esta sección se visualizarán todas las entradas de insumos realizadas por el administrador. Estas entradas se añadirán automáticamente al inventario y quedarán registradas en una tabla que permitirá llevar un control claro y detallado de los movimientos de ingreso.
                    </p>
                    <p class="mb-0 mt-2 text-justify">
                        La tabla mostrará la siguiente información: fecha de la entrada, dependencia a la que se destina el insumo, responsable del registro, nombre del insumo, cantidad anterior al ingreso, cantidad ingresada, stock total tras la entrada y unidad de medida. Esta información es esencial para mantener un control preciso del inventario.
                    </p>
                    <p class="mb-0 mt-2 text-justify">
                        Cada registro reflejará únicamente los movimientos de entrada efectuados por el administrador, permitiendo así una visualización clara y ordenada de los insumos agregados al inventario.
                    </p>

                </div>
            </div>
            <br>


            <div>


                <div>

                    <h2><strong style="color: green;">Entradas de Bienestar</strong></h2>
                    <br>
                    <table id="Tabla_inventario" class="table table-striped">
                        <thead class="table-dark">
                            <tr>
                                <th>Fecha</th>
                                <th>Dependencia</th>
                                <th>Responsable</th>
                                <th>Insumo</th>
                                <th>Cantidad Anterior</th>
                                <th>Cantidad Ingresada</th>
                                <th>Cantidad Total</th>
                                <th>Unidad Medida</th>
                            </tr>
                        </thead>
                        <tbody>
                            <script src="../js/TablaEntradas/Bienestar.js"></script>
                            <!-- Los datos se cargarán dinámicamente con DataTables -->
                        </tbody>
                    </table>
                    <br>
                    <br>

                    <!-- DataTables Scripts -->
                    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
                    <script src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>
                    <script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.html5.min.js"></script>
                    <script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.print.min.js"></script>

                </div>
            </div>
        </div>

        <script src="../js/selector.js"></script>
        <script src="../js/Graficos/Deportes.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>



</body>


</html>