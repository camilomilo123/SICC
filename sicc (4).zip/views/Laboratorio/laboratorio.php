<?php
session_start();
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");



if (!isset($_SESSION['correo'])) {
    header("Location: ../../index.php");
    exit();
}

if ($_SESSION['role_id'] != 2) {
    header("Location: ../../403.php");
    exit();
}

$username = isset($_SESSION['username']) ? $_SESSION['username'] : 'Usuario';




// Si el usuario es admin, continúa con la carga del contenido
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SICC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="icon" href="../../views/icons/hexagon-fill.svg" type="image/x-icon">



    <link href="https://cdn.lineicons.com/4.0/lineicons.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/administrador.css">
    <link rel="stylesheet" href="../css/Notificaciones.css">
</head>

<body>

    <div class="wrapper">

        <aside id="sidebar" class="expand">
            <div class="d-flex">
                <button class="toggle-btn" type="button">
                    <i class="bi bi-hexagon-fill"></i>
                </button>
                <div class="sidebar-logo">
                    <a href="#" style="font-size: 25px;">Laboratorio</a>
                </div>
            </div>

            <ul class="sidebar-nav">
                <li class="sidebar-item">
                    <a href="laboratorio.php" class="sidebar-link">
                        <i class="bi bi-house-door-fill"></i>
                        <span>Inicio</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse" data-bs-target="#lab-options">
                        <i class="bi bi-grid-fill"></i> Operaciones</a>

                    <ul id="lab-options" class="sidebar-dropdown list-unstyled collapse">
                        <li class="sidebar-item">
                            <a href="inventario.php" class="sidebar-link"><i class="bi bi-clipboard-fill"></i>Inventario</a>
                        </li>
                        <li class="sidebar-item">
                            <a href="laboratorio_entradas.php" class="sidebar-link">
                                <i class="bi bi-caret-up"></i> Entradas
                            </a>
                        </li>


                        <li class="sidebar-item">
                            <a href="laboratorio_salidas.php" class="sidebar-link">
                                <i class="bi bi-caret-down"></i> Salidas
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="sidebar-item">
                    <a href="ReporteErroresLab.php" class="sidebar-link">
                        <i class="bi bi-exclamation-circle-fill"></i>
                        <span>Reportar errores</span>
                    </a>
                </li>


                <li class="sidebar-item">
                    <a href="#" class="sidebar-link" id="logout">
                        <i class="lni lni-exit"></i>
                        <span>Salir</span>
                    </a>
                </li>
            </ul>

            <script src="../js/cerrarsesion.js"></script>

        </aside>


        <div class="main p-3 bold">
            <div class="row page-titles mx-0">
                <div class="col-sm-6 p-md-0">
                    <div class="welcome-text d-flex align-items-center">
                        <img src="../img/sena.png" style="width: 60px; height: auto;" alt="" class="me-3">
                        <div>
                            <h4 style="color: black;" class="bold" st>Bienvenido a <strong class="bold" style="color: green;">sistema de consumo controlado</strong></h4>
                            <p class="mb-0">¡La solución inteligente para gestionar entradas y salidas!</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                    <a class="nav-link position-relative" href="#" id="notificacionesDropdown" role="button" data-bs-toggle="dropdown">
                        <i class="bi bi-bell-fill" style="font-size: 25px; padding-right: 10px;"></i>
                        <span id="notificacionesContador" class="position-absolute top-3 start-10 translate-middle badge rounded-pill bg-danger d-none">
                            0
                        </span>
                    </a>
                    <ul id="notificacionesLista" class="dropdown-menu dropdown-menu-end">
                        <li>
                            <p class="dropdown-item text-center">No hay notificaciones</p>
                        </li>
                    </ul>
                    <script src="../js/NotificacionesLab.js"></script>




                    <ol class="breadcrumb bold" style="font-size:20px;">
                        <?php echo htmlspecialchars($_SESSION['username']); ?>
                        <i class="bi bi-person-fill"></i>
                    </ol>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3 col-sm-6">
                    <div class="card">
                        <div class="stat-widget-one card-body">
                            <div class="stat-icon d-inline-block">
                                <i class="bi bi-arrow-up-circle-fill text-success border-success"></i>
                            </div>
                            <div class="stat-content d-inline-block">
                                <div class="stat-text">Entradas</div>
                                <div class="stat-digit" id="totalEntradas">0</div>
                                <script src="../js/ContarEntradaLab.js"></script>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="card">
                        <div class="stat-widget-one card-body">
                            <div class="stat-icon d-inline-block">
                                <i class="bi bi-arrow-down-circle-fill text-danger border-danger"></i>
                            </div>
                            <div class="stat-content d-inline-block">
                                <div class="stat-text">Salidas</div>
                                <div class="stat-digit" id="totalSalidas">0</div>
                                <script src="../js/ContarSalidaLab.js"></script>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="card">
                        <div class="stat-widget-one card-body">
                            <div class="stat-icon d-inline-block">
                                <i class="bi bi-box-fill text-muted "></i>
                            </div>
                            <div class="stat-content d-inline-block">
                                <div class="stat-text">Insumos</div>
                                <div class="stat-digit" id="TotalInsumosLab">0</div>
                                <script src="../js/ContarInsumosLab.js"></script>


                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="card">
                        <div class="stat-widget-one card-body">
                            <div class="stat-icon d-inline-block">
                                <i class="bi bi-people-fill"></i>
                            </div>
                            <div class="stat-content d-inline-block">
                                <div class="stat-text">Usuarios</div>
                                <div class="stat-digit" id="TotalUsuariosLab">0</div>
                                <script src="../js/contarUsuarioslab.js"></script>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">

                <div class="col-lg-8">
                    <div class="card">
                        <div class="card-header">
                            <h4 style="color: black;" class="card-title bold">Cantidad de insumos Laboratorio</h4>
                        </div>
                        <div class="card-body">
                            <canvas id="myChart"></canvas>
                            <br>
                            <button id="prevPageReactivos" class="btn btn-primary btn-sm">Anterior</button>
                            <button id="nextPageReactivos" class="btn btn-primary btn-sm">Siguiente</button>
                            <script src="../js/Graficos/Laboratorio.js"></script>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 w-100 h-100">
                    <div class="card">
                        <div id="GraficoEspacioCircular" class="card-body">
                            <h4 style="color: black;" class="card-title bold">Laboratorio</h4>
                            <canvas id="graficoEntradasSalidas"></canvas>
                            <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
                            <script src="../js/EntradasSalidasGraficos/Laboratorio.js"></script>
                        </div>
                    </div>
                </div>
            </div>




            <!-- Contenedor oculto de los gráficos adicionales -->



            <div class="row"> <!-- Contenedor de fila -->

                <div class="col-xl-4 col-lg-6 col-xxl-6 col-md-6">
                    <br>
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title bold">Roles del sistema </h4>
                        </div>
                        <div class="card-body">
                            <div class="recent-comment m-t-15">
                                <div class="media">
                                    <div class="media-left">
                                        <a href="#"><img class="media-object mr-3" src="../img/administrador.png" alt="..."></a>
                                    </div>
                                    <div class="media-body">
                                        <h4 class="media-heading ">Jefe de almacen</h4>
                                        <p>El rol de administrador permite gestionar las entradas de insumos y generar reportes detallados sobre estos movimientos.</p>

                                    </div>
                                </div>


                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6 col-xxl-6 col-md-6">
                    <br>
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title bold">Roles del sistema </h4>
                        </div>
                        <div class="card-body">
                            <div class="recent-comment m-t-15">

                                <div class="media">
                                    <div class="media-left">
                                        <a href="#"><img class="media-object mr-3" src="../img/grupo.png" alt="..."></a>
                                    </div>
                                    <div class="media-body">
                                        <h4 class="media-heading ">Encargado Dependencia</h4>
                                        <p>El encargado de dependencia puede gestionar las salidas de insumos, visualizar su inventario y consultar las entradas registradas.</p>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>



</body>

</html>