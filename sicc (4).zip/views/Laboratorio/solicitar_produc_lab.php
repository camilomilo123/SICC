<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SICC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="icon" href="../../views/icons/hexagon-fill.svg" type="image/x-icon">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.2/css/buttons.dataTables.min.css">
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <link href="https://cdn.lineicons.com/4.0/lineicons.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/administrador.css">
</head>

<body >
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-6 col-md-8">
            <div class="card border-0 shadow-lg rounded-4">
                <div class="card-header text-white text-center" style="background-color: #006341; border-top-left-radius: 10px; border-top-right-radius: 10px;">
                    <h4 class="mb-0">📦 Solicitar Reabastecimiento de Inventario</h4>
                </div>
                <div class="card-body">
                    <form id="formulario" action="../../controllers/solicitar_produc_manu.php" method="POST">

                        <!-- Campo para seleccionar el elemento -->
                        <div class="mb-4">
                            <label for="buscar_insumo" class="form-label fs-6 fw-medium">Elemento Requerido</label>
                            <div class="dropdown">
                                <input type="text" id="buscar_insumo" class="form-control form-control-lg" name="insumo_nombre" placeholder="Escribe para buscar..." required>
                                <ul id="lista_insumo" class="dropdown-menu w-100"></ul>
                            </div>
                            <input type="hidden" id="insumo" name="insumo">
                        </div>

                        <!-- Fila para cantidad y unidad -->
                        <div class="row">
                            <div class="col-md-6 mb-4">
                                <label for="cantidad" class="form-label fs-6 fw-medium">Cantidad Solicitada</label>
                                <input type="number" id="cantidad" name="cantidad" class="form-control form-control-lg text-center" required step="any" min="0" style="font-size: 1rem;">
                            </div>

                            <div class="col-md-6 mb-4">
                                <label for="unidad_medida" class="form-label fs-6 fw-medium">Unidad de Medida</label>
                                <select id="unidad_medida" name="unidad_medida" class="form-control form-control-lg" required">
                                    <option value="" selected disabled>Seleccione una unidad</option>
                                    <option value="litros">Litros</option>
                                    <option value="mililitros">Mililitros</option>
                                    <option value="kilogramos">Kilogramos</option>
                                    <option value="libras">Libras</option>
                                    <option value="gramos">Gramos</option>
                                    <option value="miligramos">Miligramos</option>
                                    <option value="unidad">Unidad</option>
                                </select>
                            </div>
                        </div>

                        <!-- Campo oculto para la dependencia -->
                        <div class="mb-4">
                            <label for="dependencia" class="form-label fs-6 fw-medium">Dependencia</label>
                            <input type="text" id="dependencia" name="dependencia" class="form-control form-control-lg text-center" value="Laboratorio" readonly>
                        </div>

                        <!-- Botones de acción -->
                        <div class="d-flex justify-content-between mt-4">
                            <button type="submit" class="btn btn-success px-4 py-2 fs-5">Solicitar Reabastecimiento</button>
                            <a href="inventario.php" class="btn btn-outline-secondary px-4 py-2 fs-5">Regresar</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- Scripts -->
<script src="../js/selector.js"></script>
<script src="../js/alerta_envio.js"></script>
<script>
    document.getElementById('solicitudForm').addEventListener('submit', function () {
        mostrarAlertaEnvio();
    });
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>








