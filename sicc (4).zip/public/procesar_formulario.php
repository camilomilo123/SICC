<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST['id_reactivo'])) {
        $id_reactivo = $_POST['id_reactivo'];
        echo "Reactivo seleccionado: " . htmlspecialchars($id_reactivo);
        // Aquí puedes hacer algo más, como guardarlo en la base de datos
    } else {
        echo "Por favor seleccione un reactivo.";
    }
}
?>
