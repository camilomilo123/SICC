<?php
$SERVER = "localhost";
$user = "root";
$pass = "";
$db = "inventario_sena";

$conexion = new mysqli($SERVER,$user,$pass,$db);
