<?php
session_start();
include "../modelos/ConexionBD.php";

// Recoger los datos ingresados por el usuario
$usuario = trim($_POST["Nombre"]);
$contraseña_ingreso = trim($_POST["Contraseña"]);
$contraseña_ingreso_encrip = hash('sha512', $contraseña_ingreso);

// Consulta para verificar el usuario en la base de datos
$q = "SELECT cargo_id FROM usuario WHERE nombre = ? AND contraseña = ?";
$stmt = $conexion->prepare($q);
$stmt->bind_param("ss", $usuario, $contraseña_ingreso_encrip);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows == 1) {
    $stmt->bind_result($cargo_id);
    $stmt->fetch();

    // Guardar información en la sesión
    $_SESSION['nombre'] = $usuario;
    $_SESSION['loggedin'] = true;

    // Redirección basada en el cargo_id
    if ($cargo_id == "Admin1107") {
        header("Location: ../public/administrador.php");
    } elseif ($cargo_id == "Deportes8765") {
        header("Location: ../public/views//.php");
    } elseif ($cargo_id == "Lab5678") {
        header("Location: ../public/views/laboratorio/laboratorio.php");
    } elseif ($cargo_id == "Bienestar0611") {
        header("Location: ../public/.php");
    } elseif ($cargo_id == "Hospedaje1181") {
        header("Location: ../public/.php");
    } else {
        header("Location: ../public/index.php");
    }
} else {
    // Si las credenciales no son válidas, redirigir con un mensaje de error
    header("Location: ../public/index.php?error=invalid_credentials");
}

$stmt->close();
$conexion->close();
?>

