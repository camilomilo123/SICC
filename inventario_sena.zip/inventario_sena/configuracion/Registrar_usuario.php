<?php
// Iniciar la sesión para almacenar información del usuario
session_start();

// Recoger y limpiar los datos del formulario
$nombre = trim($_POST["Nombre"]); // Nombre del usuario
$telefono = trim($_POST["Telefono"]); // Teléfono del usuario
$correo = trim($_POST["Correo"]); // Correo del usuario
$rol = trim($_POST["Codigo"]); // Codigo del usuario
$Contraseña = trim($_POST["Contraseña"]); // Contraseña proporcionada por el usuario

// Encriptar la contraseña utilizando el algoritmo SHA-512
$contraseña_encrip = hash('sha512', $Contraseña); 


// Incluir el archivo de conexión a la base de datos
include "../modelos/ConexionBD.php";

// Consulta SQL para insertar el nuevo usuario en la tabla 'usuario'
$sql = "INSERT INTO usuario(nombre, telefono, correo, contraseña, cargo_id)
        VALUES ('$nombre', '$telefono', '$correo', '$contraseña_encrip', '$rol')"; 

// Ejecutar la consulta y verificar si se realizó correctamente
if ($conexion->query($sql) === true) {
    // Redirigir a la página de inicio con un mensaje de éxito
    header("Location: ../public/index.php?registro=success");
    exit(); // Salir para evitar que se ejecute más código
} else {
    // Redirigir a la página de inicio con un mensaje de error
    header("Location: ../public/index.php?registro=error");
    exit(); // Salir para evitar que se ejecute más código
}

// Cerrar la conexión a la base de datos
$conexion->close();
?>
