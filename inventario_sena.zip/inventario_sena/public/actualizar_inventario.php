<?php
// actualizar_inventario.php
$conn = new mysqli("localhost", "root", "", "inventario_sena");

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $reactivo = $_POST['reactivo'];
    $formula = $_POST['formula'];
    $estado = $_POST['estado'];
    $fecha_vencimiento = $_POST['fecha_vencimiento'];
    $lote = $_POST['lote'];
    $unidad_medida = $_POST['unidad_medida'];
    $ubicacion = $_POST['ubicacion'];
    $codigo_almacenamiento = $_POST['codigo_almacenamiento'];
    // $cantidad = $_POST['cantidad'];  Removed cantidad from here

    $sql = "UPDATE inventario_laboratorio SET 
            reactivo = '$reactivo',
            formula = '$formula',
            estado = '$estado',
            fecha_vencimiento = '$fecha_vencimiento',
            lote = '$lote',
            unidad_medida = '$unidad_medida',
            ubicacion = '$ubicacion',
            codigo_almacenamiento = '$codigo_almacenamiento'
            WHERE id = $id"; // Removed cantidad from the query

    if ($conn->query($sql) === TRUE) {
        echo "success";
    } else {
        echo "Error updating record: " . $conn->error;
    }
}

$conn->close();
?>