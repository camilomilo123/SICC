<?php
// Conectar a la base de datos
$conn = new mysqli("localhost", "root", "", "inventario_sena");

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Eliminar todos los registros
$sql_delete = "DELETE FROM entradas";
if ($conn->query($sql_delete) === TRUE) {
    echo "Registros eliminados correctamente";

    // Reiniciar el AUTO_INCREMENT
    $conn->query("ALTER TABLE entradas AUTO_INCREMENT = 1");
} else {
    echo "Error al eliminar los registros: " . $conn->error;
}

$conn->close();


