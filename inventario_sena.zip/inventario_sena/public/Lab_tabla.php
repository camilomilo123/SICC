<?php
$conn = new mysqli("localhost", "root", "", "inventario_sena");

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$sql = "SELECT * FROM inventario_laboratorio";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['id']}</td>
                <td>{$row['reactivo']}</td>
                <td>{$row['formula']}</td>
                <td>{$row['estado']}</td>
                <td>{$row['fecha_vencimiento']}</td>
                <td>{$row['lote']}</td>
                <td>{$row['unidad_medida']}</td>
                <td>{$row['ubicacion']}</td>
                <td>{$row['codigo_almacenamiento']}</td>
                <td>{$row['cantidad']}</td>
                
                <td> 
                <button class='btn btn-info btn-sm' onclick='borrarFila({$row['id']}, {$row['cantidad_ingresada']})'>
                <i class='bi bi-pencil-fill'></i>Editar
                </button>
            </td>
            <td> 
                <button class='btn btn-danger btn-sm' onclick='borrarFila({$row['id']}, {$row['cantidad_ingresada']})'>
                <i class='bi bi-trash3-fill'></i>Eliminar
                </button>
            </td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='10'>No hay datos disponibles</td></tr>";
}

$conn->close();
?>
