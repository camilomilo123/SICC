

<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);

include_once('conexionBD.php');

// Añadir mililitros
if (isset($_POST['action']) && $_POST['action'] == 'add_mililitros') {
    $id = $_POST['id'];
    $mililitros = $_POST['mililitros'];

    // Actualizar el valor
    $sql = "UPDATE datos SET mililitros = mililitros + $mililitros WHERE id = $id";
    if ($conn->query($sql)) {
        // Devolver el valor actualizado
        $result = $conn->query("SELECT mililitros FROM datos WHERE id = $id");
        $row = $result->fetch_assoc();
        echo $row['mililitros'];
    } else {
        echo "Error: " . $conn->error;
    }
    exit;
}

// Obtener datos
if (isset($_POST['action']) && $_POST['action'] == 'fetch_data') {
    $result = $conn->query("SELECT * FROM datos");
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    echo json_encode($data);
    exit;
}
?>
