


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SCC Laboratorio</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container mt-5">
        <h1 class="text-center">Laboratorio - Añadir Mililitros</h1>

        <!-- Formulario para añadir mililitros manualmente -->
        <form id="addForm" class="mb-4" method="POST" id="miFormulario">
            <div class="row">
                <div class="col-md-4">
                    <label for="idInput" class="form-label">ID del Reactivo</label>
                    <input type="number" id="idInput" class="form-control" placeholder="Ingresa el ID" required>
                </div>
                <div class="col-md-4">
                    <label for="mililitrosInput" class="form-label">Mililitros a Añadir</label>
                    <input type="number" id="mililitrosInput" class="form-control" placeholder="Ingresa los mililitros" required>
                </div>
                <div class="col-md-4 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary w-100">Añadir Mililitros</button>
                </div>
            </div>
        </form>

        <!-- Tabla para mostrar los datos -->
        <table class="table table-bordered mt-4" id="dataTable">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Mililitros</th>
                </tr>
            </thead>
            <tbody>
                <!-- Los datos se cargarán dinámicamente con JavaScript -->
            </tbody>
        </table>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script>
        // Cargar los datos al cargar la página
        function fetchData() {
            $.post('ajax.php', { action: 'fetch_data' }, function(data) {
                const rows = JSON.parse(data);
                let html = '';
                rows.forEach(row => {
                    html += `
                        <tr>
                            <td>${row.id}</td>
                            <td>${row.nombre}</td>
                            <td id="mililitros-${row.id}">${row.mililitros}</td>
                        </tr>
                    `;
                });
                $('#dataTable tbody').html(html);
            });
        }

        // Añadir mililitros manualmente
        $('#addForm').on('submit', function(e) {
            e.preventDefault();

            const id = $('#idInput').val();
            const mililitros = $('#mililitrosInput').val();

            if (id && mililitros && mililitros > 0) {
                $.post('ajax.php', { action: 'add_mililitros', id, mililitros }, function(newValue) {
                    if (!isNaN(newValue)) {
                        // Actualizar la tabla dinámicamente
                        $(`#mililitros-${id}`).text(newValue);
                        // Limpiar los campos del formulario
                        $('#idInput').val('');
                        $('#mililitrosInput').val('');
                        alert('Mililitros añadidos con éxito.');
                    } else {
                        alert('Error: No se pudo añadir los mililitros. Verifica el ID.');
                    }
                });
            } else {
                alert('Por favor, ingresa un ID válido y un valor de mililitros mayor a 0.');
            }
        });

        // Llama a la función para cargar los datos al iniciar
        fetchData();
    </script>
</body>

</html>
