<?php
// Habilitar la visualización de errores
ini_set('display_errors', 1);
error_reporting(E_ALL);

$conn = new mysqli("localhost", "root", "", "inventario_sena");

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Verificar que los parámetros id y cantidad_ingresada estén presentes
if (isset($_POST['id']) && isset($_POST['cantidad_ingresada'])) {
    $id = $_POST['id'];
    $cantidad_ingresada = $_POST['cantidad_ingresada'];

    // Comenzar la transacción para mantener la integridad de los datos
    $conn->begin_transaction();

    try {
        // Verificar si el inventario_id existe en la tabla entradas
        $sql_check = "SELECT inventario_id FROM entradas WHERE id = ?";
        $stmt_check = $conn->prepare($sql_check);
        $stmt_check->bind_param("i", $id);
        $stmt_check->execute();
        $result_check = $stmt_check->get_result();

        if ($result_check->num_rows > 0) {
            // Obtener el inventario_id de la entrada
            $row = $result_check->fetch_assoc();
            $inventario_id = $row['inventario_id'];

            // Verificar si el inventario_id existe en inventario_laboratorio
            $sql_check_inventory = "SELECT cantidad FROM inventario_laboratorio WHERE id = ?";
            $stmt_check_inventory = $conn->prepare($sql_check_inventory);
            $stmt_check_inventory->bind_param("i", $inventario_id);
            $stmt_check_inventory->execute();
            $result_check_inventory = $stmt_check_inventory->get_result();

            if ($result_check_inventory->num_rows > 0) {
                // Obtener la cantidad actual del inventario
                $inventory_row = $result_check_inventory->fetch_assoc();
                $nueva_cantidad = $inventory_row['cantidad'] - $cantidad_ingresada; // Restar la cantidad ingresada

                // Actualizar la cantidad en inventario_laboratorio
                $sql_update = "UPDATE inventario_laboratorio SET cantidad = ? WHERE id = ?";
                $stmt_update = $conn->prepare($sql_update);
                $stmt_update->bind_param("di", $nueva_cantidad, $inventario_id);
                $stmt_update->execute();

                // Eliminar la entrada de la tabla 'entradas'
                $sql_delete = "DELETE FROM entradas WHERE id = ?";
                $stmt_delete = $conn->prepare($sql_delete);
                $stmt_delete->bind_param("i", $id);
                $stmt_delete->execute();

                // Si todo fue exitoso, hacer commit de la transacción
                $conn->commit();
                echo "Entrada eliminada con éxito.";
            } else {
                echo "No se encontró el reactivo con el ID en inventario_laboratorio.";
            }
        } else {
            echo "No se encontró la entrada con el ID en la tabla entradas.";
        }
    } catch (Exception $e) {
        // Si ocurre algún error, revertir la transacción
        $conn->rollback();
        echo "Error al eliminar la entrada: " . $e->getMessage();
    }
} else {
    echo "Faltan parámetros.";
}

$conn->close();
?>











