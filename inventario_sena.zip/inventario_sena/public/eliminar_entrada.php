<?php
// eliminar_entrada.php
if (isset($_POST['id'])) {
    // Conectar a la base de datos
    $conn = new mysqli('localhost', 'usuario', 'contraseña', 'inventario_sena');

    // Comprobar si hubo error de conexión
    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }

    // Obtener el ID de la entrada a eliminar
    $id = $_POST['id'];

    // Consulta para eliminar la entrada
    $sql = "DELETE FROM entradas WHERE id = ?";

    // Preparar y ejecutar la consulta
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $id);  // "i" para integer
        $stmt->execute();
        echo "Entrada eliminada con éxito";
    } else {
        echo "Error al eliminar la entrada";
    }

    // Cerrar la conexión
    $conn->close();
} else {
    echo "ID no especificado";
}
?>
