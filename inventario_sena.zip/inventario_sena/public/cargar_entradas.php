<?php
$conn = new mysqli("localhost", "root", "", "inventario_sena");
if ($conn->connect_error) die("Conexión fallida: " . $conn->connect_error);

// Obtener las entradas registradas
$sql = "SELECT * FROM entradas";
$result = $conn->query($sql);

while ($row = $result->fetch_assoc()) {
    echo "<tr>
            <td >{$row['id']}</td>
            <td>{$row['nombre']}</td>
            <td>{$row['fecha']}</td>
            <td>{$row['unidad_medida']}</td>
            <td style='background-color: #f1948a ;'>{$row['cantidad_anterior']}</td>
            <td style='background-color: #f7dc6f;'>{$row['cantidad_ingresada']}</td>
            <td style='background-color: #82e0aa ;'>" . ($row['cantidad_anterior'] + $row['cantidad_ingresada']) . "</td>
            <td> 
                <button class='btn btn-danger btn-sm' onclick='borrarFila({$row['id']}, {$row['cantidad_ingresada']})'>
                    <i class='bi bi-trash'></i> Eliminar
                </button>
            </td>
          </tr>";
}

$conn->close();
?>



