<?php
include '../../configuracion/conexion.php';

$query = "SELECT id, reactivo, fecha, descripcion, cantidad_anterior, cantidad_salida, cantidad_total FROM salidas ORDER BY fecha DESC";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['id']}</td>
                <td>{$row['reactivo']}</td>
                <td>{$row['fecha']}</td>
                <td>{$row['descripcion']}</td>
                <td>{$row['cantidad_anterior']}</td>
                <td>{$row['cantidad_salida']}</td>
                <td>{$row['cantidad_total']}</td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='7' class='text-center'>No hay registros de salida</td></tr>";
}

$conn->close();
?>

