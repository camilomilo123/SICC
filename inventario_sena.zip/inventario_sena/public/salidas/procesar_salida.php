<?php
include '../../configuracion/conexion.php'; // Asegúrate de incluir la conexión a la BD

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $inventario_id = $_POST["inventario_id"];
    $unidad_medida = $_POST["unidad_medida"];
    $cantidad_salida = $_POST["cantidad_salida"];

    // Obtener la cantidad actual en el inventario
    $query = "SELECT cantidad, reactivo FROM inventario_laboratorio WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $inventario_id);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($cantidad_actual, $reactivo);
        $stmt->fetch();

        if ($cantidad_actual >= $cantidad_salida) {
            $cantidad_total = $cantidad_actual - $cantidad_salida;

            // Actualizar la cantidad en el inventario
            $updateQuery = "UPDATE inventario_laboratorio SET cantidad = ? WHERE id = ?";
            $updateStmt = $conn->prepare($updateQuery);
            $updateStmt->bind_param("di", $cantidad_total, $inventario_id);
            $updateStmt->execute();

            // Registrar la salida en la tabla "salidas"
            $insertQuery = "INSERT INTO salidas (inventario_id, reactivo, descripcion, cantidad_anterior, cantidad_salida, cantidad_total, fecha) 
                            VALUES (?, ?, ?, ?, ?, ?, NOW())";
            $insertStmt = $conn->prepare($insertQuery);
            $insertStmt->bind_param("issddd", $inventario_id, $reactivo, $unidad_medida, $cantidad_actual, $cantidad_salida, $cantidad_total);
            $insertStmt->execute();

            echo "Salida registrada exitosamente.";
        } else {
            echo "Error: No hay suficiente cantidad en el inventario.";
        }
    } else {
        echo "Error: El ID de inventario no existe.";
    }

    $stmt->close();
    $conn->close();
}
?>
