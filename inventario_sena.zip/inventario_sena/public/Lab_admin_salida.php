

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SICC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


    <link href="https://cdn.lineicons.com/4.0/lineicons.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="./css/administrador.css?v=1.0">
    <link rel="stylesheet" href="./css/pdf.css" media="print">
</head>

<body>
    <div class="wrapper">
        <aside id="sidebar" class="expand">
            <div class="d-flex" >
                <button class="toggle-btn" type="button"  >
                <i class="bi bi-hexagon-fill"></i>
                </button>
                <div class="sidebar-logo">
                    <a href="#" style="font-size: 25px;">SICC</a>
                </div>
            </div>
            <ul class="sidebar-nav">
                <li class="sidebar-item">
                    <a href="#" class="sidebar-link">
                    <i class="bi bi-house-door-fill"></i>
                        <span>Inicio</span>
                    </a>
                </li>
                
                
                <li class="sidebar-item">
                    <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
                        data-bs-target="#auth" aria-expanded="false" aria-controls="auth">
                        
                       <i class="bi bi-grid-fill"></i>
                        <span> Dependencias</span>
                    </a>
                    <ul id="auth" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">
    <!-- Laboratorio -->
    <li class="sidebar-item">
        <a href="./Laboratorio_inventario.php" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
            data-bs-target="#lab-options" aria-expanded="false" aria-controls="lab-options">
            <i class="bi bi-thermometer-high"></i>Laboratorio
        </a>
        <ul id="lab-options" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#auth">
        <li class="sidebar-item">
                <a href="./Laboratorio_inventario.php" class="sidebar-link"><i class="bi bi-clipboard-fill"></i>Inventario</a>
            </li>
            <li class="sidebar-item">
                <a href="./Lab_admin_salida.php" class="sidebar-link"><i class="bi bi-caret-up"></i>Entradas</a>
            </li>
            <li class="sidebar-item">
                <a href="./Lab_admin_salida.php" class="sidebar-link"> <i class="bi bi-caret-down"></i>Salidas</a>
            </li>
        </ul>
    </li>
    <!-- Bienestar -->
    <li class="sidebar-item">
        <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
            data-bs-target="#bienestar-options" aria-expanded="false" aria-controls="bienestar-options">
            <i class="bi bi-person-arms-up"></i>Bienestar
        </a>
        <ul id="bienestar-options" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#auth">
            <li class="sidebar-item">
                <a href="#" class="sidebar-link"> <i class="bi bi-caret-up"></i>Entradas</a>
            </li>
            <li class="sidebar-item">
                <a href="#" class="sidebar-link"> <i class="bi bi-caret-down"></i>Salidas</a>
            </li>
        </ul>
    </li>
    <!-- Deportes -->
    <li class="sidebar-item">
        <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
            data-bs-target="#deportes-options" aria-expanded="false" aria-controls="deportes-options">
            <i class="bi bi-trophy-fill"></i>Deportes
        </a>
        <ul id="deportes-options" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#auth">
            <li class="sidebar-item">
                <a href="#" class="sidebar-link"><i class="bi bi-caret-up"></i>Entradas</a>
            </li>
            <li class="sidebar-item">
                <a href="#" class="sidebar-link"> <i class="bi bi-caret-down"></i>Salidas</a>
            </li>
        </ul>
    </li>
    <!-- Hospedaje -->
    <li class="sidebar-item">
        <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
            data-bs-target="#hospedaje-options" aria-expanded="false" aria-controls="hospedaje-options">
            <i class="bi bi-buildings-fill"></i>Hospedaje
        </a>
        <ul id="hospedaje-options" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#auth">
            <li class="sidebar-item">
                <a href="#" class="sidebar-link"><i class="bi bi-caret-up"></i>Entradas</a>
            </li>
            <li class="sidebar-item">
                <a href="#" class="sidebar-link"> <i class="bi bi-caret-down"></i>Salidas</a>
            </li>
        </ul>
    </li>
</ul>


<!-- inventario -->
                </li>
                <li class="sidebar-item">
                    <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
                        data-bs-target="#multi" aria-expanded="false" aria-controls="multi">
                        <i class="bi bi-database"></i>
                        <span>Inventario</span>
                    </a>
                    <!-- opciones -->
                    <ul id="multi" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">
                        <li class="sidebar-item">
                            <a href="#" class="sidebar-link collapsed" data-bs-toggle="collapse"
                                data-bs-target="#multi-two" aria-expanded="false" aria-controls="multi-two">
                                <i class="bi bi-database-fill-gear"></i>
                                Opciones 
                            </a>
                            <ul id="multi-two" class="sidebar-dropdown list-unstyled collapse">
                                <li class="sidebar-item">
                                    <a href="./anadir.php" class="sidebar-link"><i class="bi bi-plus-circle"></i>Añadir</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="#" class="sidebar-link"><i class="bi bi-x-circle"></i>eliminar</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="#" class="sidebar-link"><i class="bi bi-pencil"></i>Editar</a>
                                </li>
                                
                            </ul>
                        </li>
                    </ul>
                </li>
                <li class="sidebar-item">
                    <a href="#" class="sidebar-link">
                        <i class="lni lni-popup"></i>
                        <span>Reportes</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a href="#" class="sidebar-link">
                        <i class="lni lni-cog"></i>
                        <span>Configuracion</span>
                    </a>
                </li>
            </ul>
            <div class="sidebar-footer">
                <a href="#" class="sidebar-link">
                    <i class="lni lni-exit"></i>
                    <span>Logout</span>
                </a>
            </div>
        </aside>
        <!-- imagen de perfil -->
        <div class="main p-3">
            <div class="text-end ">
                <h1>imagen de perfil</h1>
                
            </div>
            <div class="container">
        <h1><strong style="color: green;">Entrada de elementos</strong></h1>
        <form id="entradaForm" class="row g-2 align-items-center">
    <!-- ID del Inventario -->
    <div class="col-md-2">
        <label for="inventario_id" class="form-label">ID Inventario:</label>
        <input type="number" id="inventario_id" name="inventario_id" class="form-control form-control-sm" required>
    </div>

    <!-- Unidad de Medida -->
    <div class="col-md-2">
        <label for="unidad_medida" class="form-label">Unidad:</label>
        <select id="unidad_medida" name="unidad_medida" class="form-select form-select-sm" required>
            <option value="ml">ml</option>
            <option value="kg">kg</option>
            <option value="ml">ml</option>
            <option value="kg">Gramos</option>

            <option value="litros">Litros</option>
        </select>
    </div>

    <!-- Cantidad Ingresada -->
    <div class="col-md-3">
        <label for="cantidad_ingresada" class="form-label">Cantidad:</label>
        <input type="number" id="cantidad_ingresada" name="cantidad_ingresada" class="form-control form-control-sm" step="0.01" required>
    </div>

    <!-- Botón -->
    <div class="col-md-5 d-flex align-items-end" style="padding-top: 30px;">
    <button type="submit" id="btnRegistrar" class="btn btn-success btn-sm w-100">Registrar</button>

    </div>
</form>
<!-- Contenido -->
<hr>



    <br>

    <h2 class="titulo-entradas">Entradas Registradas </h2> 
    
    
<table class="table" id="tabla-inventario">
    <thead class="table-dark">
       <tr>
        <th scope="col">ID</th>
        <th scope="col">Nombre</th>
        <th scope="col">Fecha</th>
        <th scope="col">Unidad de Medida</th>
        <th scope="col">Cantidad Anterior</th>
        <th scope="col">Cantidad Ingresada</th>
        <th scope="col">Cantidad Total</th>
        <th scope="col">Accion</th>
        

        
      </tr>
   </thead>
   

    <tbody id="entradasTable">
    <!-- aqui apareceran las entradas  -->
    </tbody>
</table>
<div class="col-md-2 d-flex align-items-end" style="padding-top: 30px;">
    <a href="" class="btn btn-success boton" onclick="window.print()">Reporte </a>

    </div>


<script>
    

    // Función para borrar una fila
function borrarFila(id, cantidad_ingresada) {
    if (confirm("¿Estás seguro de que quieres eliminar esta entrada?")) {
        $.ajax({
            type: "POST",
            url: "eliminar_entrada.php", // Ruta del archivo PHP que maneja la eliminación
            data: {
                id: id,
                cantidad_ingresada: cantidad_ingresada // Enviamos la cantidad ingresada para restar de la cantidad total
            },
            success: function (response) {
                alert(response); // Muestra la respuesta del servidor
                loadEntradas(); // Recarga la tabla para mostrar los datos actualizados
            },
            error: function () {
                console.error("Error al eliminar");
                alert("Hubo un error al eliminar la entrada.");
            }
        });
    }
}

// Función para cargar las entradas desde el servidor y actualizar la tabla
function loadEntradas() {
    $.ajax({
        url: "cargar_entradas.php", // Archivo PHP para obtener las entradas actualizadas
        success: function (response) {
            $("#entradasTable").html(response); // Actualiza la tabla con los nuevos datos
        },
        error: function () {
            Swal.fire({
                icon: 'error',
                title: 'Error al cargar',
                text: 'No se pudieron cargar las entradas registradas.',
                confirmButtonText: 'Cerrar'
            });
        }
    });
}


    // Enviar el formulario con confirmación SweetAlert2 y AJAX
    $("#entradaForm").on("submit", function (event) {
        event.preventDefault(); // Prevenir el envío normal del formulario

        // Alerta de confirmación antes de enviar
        Swal.fire({
            title: '¿Confirmar envío?',
            text: '¿Estás seguro de que deseas registrar esta entrada?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Sí, enviar',
            cancelButtonText: 'Cancelar',
        }).then((result) => {
            if (result.isConfirmed) {
                // Si el usuario confirma, se envía el formulario por AJAX
                $.ajax({
                    url: "registrar_entrada.php", // Archivo PHP para registrar la entrada
                    type: "POST",
                    data: $(this).serialize(), // Serializa los datos del formulario
                    success: function (response) {
                        // Muestra un mensaje de éxito con SweetAlert2
                        Swal.fire({
                            icon: 'success',
                            title: 'Entrada registrada',
                            text: 'La entrada se registró con éxito.',
                            confirmButtonText: 'Aceptar'
                        }).then(() => {
                            // Actualiza la tabla con las entradas más recientes
                            loadEntradas();
                        });
                    },
                    error: function () {
                        // Si ocurre un error, muestra un mensaje de error
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Hubo un problema al registrar la entrada. Inténtalo nuevamente.',
                            confirmButtonText: 'Cerrar'
                        });
                    }
                });
            }
        });
    });

    // Cargar las entradas cuando la página esté lista
    $(document).ready(function () {
        loadEntradas(); // Llamada para cargar las entradas desde el principio
    });
</script>



    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="filtros.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</body>

</html>

