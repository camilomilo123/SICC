<?php
// Código para registrar la entrada en la base de datos
$conn = new mysqli("localhost", "root", "", "inventario_sena");
if ($conn->connect_error) die("Conexión fallida: " . $conn->connect_error);

$inventario_id = $_POST['inventario_id'];
$unidad_medida = $_POST['unidad_medida'];
$cantidad_ingresada = intval($_POST['cantidad_ingresada']); // Asegura que cantidad_ingresada sea un entero

// Obtener la cantidad actual del inventario
$sql_cantidad = "SELECT cantidad FROM inventario_laboratorio WHERE id = $inventario_id";
$result = $conn->query($sql_cantidad);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $cantidad_anterior = intval($row['cantidad']); // Asegura que cantidad_anterior sea un entero
} else {
    die("Error: No se encontró el inventario con ID $inventario_id");
}

// Calcular la nueva cantidad total, asegurando que sea un entero
$cantidad_total = intval($cantidad_anterior + $cantidad_ingresada);

// Actualizar la cantidad en la tabla de inventario
$sql_update = "UPDATE inventario_laboratorio SET cantidad = $cantidad_total WHERE id = $inventario_id";
if (!$conn->query($sql_update)) {
    die("Error al actualizar el inventario: " . $conn->error);
}

// Obtener la fecha actual desde el servidor
$fecha_actual = date("Y-m-d");

// Insertar el registro en la tabla de entradas, asegurando que las cantidades sean enteras
$sql_insert = "INSERT INTO entradas (inventario_id, nombre, fecha, unidad_medida, cantidad_anterior, cantidad_ingresada)
               SELECT id, reactivo, '$fecha_actual', '$unidad_medida', $cantidad_anterior, $cantidad_ingresada
               FROM inventario_laboratorio WHERE id = $inventario_id";

if ($conn->query($sql_insert) === TRUE) {
    // Obtener las entradas registradas para devolverlas como HTML
    $sql_select = "SELECT * FROM entradas";
    $result = $conn->query($sql_select);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row['id'] . "</td>";
            echo "<td>" . $row['nombre'] . "</td>";
            echo "<td>" . $row['fecha'] . "</td>";
            echo "<td>" . $row['unidad_medida'] . "</td>";
            echo "<td>" . $row['cantidad_anterior'] . "</td>";
            echo "<td>" . $row['cantidad_ingresada'] . "</td>";
            echo "<td>" . ($row['cantidad_anterior'] + $row['cantidad_ingresada']) . "</td>";
            echo "</tr>";
        }
    }
} else {
    echo "Error al registrar la entrada: " . $conn->error;
}

$conn->close();
?>


