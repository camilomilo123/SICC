<?php
// Verificar si los datos fueron enviados por POST
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['item']) && isset($_POST['cantidad_salida'])) {

    // Obtener los datos del formulario
    $item = $_POST['item'];
    $cantidad_salida = $_POST['cantidad_salida'];

    // Validar que las cantidades sean positivas
    if ($cantidad_salida <= 0) {
        $error = "La cantidad de salida debe ser mayor a cero.";
    } else {
        // Conexión a la base de datos
        $conexion = new mysqli("localhost", "root", "", "inventario_sena");

        if ($conexion->connect_error) {
            die("Conexión fallida: " . $conexion->connect_error);
        }

        // Verificar si el producto existe en la tabla inven_laboratorio
        $query = "SELECT cantidad_total, cantidad_anterior, cantidad_ingresada FROM inven_laboratorio WHERE item = ?";
        $stmt = $conexion->prepare($query);
        $stmt->bind_param("i", $item);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // El producto existe en inven_laboratorio
            $row = $result->fetch_assoc();
            $cantidad_total = $row['cantidad_total'];
            $cantidad_anterior = $row['cantidad_anterior'];
            $cantidad_ingresada = $row['cantidad_ingresada'];

            if ($cantidad_total >= $cantidad_salida) {
                // Actualizar las cantidades en inven_laboratorio
                if ($cantidad_salida <= $cantidad_ingresada) {
                    $nueva_cantidad_ingresada = $cantidad_ingresada - $cantidad_salida;
                    $update_query = "UPDATE inven_laboratorio SET cantidad_ingresada = ? WHERE item = ?";
                    $update_stmt = $conexion->prepare($update_query);
                    $update_stmt->bind_param("di", $nueva_cantidad_ingresada, $item);
                    $update_stmt->execute();
                } else {
                    $cantidad_salida_restante = $cantidad_salida - $cantidad_ingresada;
                    $nueva_cantidad_anterior = $cantidad_anterior - $cantidad_salida_restante;
                    $update_query = "UPDATE inven_laboratorio SET cantidad_ingresada = 0, cantidad_anterior = ? WHERE item = ?";
                    $update_stmt = $conexion->prepare($update_query);
                    $update_stmt->bind_param("di", $nueva_cantidad_anterior, $item);
                    $update_stmt->execute();
                }

                // Registrar el movimiento en la tabla movimientos
                $tipo_movimiento = 'Salida';
                $fecha = date("Y-m-d H:i:s");
                $insert_query = "INSERT INTO movimientos (producto_id, tipo_movimiento, cantidad, fecha) VALUES (?, ?, ?, ?)";
                $insert_stmt = $conexion->prepare($insert_query);
                $insert_stmt->bind_param("isds", $item, $tipo_movimiento, $cantidad_salida, $fecha);
                $insert_stmt->execute();

                // Mostrar mensaje de éxito
                $success = "La cantidad ha sido actualizada correctamente en inven_laboratorio y el movimiento registrado en movimientos.";
            } else {
                $error = "La cantidad solicitada supera el total disponible en el inventario.";
            }
        } else {
            $error = "El producto no existe en la tabla 'inven_laboratorio'. No se puede registrar el movimiento.";
        }

        $conexion->close();
    }
} else {
    // Si no se han enviado los datos correctamente, mostrar un mensaje de advertencia
    $error = "Por favor, completa todos los campos del formulario.";
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Descontar Producto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdn.lineicons.com/4.0/lineicons.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../css/Homepage.css?v=1.0">
</head>
<body>

<div class="wrapper">
    <aside id="sidebar">
        <div class="d-flex" style="align-items: start;">
            <button class="toggle-btn" type="button" style="padding-right: 10px;">
                <img src="./Imagenes/laboratorio-medico.png" alt="" srcset="" style="width: 35px; padding:0px 0px 8px 0px;">
            </button>
            <div class="sidebar-logo">
                <a href="#" style="font-size: 25px;">Laboratorio</a>
            </div>
        </div>
        <ul class="sidebar-nav">
            <li class="sidebar-item">
                <a href="#" class="sidebar-link">
                    <i class="bi bi-house-door-fill"></i>
                    <span>Inicio</span>
                </a>
            </li>
            <li class="sidebar-item">
                <a href="./entradas.php" class="sidebar-link">
                    <i class="bi bi-caret-up"></i>
                    <span>Entradas</span>
                </a>
            </li>
            <li class="sidebar-item">
                <a href="#" id="salidasBtn" class="sidebar-link">
                    <i class="bi bi-caret-down"></i>
                    <span>Salidas</span>
                </a>
            </li>
        </ul>
        <div class="sidebar-footer">
            <a href="#" class="sidebar-link">
                <i class="lni lni-exit"></i>
                <span>Logout</span>
            </a>
        </div>
    </aside>
    <!-- ===========================================================" -->
    <div class="main p-3">
            <div class="text-end ">
                <h1>imagen de perfil</h1>
                
            </div>
            <div class="container">
        
        <h1><strong style="color: green;">Inventario laboratorio</strong></h1>
        
<hr>


    <br>
    

    <h2>Inventario</h2>
    <div class="row mb-3">
    <div class="col-md-4">
        <label for="filtroID">Filtrar por ID:</label>
        <input type="text" id="filtroID" class="form-control" placeholder="Ingrese ID">
    </div>
    <div class="col-md-4">
        <label for="filtroUbicacion">Filtrar por Ubicación:</label>
        <input type="text" id="filtroUbicacion" class="form-control" placeholder="Ingrese Ubicación">
    </div>
    <div class="col-md-4">
        <label for="filtroReactivo">Filtrar por Reactivo:</label>
        <input type="text" id="filtroReactivo" class="form-control" placeholder="Ingrese Reactivo">
    </div>
</div>

<!-- tabla de inventario -->
<table class="table" id="tabla-inventario">
    <thead class="table-dark">
       <tr>
        <th scope="col">ID</th>
        <th scope="col">Reactivo</th>
        <th scope="col">Formula</th>
        <th scope="col">Estado</th>
        <th scope="col">fecha de vencimiento</th>
        <th scope="col">lote</th>
        <th scope="col">Unidad de medida</th>
        <th scope="col">Ubicacion</th>
        <th scope="col">Codigo de almacenamiento</th>
        <th scope="col">Cantidad</th>
        
        <th scope="col">Editar</th>
        <th scope="col">Eliminar</th>

        

        
      </tr>
   </thead>
   

   <tbody id="entradasTable">
    <?php include './Lab_tabla.php'; ?>
</tbody>

</table>
<script>
$(document).ready(function() {
            // ... (existing AJAX call to load data) ...
        });


        function borrarFila(id) { // Removed cantidad_ingresada parameter
            Swal.fire({
                title: 'Editar Reactivo',
                html: `
                <form id="editForm">
                    <input type="hidden" name="id" value="${id}">
                    <div class="form-group">
                        <label for="reactivo">Reactivo:</label>
                        <input type="text" class="form-control" id="reactivo" name="reactivo" required> 
                    </div>
                    <div class="form-group">
                        <label for="formula">Formula:</label>
                        <input type="text" class="form-control" id="formula" name="formula" required>
                    </div>
                    <div class="form-group">
                        <label for="estado">Estado:</label>
                        <input type="text" class="form-control" id="estado" name="estado" required>
                    </div>
                    <div class="form-group">
                        <label for="fecha_vencimiento">Fecha Vencimiento:</label>
                        <input type="date" class="form-control" id="fecha_vencimiento" name="fecha_vencimiento" required>
                    </div>
                    <div class="form-group">
                        <label for="lote">Lote:</label>
                        <input type="text" class="form-control" id="lote" name="lote" required>
                    </div>
                    <div class="form-group">
                        <label for="unidad_medida">Unidad de Medida:</label>
                        <input type="text" class="form-control" id="unidad_medida" name="unidad_medida" required>
                    </div>
                    <div class="form-group">
                        <label for="ubicacion">Ubicación:</label>
                        <input type="text" class="form-control" id="ubicacion" name="ubicacion" required>
                    </div>
                    <div class="form-group">
                        <label for="codigo_almacenamiento">Código de Almacenamiento:</label>
                        <input type="text" class="form-control" id="codigo_almacenamiento" name="codigo_almacenamiento" required>
                    </div>
                    
                </form>
                `, // Removed cantidad input
                showCancelButton: true,
                confirmButtonText: 'Guardar',
                cancelButtonText: 'Cancelar',
                preConfirm: () => {
                    const formData = {};
                    $('#editForm').serializeArray().forEach(item => {
                        formData[item.name] = item.value;
                    });

                    return formData;
                }
            }).then((result) => {
                if (result.isConfirmed) {

                    $.ajax({
                        url: 'actualizar_inventario.php',
                        type: 'POST',
                        data: result.value,
                        success: function(response) {
                            if (response === 'success') {
                                Swal.fire('Actualizado!', '', 'success').then(() => {
                                    location.reload();
                                });
                            } else {
                                Swal.fire('Error', response, 'error');
                            }
                        },
                        error: function(error) {
                            Swal.fire('Error', 'Error al actualizar', 'error');
                        }
                    });


                }
            });
        }

</script>






    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="filtros.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <form id="entradaForm" class="row g-2 align-items-center">
    <!-- ID del Inventario -->
    <div class="main p-3">
        <div class="">
            

            <!-- Mostrar el formulario solo cuando se haga clic en "Salidas" -->
            <div id="salidaForm" style="display: none;">
                <?php if (isset($error)): ?>
                    <p style="color: red;"><?= $error ?></p>
                <?php elseif (isset($success)): ?>
                    <p style="color: green;"><?= $success ?></p>
                    <!-- Mostrar el formulario nuevamente después de mostrar el éxito -->
                    <p><a href="laboratorio.php">Haga clic aquí para realizar otra salida.</a></p>
                <?php endif; ?>

                <form action="laboratorio.php" method="POST" class="p-4 border rounded shadow bg-light">
    <?php if (isset($error)): ?>
        <div class="alert alert-danger text-center"><?= $error ?></div>
    <?php elseif (isset($success)): ?>
        <div class="alert alert-success text-center"><?= $success ?></div>
        <div class="text-center"><a href="laboratorio.php" class="btn btn-secondary mt-2">Realizar otra salida</a></div>
    <?php endif; ?>
    <h1><strong style="color: green;">Salidas de Reactivos</strong></h1>

    <div class="d-flex gap-1 align-items-center">
        <label for="item" class="form-label"><strong>Reactivo(ID):</strong></label>
        <input type="number" name="item" id="item" class="form-control" placeholder="Ingrese el ID" required min="1" style="width: 30%;">

        <label for="cantidad_salida" class="form-label"><strong>Cantidad:</strong></label>
        <input type="number" name="cantidad_salida" id="cantidad_salida" class="form-control" placeholder="Ingrese la cantidad" required min="1"style="width: 30%;">

        <button type="submit"style="width: 30%;" class="btn btn-success" >
            <i class="bi bi-box-arrow-right"></i> Registrar
        </button>
    </div>
</form>


            </div>
        </div>
    </div>
</div>
<!-- Contenido -->
<hr>



    <br>

    <h2 class="titulo-entradas">Entradas Registradas </h2> 
    
    
<table class="table" id="tabla-inventario">
    <thead class="table-dark">
       <tr>
        <th scope="col">ID</th>
        <th scope="col">Nombre</th>
        <th scope="col">Fecha</th>
        <th scope="col">Unidad de Medida</th>
        <th scope="col">Cantidad Anterior</th>
        <th scope="col">Cantidad Ingresada</th>
        <th scope="col">Cantidad Total</th>
        <th scope="col">Accion</th>
        

        
      </tr>
   </thead>
   

    <tbody id="entradasTable">
    <!-- aqui apareceran las entradas  -->
    </tbody>
</table>

   <!-- ===========================================================" -->

    

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script>
    document.getElementById('salidasBtn').addEventListener('click', function() {
        var form = document.getElementById('salidaForm');
        // Alternar la visibilidad del formulario
        form.style.display = (form.style.display === 'none' || form.style.display === '') ? 'block' : 'none';
    });
</script>

</body>
</html>
