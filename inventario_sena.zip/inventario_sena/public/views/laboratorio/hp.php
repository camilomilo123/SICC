<?php
require 'conexion.php'; // Asegúrate de tener una conexión a la base de datos

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_producto = intval($_POST['id_producto']);
    $cantidad_salida = floatval($_POST['cantidad']);
    $fecha_hora = date('Y-m-d H:i:s');

    // Verificar si el producto existe y obtener la cantidad actual
    $stmt = $conn->prepare("SELECT producto, cantidad_anterior FROM inven_laboratorio WHERE item = ?");
    $stmt->bind_param("i", $id_producto);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows > 0) {
        $producto = $resultado->fetch_assoc();
        $cantidad_actual = $producto['cantidad_anterior'];
        $nombre_producto = $producto['producto'];

        if ($cantidad_actual >= $cantidad_salida) {
            // Actualizar la cantidad en inven_laboratorio
            $nueva_cantidad = $cantidad_actual - $cantidad_salida;
            $stmt = $conn->prepare("UPDATE inven_laboratorio SET cantidad_anterior = ? WHERE item = ?");
            $stmt->bind_param("di", $nueva_cantidad, $id_producto);
            $stmt->execute();

            // Registrar el movimiento en la tabla movimientos
            $stmt = $conn->prepare("INSERT INTO movimientos (producto_id, tipo_movimiento, cantidad, fecha) VALUES (?, 'salida', ?, ?)");
            $stmt->bind_param("ids", $id_producto, $cantidad_salida, $fecha_hora);
            $stmt->execute();
            
            echo "<p style='color: green;'>Salida registrada exitosamente.</p>";
        } else {
            echo "<p style='color: red;'>No hay suficiente cantidad en inventario.</p>";
        }
    } else {
        echo "<p style='color: red;'>Producto no encontrado.</p>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Salida de Producto - Laboratorio</title>
</head>
<body>
    <h2>Registrar Salida de Producto</h2>
    <form method="post" action="laboratorio.php">
        <label for="id_producto">ID del Producto:</label>
        <input type="number" name="id_producto" required>
        <br>
        <label for="cantidad">Cantidad a Descontar:</label>
        <input type="number" name="cantidad" step="0.01" required>
        <br>
        <button type="submit">Registrar Salida</button>
    </form>
</body>
</html>
