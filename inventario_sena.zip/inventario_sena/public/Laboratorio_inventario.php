

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SICC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


    <link href="https://cdn.lineicons.com/4.0/lineicons.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="./css/administrador.css?v=1.0">
</head>

<body>
    <div class="wrapper">
        <aside id="sidebar" class="expand">
            <div class="d-flex" >
                <button class="toggle-btn" type="button"  >
                <i class="bi bi-hexagon-fill"></i>
                </button>
                <div class="sidebar-logo">
                    <a href="#" style="font-size: 25px;">SICC</a>
                </div>
            </div>
            <ul class="sidebar-nav">
                <li class="sidebar-item">
                    <a href="#" class="sidebar-link">
                    <i class="bi bi-house-door-fill"></i>
                        <span>Inicio</span>
                    </a>
                </li>
                
                
                <li class="sidebar-item">
                    <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
                        data-bs-target="#auth" aria-expanded="false" aria-controls="auth">
                        
                       <i class="bi bi-grid-fill"></i>
                        <span> Dependencias</span>
                    </a>
                    <ul id="auth" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">
    <!-- Laboratorio -->
    <li class="sidebar-item">
        <a href="./Laboratorio_inventario.php" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
            data-bs-target="#lab-options" aria-expanded="false" aria-controls="lab-options">
            <i class="bi bi-thermometer-high"></i>Laboratorio
        </a>
        <ul id="lab-options" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#auth">
        <li class="sidebar-item">
                <a href="./Laboratorio_inventario.php" class="sidebar-link"><i class="bi bi-clipboard-fill"></i>Inventario</a>
            </li>
            <li class="sidebar-item">
                <a href="./Lab_admin_salida.php" class="sidebar-link"><i class="bi bi-caret-up"></i>Entradas</a>
            </li>
            <li class="sidebar-item">
                <a href="./Lab_admin_salida.php" class="sidebar-link"> <i class="bi bi-caret-down"></i>Salidas</a>
            </li>
        </ul>
    </li>
    <!-- Bienestar -->
    <li class="sidebar-item">
        <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
            data-bs-target="#bienestar-options" aria-expanded="false" aria-controls="bienestar-options">
            <i class="bi bi-person-arms-up"></i>Bienestar
        </a>
        <ul id="bienestar-options" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#auth">
            <li class="sidebar-item">
                <a href="#" class="sidebar-link"> <i class="bi bi-caret-up"></i>Entradas</a>
            </li>
            <li class="sidebar-item">
                <a href="#" class="sidebar-link"> <i class="bi bi-caret-down"></i>Salidas</a>
            </li>
        </ul>
    </li>
    <!-- Deportes -->
    <li class="sidebar-item">
        <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
            data-bs-target="#deportes-options" aria-expanded="false" aria-controls="deportes-options">
            <i class="bi bi-trophy-fill"></i>Deportes
        </a>
        <ul id="deportes-options" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#auth">
            <li class="sidebar-item">
                <a href="#" class="sidebar-link"><i class="bi bi-caret-up"></i>Entradas</a>
            </li>
            <li class="sidebar-item">
                <a href="#" class="sidebar-link"> <i class="bi bi-caret-down"></i>Salidas</a>
            </li>
        </ul>
    </li>
    <!-- Hospedaje -->
    <li class="sidebar-item">
        <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
            data-bs-target="#hospedaje-options" aria-expanded="false" aria-controls="hospedaje-options">
            <i class="bi bi-buildings-fill"></i>Hospedaje
        </a>
        <ul id="hospedaje-options" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#auth">
            <li class="sidebar-item">
                <a href="#" class="sidebar-link"><i class="bi bi-caret-up"></i>Entradas</a>
            </li>
            <li class="sidebar-item">
                <a href="#" class="sidebar-link"> <i class="bi bi-caret-down"></i>Salidas</a>
            </li>
        </ul>
    </li>
</ul>


<!-- inventario-->
                </li>
                <li class="sidebar-item">
                    <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
                        data-bs-target="#multi" aria-expanded="false" aria-controls="multi">
                        <i class="bi bi-database"></i>
                        <span>Inventario</span>
                    </a>
                    <!-- opciones -->
                    <ul id="multi" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">
                        <li class="sidebar-item">
                            <a href="#" class="sidebar-link collapsed" data-bs-toggle="collapse"
                                data-bs-target="#multi-two" aria-expanded="false" aria-controls="multi-two">
                                <i class="bi bi-database-fill-gear"></i>
                                Opciones 
                            </a>
                            <ul id="multi-two" class="sidebar-dropdown list-unstyled collapse">
                                <li class="sidebar-item">
                                    <a href="#" class="sidebar-link"><i class="bi bi-plus-circle"></i>Añadir</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="#" class="sidebar-link"><i class="bi bi-x-circle"></i>eliminar</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="#" class="sidebar-link"><i class="bi bi-pencil"></i>Editar</a>
                                </li>
                                
                            </ul>
                        </li>
                    </ul>
                </li>
                <li class="sidebar-item">
                    <a href="#" class="sidebar-link">
                        <i class="lni lni-popup"></i>
                        <span>Reportes</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a href="#" class="sidebar-link">
                        <i class="lni lni-cog"></i>
                        <span>Configuracion</span>
                    </a>
                </li>
            </ul>
            <div class="sidebar-footer">
                <a href="#" class="sidebar-link">
                    <i class="lni lni-exit"></i>
                    <span>Logout</span>
                </a>
            </div>
        </aside>
        <!-- imagen de perfil -->
        <div class="main p-3">
            <div class="text-end ">
                <h1>imagen de perfil</h1>
                
            </div>
            <div class="container">


            <!-- Contenido -->
        <h1><strong style="color: green;">Inventario laboratorio</strong></h1>
        
<hr>


    <br>

    <h2>Inventario</h2>
    <div class="row mb-3">
    <div class="col-md-4">
        <label for="filtroID">Filtrar por ID:</label>
        <input type="text" id="filtroID" class="form-control" placeholder="Ingrese ID">
    </div>
    <div class="col-md-4">
        <label for="filtroUbicacion">Filtrar por Ubicación:</label>
        <input type="text" id="filtroUbicacion" class="form-control" placeholder="Ingrese Ubicación">
    </div>
    <div class="col-md-4">
        <label for="filtroReactivo">Filtrar por Reactivo:</label>
        <input type="text" id="filtroReactivo" class="form-control" placeholder="Ingrese Reactivo">
    </div>
</div>

<!-- tabla de inventario -->
<table class="table" id="tabla-inventario">
    <thead class="table-dark">
       <tr>
        <th scope="col">ID</th>
        <th scope="col">Reactivo</th>
        <th scope="col">Formula</th>
        <th scope="col">Estado</th>
        <th scope="col">fecha de vencimiento</th>
        <th scope="col">lote</th>
        <th scope="col">Unidad de medida</th>
        <th scope="col">Ubicacion</th>
        <th scope="col">Codigo de almacenamiento</th>
        <th scope="col">Cantidad</th>
        
        <th scope="col">Editar</th>
        <th scope="col">Eliminar</th>

        

        
      </tr>
   </thead>
   

   <tbody id="entradasTable">
    <?php include './Lab_tabla.php'; ?>
</tbody>

</table>
<script>
$(document).ready(function() {
            // ... (existing AJAX call to load data) ...
        });


        function borrarFila(id) { // Removed cantidad_ingresada parameter
            Swal.fire({
                title: 'Editar Reactivo',
                html: `
                <form id="editForm">
                    <input type="hidden" name="id" value="${id}">
                    <div class="form-group">
                        <label for="reactivo">Reactivo:</label>
                        <input type="text" class="form-control" id="reactivo" name="reactivo" required> 
                    </div>
                    <div class="form-group">
                        <label for="formula">Formula:</label>
                        <input type="text" class="form-control" id="formula" name="formula" required>
                    </div>
                    <div class="form-group">
                        <label for="estado">Estado:</label>
                        <input type="text" class="form-control" id="estado" name="estado" required>
                    </div>
                    <div class="form-group">
                        <label for="fecha_vencimiento">Fecha Vencimiento:</label>
                        <input type="date" class="form-control" id="fecha_vencimiento" name="fecha_vencimiento" required>
                    </div>
                    <div class="form-group">
                        <label for="lote">Lote:</label>
                        <input type="text" class="form-control" id="lote" name="lote" required>
                    </div>
                    <div class="form-group">
                        <label for="unidad_medida">Unidad de Medida:</label>
                        <input type="text" class="form-control" id="unidad_medida" name="unidad_medida" required>
                    </div>
                    <div class="form-group">
                        <label for="ubicacion">Ubicación:</label>
                        <input type="text" class="form-control" id="ubicacion" name="ubicacion" required>
                    </div>
                    <div class="form-group">
                        <label for="codigo_almacenamiento">Código de Almacenamiento:</label>
                        <input type="text" class="form-control" id="codigo_almacenamiento" name="codigo_almacenamiento" required>
                    </div>
                    
                </form>
                `, // Removed cantidad input
                showCancelButton: true,
                confirmButtonText: 'Guardar',
                cancelButtonText: 'Cancelar',
                preConfirm: () => {
                    const formData = {};
                    $('#editForm').serializeArray().forEach(item => {
                        formData[item.name] = item.value;
                    });

                    return formData;
                }
            }).then((result) => {
                if (result.isConfirmed) {

                    $.ajax({
                        url: 'actualizar_inventario.php',
                        type: 'POST',
                        data: result.value,
                        success: function(response) {
                            if (response === 'success') {
                                Swal.fire('Actualizado!', '', 'success').then(() => {
                                    location.reload();
                                });
                            } else {
                                Swal.fire('Error', response, 'error');
                            }
                        },
                        error: function(error) {
                            Swal.fire('Error', 'Error al actualizar', 'error');
                        }
                    });


                }
            });
        }

</script>






    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="filtros.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    

</body>

</html>