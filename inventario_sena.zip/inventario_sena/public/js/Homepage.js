// Selecciona todos los enlaces en el menú lateral, excluyendo aquellos con la clase 'logout'
const sideLinks = document.querySelectorAll('.sidebar.side-menu li a:not(.logout)');

// Itera sobre cada enlace del menú lateral
sideLinks.forEach(item => {
    // Obtiene el elemento <li> padre del enlace
    const li = item.parentElement;

    // Añade un evento de clic al enlace
    item.addEventListener('click', () => {
        // Remueve la clase 'active' de todos los elementos <li> en el menú lateral
        sideLinks.forEach(i => {
            i.parentElement.classList.remove('active');
        });
        // Añade la clase 'active' al <li> correspondiente al enlace que fue clickeado
        li.classList.add('active');
    });
});

// Elimina la funcionalidad de alternar el menú lateral
// Selecciona el icono de menú en la barra de navegación
const menuBar = document.querySelector('.content nav .bx.bx-menu');
// Selecciona la barra lateral
const sideBar = document.querySelector('.sidebar');

// Desactiva el evento que alterna la clase 'close'
menuBar.addEventListener('click', () => {
    // No hace nada
});

// Selecciona el botón de búsqueda, su icono y el formulario de búsqueda
const searchBtn = document.querySelector('.content nav form .form-input button');
const searchBtnIcon = document.querySelector('.content nav form .form-input button .bx');
const searchForm = document.querySelector('.content nav form');

// Añade un evento de clic al botón de búsqueda
searchBtn.addEventListener('click', function (e) {
    // Si el ancho de la ventana es menor a 576 píxeles
    if (window.innerWidth < 576) {
        e.preventDefault(); // Evita el comportamiento predeterminado del botón
        searchForm.classList.toggle('show'); // Alterna la clase 'show' en el formulario de búsqueda
        // Cambia el icono del botón de búsqueda entre 'bx-search' y 'bx-x'
        if (searchForm.classList.contains('show')) {
            searchBtnIcon.classList.replace('bx-search', 'bx-x');
        } else {
            searchBtnIcon.classList.replace('bx-x', 'bx-search');
        }
    }
});

// Añade un evento de redimensionamiento a la ventana
window.addEventListener('resize', () => {
    // Si el ancho de la ventana es mayor a 576 píxeles, restablece el formulario de búsqueda
    if (window.innerWidth > 576) {
        searchBtnIcon.classList.replace('bx-x', 'bx-search');
        searchForm.classList.remove('show');
    }
});

// Selecciona el interruptor de tema
const toggler = document.getElementById('theme-toggle');

// Añade un evento de cambio al interruptor de tema
toggler.addEventListener('change', function () {
    // Si el interruptor está activado, añade la clase 'dark' al cuerpo del documento
    if (this.checked) {
        document.body.classList.add('dark');
    } else {
        // Si está desactivado, elimina la clase 'dark'
        document.body.classList.remove('dark');
    }
});
