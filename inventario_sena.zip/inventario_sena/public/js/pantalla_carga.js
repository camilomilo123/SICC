
    // Selecciona la pantalla de carga
    const loadingScreen = document.getElementById('loading-screen');

    // Muestra la pantalla de carga al enviar formularios
    document.addEventListener('submit', (e) => {
        loadingScreen.style.display = 'flex'; // Muestra el spinner
    });

    // Muestra la pantalla de carga al hacer clic en enlaces
    document.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', (e) => {
            const href = link.getAttribute('href');
            if (href && href !== '#') {
                loadingScreen.style.display = 'flex'; // Muestra el spinner
            }
        });
    });

