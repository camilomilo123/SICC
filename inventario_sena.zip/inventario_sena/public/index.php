<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión</title>
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="./css/index.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex justify-content-center align-items-center" style="height: 100vh;">

    <!-- Contenedor del formulario -->
    <div class="form-container bg-white p-4 rounded shadow" style="max-width: 500px; width: 100%;">
        <form action="../Configuracion/Loguear_usuario.php" method="post">
            <div class="d-flex justify-content-center align-items-center" style="height: 100px;">
                <img src="Imagenes/logo_inventario.png" style="width: 200px; height: 200px;" alt="Logo">
            </div>
            <h1 class="text-center mb-4" style="color: green;">Consumo controlado SENA</h1>

            <!-- Mensaje de error, si existe -->
            <?php
                echo isset($_GET["error"]) ? "<div class='alert alert-danger'>Usuario y contraseña incorrecta</div>" : "";
            ?>

            <!-- Nombre de usuario -->
            <div class="mb-3">
                <input name="Nombre" type="text" class="form-control" placeholder="Nombre" required>
            </div>

            <!-- Contraseña -->
            <div class="mb-3">
                <input name="Contraseña" type="password" class="form-control" placeholder="Contraseña" required>
            </div>

            <div class="mb-3">
                <button class="btn btn-outline-success w-100">Iniciar Sesión</button >
            </div>

            <!-- Botón de registro redireccionando a registro_usuario.php -->
            <div class="mb-3">
                <a href="Conf/Registrar.php" class="btn btn-outline-primary w-100">Registrarse</a>
            </div>

            <p class="mt-3 text-center text-muted">*Si no cuentas con un usuario registrado, crea uno para comenzar!*</p>

            <br>
            <!-- Enlace para olvidar contraseña -->
            <a href="#" class="text-decoration-none d-block text-center">¿Olvidaste tu contraseña?</a>
        </form>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    // Obtener parámetros de la URL
    const urlParams = new URLSearchParams(window.location.search);
    const registro = urlParams.get('registro');

    // Mostrar un mensaje de alerta si el registro fue exitoso
    if (registro === 'success') {
        Swal.fire({
            icon: 'success',
            title: 'Registro exitoso',
            text: '¡Te has registrado correctamente!',
            confirmButtonText: 'Aceptar'
        }).then(() => {
            // Reemplazar el estado del historial para evitar que se vuelva a mostrar el mensaje
            window.history.replaceState({}, document.title, window.location.pathname);
        });
    } else if (registro === 'error') {
        Swal.fire({
            icon: 'error',
            title: 'Error en el registro',
            text: 'Por favor, verifica los datos ingresados.',
            confirmButtonText: 'Intentar de nuevo'
        });
        
    }
</script>

    
</body>

</html>


</body>
</html>
