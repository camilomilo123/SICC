<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../css/index.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex justify-content-center align-items-center" style="height: 100vh;">

    <!-- Contenedor del formulario -->
    <div class="form-container bg-white p-4 rounded shadow" style="max-width: 500px; width: 100%;">
        <form action="../../Configuracion/Registrar_usuario.php" method="post" onsubmit="return validarFormulario()">
            <div class="d-flex justify-content-center align-items-center" style="height: 100px;">
                <img src="../imagenes/logo_inventario.png" style="width: 200px; height: 200px;" alt="Logo">
            </div>

            <h1 class="text-center mb-4" style="color: green;">Sistema de inventario SENA</h1>

            <!-- Mensaje de error, si existe -->
            <?php
                echo isset($_GET["error"]) ? "<div class='alert alert-danger'>Usuario y contraseña incorrecta</div>" : "";
            ?>

            <div class="mb-3">
                <input name="Nombre" type="text" class="form-control" placeholder="Nombre de usuario" required>
                <br>
                <input name="Telefono" type="text" class="form-control" placeholder="Telefono" required>
                <br>            
                <input name="Correo" type="email" class="form-control" placeholder="Correo" required>
                <br>            
                <input name="Codigo" type="text" class="form-control" placeholder="Codigo de usuario" required>
                <br>
                <input name="Contraseña" type="password" class="form-control" placeholder="Contraseña" required>
                <br>
            </div>

            <div class="mb-3">
                <button type="submit" class="btn btn-outline-primary w-100">Registrarse</button>
            </div>

            <div class="mb-3">
                <button type="button" class="btn btn-outline-success w-100" onclick="window.location.href='../index.php';">Iniciar Sesión</button>
            </div>

            <p class="mt-3 text-center text-muted">*Si ya tienes usuario inicia sesión!*</p>
        </form>
    </div>

    <script>
        // Función para validar el formulario
        function validarFormulario() {
            const codigo = document.forms[0]["Codigo"].value;
            if (codigo !== "Admin1107" && codigo !== "Deportes8765" && codigo !== "Lab5678"  && codigo !== "Bienestar0611"  && codigo !== "Hospedaje1181") {
                alert("El código de usuario es entregado por el administrador. Por favor, solicite el código de usuario y vuelva a intentarlo más tarde.");
                return false; // Impide el envío del formulario
            }
            return true; // Permite el envío del formulario
        }
    </script>
</body>
</html>
