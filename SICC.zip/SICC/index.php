<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>SICC</title>

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
    rel="stylesheet">


  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="vendor/aos/aos.css" rel="stylesheet">
  <link href="vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link rel="icon" href="views/icons/hexagon-fill.svg" type="image/x-icon">

  <link href="views/css/main.css" rel="stylesheet">


</head>

<body class="index-page">

  <header id="header" class="header d-flex align-items-center sticky-top">
    <div class="container-fluid container-xl position-relative d-flex align-items-center">

      <a href="index.php" class="logo d-flex align-items-center me-auto">
        <h1 class="sitename" style="position: relative; left: -20px;">
          <img src="views/img/sena.png" alt="Logo SENA" style="position: relative; top: -5px;">
          <strong>SICC</strong>
        </h1>
      </a>

      <nav id="navmenu" class="navmenu">
        <ul>
          <li><a href="index.php#hero" class="active">Inicio</a></li>
          <li><a href="index.php#about">Sobre nosotros</a></li>
          <li><a href="index.php#services">Servicios</a></li>
          <li><a href="index.php#team">Equipo</a></li>
          <li><a href="index.php#contact">Contacto</a></li>
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
      </nav>

      <a class="btn-getstarted" href="loguin.php">Iniciar Sesión</a>

    </div>
  </header>

  <main class="main">

    <!-- Inicio -->
    <section id="hero" class="section hero light-background">

      <div class="container">
        <div class="row gy-4">
          <div class="col-lg-6 order-2 order-lg-1 d-flex flex-column justify-content-center" data-aos="fade-up">
            <h1>Bienvenido al Sistema de Consumo Controlado</h1><br>
            <p>"Gestiona con precisión el flujo de insumos en las diferentes dependencias del SENA, como Laboratorio, Deportes, Bienestar, Hospedaje y más. Registra cada entrada y salida de manera eficiente, asegurando un control detallado y optimizando la disponibilidad de recursos en cada área."</p>
            <div class="d-flex">
              <a href="loguin.php" class="btn-get-started">Iniciar Sesión</a>
              <a href="https://www.youtube.com/"
                class="glightbox btn-watch-video d-flex align-items-center"><i
                  class="bi bi-play-circle"></i><span>Tutorial</span></a>
            </div>
          </div>
          <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="zoom-out" data-aos-delay="200">
            <img src="views/img/landing_sicc.png" class="img-fluid animated" alt="">
          </div>
        </div>
      </div>

    </section>

    <!-- Sobre nosotros -->
    <section id="about" class="section about">

      <div class="container">

        <div class="row gy-3">

          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
            <img src="views/img/landing_2.png" alt="" class="img-fluid" style="width: 80%; margin-top: 60px;">
          </div>


          <div class="col-lg-6 d-flex flex-column justify-content-center" data-aos="fade-up" data-aos-delay="200">
            <div class="about-content ps-0 ps-lg-3">
              <h3>SICC - Comprometidos con la gestión inteligente</h3>
              <p class="fst-italic">
              Este sistema del SENA está diseñado para ofrecerte un control preciso, con mayor eficiencia y seguridad en la administración de los recursos que ingresan y salen de las distintas dependencias, como laboratorios, deportes, bienestar y hospedaje, entre otras. Alineado con la misión del SENA de fortalecer la formación y gestión de recursos, esta plataforma optimiza los procesos para garantizar un uso adecuado y transparente de los insumos. Con herramientas avanzadas como:
              </p>
              <ul>
                <li>
                  <i class="bi bi-diagram-3"></i>
                  <div>
                    <h4>Monitoreo en tiempo real</h4>
                    <p>Registra cada movimiento al instante, evitando errores y mejorando la trazabilidad.</p>
                  </div>
                </li>
                <li>
                  <i class="bi bi-fullscreen-exit"></i>
                  <div>
                    <h4>Generación de reportes</h4>
                    <p>Obtén informes precisos sobre las entradas y salidas registradas en cada dependencia, facilitando
                      el análisis y la toma de decisiones.</p>
                  </div>
                </li>
              </ul>
              <p class="fst-italic">
                Con SICC, no solo podrás acceder a información clara y detallada sobre los movimientos de tus recursos,
                sino que también contarás con herramientas que facilitan su análisis y gestión.
              </p>
            </div>

          </div>
        </div>

      </div>

    </section>

    <!-- Servicios -->
    <section id="services" class="services section light-background">


      <div class="container section-title" data-aos="fade-up">
        <h2>Servicios</h2>
        <p>En SICC, ofrecemos un sistema de gestión inteligente para controlar las entradas y salidas de recursos
          dentro del inventario en 4 dependencias clave: Laboratorio, Deportes, Bienestar y Hospedaje. Nuestro sistema
          genera
          reportes detallados que registran cada movimiento, garantizando un manejo preciso, eficiente y seguro de los
          recursos en tiempo real.</p>
      </div>

      <div class="container">

        <div class="row gy-4">

          <div class="col-xl-3 col-md-6 d-flex" data-aos="fade-up" data-aos-delay="100">
            <div class="service-item position-relative">
              <div class="icon"><i class="bi bi-thermometer-high"></i></div>
              <h4><a class="stretched-link">Laboratorio</a></h4>
              <p>Gestiona las salidas de insumos en las distintas dependencias, garantizando que los recursos estén disponibles para su uso en prácticas, actividades y demás necesidades. Registra, supervisa y controla el movimiento de materiales, asegurando un seguimiento preciso y una administración eficiente del inventario.</p>
            </div>
          </div>

          <div class="col-xl-3 col-md-6 d-flex" data-aos="fade-up" data-aos-delay="200">
            <div class="service-item position-relative">
              <div class="icon"><i class="bi bi-bicycle icon"></i></div>
              <h4><a class="stretched-link">Deportes</a></h4>
              <p>Gestiona las entradas y salidas asegurando que los recursos estén siempre disponibles para su uso en entrenamientos, eventos y actividades diarias de cada dependencia. Además de registrar, editar o incluso eliminar elementos del inventario, permite llevar un control detallado de los insumos, optimizando su distribución y garantizando un uso eficiente dentro de la institución.</p>
            </div>
          </div>

          <div class="col-xl-3 col-md-6 d-flex" data-aos="fade-up" data-aos-delay="300">
            <div class="service-item position-relative">
              <div class="icon"><i class="bi bi-heart icon"></i></div>
              <h4><a class="stretched-link">Bienestar</a></h4>
              <p>Controla las entradas y salidas de recursos destinados al bienestar, garantizando que los insumos y materiales estén disponibles para actividades recreativas, culturales y de apoyo estudiantil. Además, permite registrar, editar y eliminar elementos del inventario para mantener una gestión eficiente.</p>
            </div>
          </div>

          <div class="col-xl-3 col-md-6 d-flex" data-aos="fade-up" data-aos-delay="400">
            <div class="service-item position-relative">
              <div class="icon"><i class="bi bi-house-door icon"></i></div>
              <h4><a class="stretched-link">Hospedaje</a></h4>
              <p>Administra los recursos de hospedaje asegurando la disponibilidad de insumos para las estancias de aprendices y personal. Gestiona de manera eficiente el inventario de habitaciones, mobiliario y suministros esenciales, con opciones para registrar, actualizar o eliminar elementos según las necesidades operativas.</p>
            </div>
          </div>

        </div>

      </div>

    </section>

    <!-- Faq -->
    <section id="faq" class="faq section light-background">


      <div class="container section-title" data-aos="fade-up">
        <h2>Preguntas Frecuentes</h2>
        <p>Aquí encontrarás las preguntas más frecuentes sobre SICC y sus funciones.
          A continuación, podrás conocer cómo gestionar el inventario, realizar entradas y salidas de recursos,
          acceder a reportes detallados y mucho más.</p>
      </div>

      <div class="container">

        <div class="row">

          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">

            <div class="faq-container">

              <div class="faq-item">
                <h3>¿Cómo se asegura que los recursos estén disponibles en tiempo real?</h3>
                <div class="faq-content">
                  <p>SICC registra cada entrada y salida de recursos al instante, lo que garantiza un monitoreo continuo
                    y
                    mejora la trazabilidad. Con esta función de monitoreo en tiempo real, siempre tendrás una visión
                    clara
                    y actualizada de los recursos disponibles en cada dependencia.</p>
                </div>
                <i class="faq-toggle bi bi-chevron-right"></i>
              </div>

              <div class="faq-item">
                <h3>¿Cómo puedo acceder a los datos de cada dependencia?</h3>
                <div class="faq-content">
                  <p>Como encargado, podrás visualizar el inventario, registrar entradas y salidas, y ver las entradas
                    realizadas por el administrador. Como administrador, podrás gestionar entradas, visualizar el
                    inventario
                    y revisar las salidas generadas por los encargados de cada dependencia.</p>
                </div>
                <i class="faq-toggle bi bi-chevron-right"></i>
              </div>

              <div class="faq-item">
                <h3>¿Puedo editar o eliminar elementos del inventario?</h3>
                <div class="faq-content">
                  <p>Sí, SICC permite registrar, editar y eliminar elementos del inventario en todas las dependencias
                    (Laboratorio, Deportes, Bienestar y Hospedaje). Esto te proporciona control total sobre los
                    recursos, asegurando que tu inventario esté siempre actualizado y organizado.</p>
                </div>
                <i class="faq-toggle bi bi-chevron-right"></i>
              </div>

            </div>

          </div>

          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="200">

            <div class="faq-container">

              <div class="faq-item">
                <h3>¿SICC permite realizar un seguimiento de los movimientos históricos de los recursos?</h3>
                <div class="faq-content">
                  <p>Sí, SICC mantiene un historial completo de todas las entradas y salidas de los recursos,
                    permitiendo
                    un seguimiento detallado y la trazabilidad de cada movimiento, lo que facilita la auditoría y el
                    análisis de la gestión de inventarios a lo largo del tiempo.</p>
                </div>
                <i class="faq-toggle bi bi-chevron-right"></i>
              </div>

              <div class="faq-item">
                <h3>¿Qué tipo de reportes genera SICC?</h3>
                <div class="faq-content">
                  <p>SICC genera reportes detallados sobre las entradas y salidas de recursos, con información clave
                    como
                    la fecha, la dependencia, el encargado, y la cantidad de recursos. Estos informes permiten analizar
                    el movimiento de los recursos y tomar decisiones informadas.</p>
                </div>
                <i class="faq-toggle bi bi-chevron-right"></i>
              </div>

              <div class="faq-item">
                <h3>¿Cómo se gestionan los permisos de usuario en SICC?</h3>
                <div class="faq-content">
                  <p>SICC permite gestionar los permisos de usuario según el rol asignado. Los administradores tienen
                    acceso completo a todas las funciones del sistema, mientras que los encargados de cada dependencia
                    solo pueden gestionar los recursos dentro de su área específica, lo que asegura un control adecuado
                    y una distribución segura de las responsabilidades.</p>
                </div>
                <i class="faq-toggle bi bi-chevron-right"></i>
              </div>

            </div>

          </div>

        </div>

      </div>

    </section>

    <!-- Equipo -->
    <section id="team" class="team section">


      <div class="container section-title" data-aos="fade-up">
        <h2>Equipo</h2>
        <p>Este es el equipo trabajó en el desarrollo del Sistema de Consumo Controlado - SICC, combinando sus
          habilidades para crear un sistema eficiente y fácil de usar.</p>
      </div>

      <div class="container">

        <div class="row gy-4">

          <div class="col-xl-3 col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="100">
            <div class="member">
              <img src="views/fotos/Hayder.jpeg" class="img-fluid" alt="Hayder Palacios">
              <div class="member-info">
                <div class="member-info-content">
                  <h4>Hayder Palacios</h4>
                  <span>Desarrollador Fullstack</span>
                </div>
                <div class="social">
                  <a href=""><i class="bi bi-twitter-x"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="200">
            <div class="member">
              <img src="views/fotos/Carlos.jpeg" class="img-fluid" alt="Carlos Guerrero">
              <div class="member-info">
                <div class="member-info-content">
                  <h4>Carlos Guerrero</h4>
                  <span>Desarrollador Fullstack</span>
                </div>
                <div class="social">
                  <a href=""><i class="bi bi-twitter-x"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="300">
            <div class="member">
              <img src="views/fotos/Camilo.jpeg" class="img-fluid" alt="Camilo Gutierrez">
              <div class="member-info">
                <div class="member-info-content">
                  <h4>Camilo Gutierrez</h4>
                  <span>Desarrollador Fullstack</span>
                </div>
                <div class="social">
                  <a href=""><i class="bi bi-twitter-x"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="400">
            <div class="member">
              <img src="views/fotos/Nicol.jpeg" class="img-fluid" alt="Nicol Portilla">
              <div class="member-info">
                <div class="member-info-content">
                  <h4>Nicol Portilla</h4>
                  <span>Desarrolladora Fullstack</span>
                </div>
                <div class="social">
                  <a href=""><i class="bi bi-twitter-x"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>

    </section>

    <!--Contacto -->
    <section id="contact" class="contact section">


      <div class="container section-title" data-aos="fade-up">
        <h2>Contacto</h2>
      </div>

      <div class="container" data-aos="fade-up" data-aos-delay="100">

        <div class="row gy-4">

          <div class="col-lg-5">

            <div class="info-wrap">
              <div class="info-item d-flex" data-aos="fade-up" data-aos-delay="200">
                <i class="bi bi-geo-alt flex-shrink-0"></i>
                <div>
                  <h3>Dirección</h3>
                  <p>Cl. 2 #13 - 3, Villeta, Cundinamarca</p>
                </div>
              </div>

              <div class="info-item d-flex" data-aos="fade-up" data-aos-delay="300">
                <i class="bi bi-telephone flex-shrink-0"></i>
                <div>
                  <h3>Contacto</h3>
                  <p>3234567654</p>
                </div>
              </div>

              <div class="info-item d-flex" data-aos="fade-up" data-aos-delay="400">
                <i class="bi bi-envelope flex-shrink-0"></i>
                <div>
                  <h3>Email</h3>
                  <p>info@gmail.com</p>
                </div>
              </div>

              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d10918.71368349174!2d-74.4757997761528!3d5.011064981066266!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e409a382b430215%3A0xc52e02a6d349782a!2sSENA%2C%20CDAE%20Villeta!5e0!3m2!1ses-419!2sco!4v1742919758154!5m2!1ses-419!2sco"
                frameborder="0" style="border:0; width: 100%; height: 270px;" allowfullscreen="" loading="lazy"
                referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
          </div>

          <div class="col-lg-7">

            <div class="info-wrap">
              <div class="info-item d-flex" data-aos="fade-up" data-aos-delay="200">


                <div class="info-item d-flex" data-aos="fade-up" data-aos-delay="400">
                  <div>
                    <h4><strong>Cabe resaltar!</strong></h4>
                    <p>El sistema SICC fue creado para uso exclusivo de la institución SENA, con el objetivo de proporcionar
                      una herramienta que facilite el manejo de algunas areas de trabajo de Almacen.</p>
                    <br>
                  </div>
                </div>
              </div>

            </div>

          </div>

    </section>

  </main>


  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i
      class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="vendor/aos/aos.js"></script>
  <script src="vendor/glightbox/js/glightbox.min.js"></script>
  <script src="vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
  <script src="vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Main JS File -->
  <script src="views/js/main.js"></script>

</body>

</html>