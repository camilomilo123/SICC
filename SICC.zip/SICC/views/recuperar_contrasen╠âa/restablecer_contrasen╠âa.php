<?php
require '../../controllers/restablecercontroller.php';

if (isset($_POST['restablecer'])) {
    $controller = new UsuarioController();
    $token = $_POST['token'];
    $nuevaContraseña = $_POST['nueva_contrasena'];

    if ($controller->restablecerContraseña($token, $nuevaContraseña)) {
        $mensaje = "cambiada";
    } else {
        $mensaje = "error";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restablecer Contraseña</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- MDBootstrap CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex align-items-center" style="height: 100vh;">

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <div class="card shadow-lg">
                    <div class="card-body p-5 text-center">
                        <h2 class="text-success mb-4">Cambiar Contraseña</h2>
                        <p class="text-dark">Ingresa tu nueva contraseña para actualizarla.</p>

                        <form method="POST" action="../../controllers/restablecercontroller.php">
                         <input type="hidden" name="token" value="<?php echo $_GET['token'] ?? ''; ?>">
                          <div class="mb-4">
                           <input type="password" class="form-control" name="nueva_contrasena" placeholder="Nueva contraseña" required>
                          </div>
                         <button type="submit" name="restablecer" class="btn btn-success w-100">Cambiar Contraseña</button>
                        </form>


                        <?php if (isset($mensaje) && $mensaje == "cambiada") { ?>
                            <div class="alert alert-success mt-4">
                                Cambio de contraseña exitoso. Redirigiendo al <a href="../../index.php" class="alert-link">inicio</a> en 5 segundos.
                            </div>
                            <script>
                                setTimeout(function() {
                                    window.location.href = "../../index.php";
                                }, 5000);
                            </script>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- MDBootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.js"></script>

</body>
</html>
