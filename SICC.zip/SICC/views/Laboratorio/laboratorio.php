<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

if (!isset($_SESSION['username'])) {
    header("Location: ../../index.php");
    exit();
}

$username = $_SESSION['username'];
$image = isset($_SESSION['profile_image']) ? $_SESSION['profile_image'] : 'default.jpg';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SICC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="icon" href="../../views/icons/hexagon-fill.svg" type="image/x-icon">



    <link href="https://cdn.lineicons.com/4.0/lineicons.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/administrador.css">
    <link rel="stylesheet" href="../css/Notificaciones.css">
</head>

<body>

    <div class="wrapper">

        <aside id="sidebar" class="expand">
            <div class="d-flex">
                <button class="toggle-btn" type="button">
                    <i class="bi bi-hexagon-fill"></i>
                </button>
                <div class="sidebar-logo">
                    <a href="#" style="font-size: 25px;">Laboratorio</a>
                </div>
            </div>

            <ul class="sidebar-nav">
                <li class="sidebar-item">
                    <a href="laboratorio.php" class="sidebar-link">
                        <i class="bi bi-house-door-fill"></i>
                        <span>Inicio</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse" data-bs-target="#lab-options">
                        <i class="bi bi-grid-fill"></i> Operaciones</a>

                    <ul id="lab-options" class="sidebar-dropdown list-unstyled collapse">
                        <li class="sidebar-item">
                            <a href="inventario.php" class="sidebar-link"><i class="bi bi-clipboard-fill"></i>Inventario</a>
                        </li>
                        <li class="sidebar-item">
                            <a href="laboratorio_entradas.php" class="sidebar-link">
                                <i class="bi bi-caret-up"></i> Entradas
                            </a>
                        </li>


                        <li class="sidebar-item">
                            <a href="laboratorio_salidas.php" class="sidebar-link">
                                <i class="bi bi-caret-down"></i> Salidas
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="sidebar-item">
                    <a href="#" class="sidebar-link">
                        <i class="lni lni-popup"></i>
                        <span>Novedades</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a href="#" class="sidebar-link">
                        <i class="lni lni-cog"></i>
                        <span>Configuracion</span>
                    </a>
                </li>

                <li class="sidebar-item">
                    <a href="#" class="sidebar-link" id="logout">
                        <i class="lni lni-exit"></i>
                        <span>Logout</span>
                    </a>
                </li>
            </ul>

            <script src="../js/cerrarsesion.js"></script>

        </aside>


        <div class="main p-3">
            <div class="row page-titles mx-0">
                <div class="col-sm-6 p-md-0">
                    <div class="welcome-text">
                        <h4 class="text-dark">Bienvenido a <strong style="color: green;">sistema de consumo controlado</strong></h4>
                        <p class="mb-0">¡La solución inteligente para gestionar entradas y salidas!</p>
                    </div>
                </div>
                <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                <a class="nav-link position-relative" href="#" id="notificacionesDropdown" role="button" data-bs-toggle="dropdown">
                        <i class="bi bi-bell-fill" style="font-size: 25px; padding-right: 10px;"></i>
                        <span id="notificacionesContador" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger d-none">
                            0
                        </span>
                    </a>
                    <ul id="notificacionesLista" class="dropdown-menu dropdown-menu-end">
                        <li><p class="dropdown-item text-center">No hay notificaciones</p></li>
                    </ul>
                    <script src="../js/NotificacionesLab.js"></script>
                   

                    
                    
                    <ol class="breadcrumb bold" style="font-size:20px;">
                        <?php echo htmlspecialchars($_SESSION['username']); ?>
                        <i class="bi bi-person-fill"></i>
                    </ol>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3 col-sm-6">
                    <div class="card">
                        <div class="stat-widget-one card-body">
                            <div class="stat-icon d-inline-block">
                                <i class="bi bi-arrow-up-circle-fill text-success border-success"></i>
                            </div>
                            <div class="stat-content d-inline-block">
                                <div class="stat-text">Entradas</div>
                                <div class="stat-digit" id="totalEntradas">0</div>
                                <script src="../js/ContarEntradaLab.js"></script>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="card">
                        <div class="stat-widget-one card-body">
                            <div class="stat-icon d-inline-block">
                                <i class="bi bi-arrow-down-circle-fill text-danger border-danger"></i>
                            </div>
                            <div class="stat-content d-inline-block">
                                <div class="stat-text">salidas</div>
                                <div class="stat-digit" id="totalSalidas">0</div>
                                <script src="../js/ContarSalidaLab.js"></script>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="card">
                        <div class="stat-widget-one card-body">
                            <div class="stat-icon d-inline-block">
                                <i class="bi bi-box-fill text-muted "></i>
                            </div>
                            <div class="stat-content d-inline-block">
                                <div class="stat-text">Insumo</div>
                                <div class="stat-digit">770</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="card">
                        <div class="stat-widget-one card-body">
                            <div class="stat-icon d-inline-block">
                                <i class="bi bi-people-fill"></i>
                            </div>
                            <div class="stat-content d-inline-block">
                                <div class="stat-text">Usuarios</div>
                                <div class="stat-digit">4</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12 ">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">cantidad de insumos</h4>
                        </div>
                        <div class="card-body">
                            
                            <canvas id="myChart"></canvas>
                        
                            <button id="prevPage" class="btn btn-primary btn-sm" >Anterior</button>
                        
                            <button id="nextPage" class="btn btn-primary btn-sm">Siguiente</button>
                            <script src="../js/grafico_reactivos.js"></script>
                        
                        </div>
                        
                        
                    </div>
                </div>
                
            </div>
            <div class="row"> <!-- Contenedor de fila -->
            <div class="col-md-4">
                    <div class="card">
                        <div class="card-body ">
                            <h4 class="card-title">laboratorio</h4>
                            <canvas id="graficoEntradasSalidas"></canvas>
                            <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
                            <script src="../js/EntradasSalidasGrafico.js"></script>
                            
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6 col-xxl-6 col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Roles del sistema </h4>
                        </div>
                        <div class="card-body">
                            <div class="recent-comment m-t-15">
                                <div class="media">
                                    <div class="media-left">
                                        <a href="#"><img class="media-object mr-3" src="../img/senap.jpg" alt="..."></a>
                                    </div>
                                    <div class="media-body">
                                        <h4 class="media-heading text-primary">Jefe de almacen</h4>
                                        <p>Realiza entradas y descarga reportes de estos mismos </p>
                                        <p class="comment-date">Entradas <br>Reportes </p>
                                    </div>
                                </div>
                                <div class="media">
                                    <div class="media-left">
                                        <a href="#"><img class="media-object mr-3" src="../img/senap.jpg" alt="..."></a>
                                    </div>
                                    <div class="media-body">
                                        <h4 class="media-heading text-success">Dependencia</h4>
                                        <p>Realiza las salidas del inventario</p>
                                        <p class="comment-date">Salidas</p>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-xxl-6 col-lg-6 col-md-12 col-sm-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Todo</h4>
                        </div>
                        <div class="card-body px-0">
                            <div class="todo-list">
                                <div class="tdl-holder">
                                    <div class="tdl-content widget-todo2 mr-4">
                                        <ul id="todo_list">
                                            <li><label><input type="checkbox"><i></i><span>Get up</span><a href='#'
                                                        class="ti-trash"></a></label></li>
                                            <li><label><input type="checkbox" checked><i></i><span>Stand up</span><a
                                                        href='#' class="ti-trash"></a></label></li>
                                            <li><label><input type="checkbox"><i></i><span>Don't give up the
                                                        fight.</span><a href='#' class="ti-trash"></a></label></li>
                                            <li><label><input type="checkbox" checked><i></i><span>Do something
                                                        else</span><a href='#' class="ti-trash"></a></label></li>
                                            <li><label><input type="checkbox" checked><i></i><span>Stand up</span><a
                                                        href='#' class="ti-trash"></a></label></li>
                                            <li><label><input type="checkbox"><i></i><span>Don't give up the
                                                        fight.</span><a href='#' class="ti-trash"></a></label></li>
                                        </ul>
                                    </div>
                                    <div class="px-4">
                                        <input type="text" class="tdl-new form-control" placeholder="Write new item and hit 'Enter'...">
                                        <script src="../js/dashboard-2.js"></script>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

        <script src="../js/selector.js"></script>

</body>

</html>