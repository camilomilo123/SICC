<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

if (!isset($_SESSION['username'])) {
    header("Location: ../../index.php");
    exit();
}

$username = $_SESSION['username'];
$image = isset($_SESSION['profile_image']) ? $_SESSION['profile_image'] : 'default.jpg';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SICC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="icon" href="../../views/icons/hexagon-fill.svg" type="image/x-icon">
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.2/css/buttons.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>



    <link href="https://cdn.lineicons.com/4.0/lineicons.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/administrador.css">
</head>

<body>

    <div class="wrapper">

        <aside id="sidebar" class="expand">
            <div class="d-flex">
                <button class="toggle-btn" type="button">
                    <i class="bi bi-hexagon-fill"></i>
                </button>
                <div class="sidebar-logo">
                    <a href="#" style="font-size: 25px;">Laboratorio</a>
                </div>
            </div>

            <ul class="sidebar-nav">
                <li class="sidebar-item">
                    <a href="laboratorio.php" class="sidebar-link">
                        <i class="bi bi-house-door-fill"></i>
                        <span>Inicio</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse" data-bs-target="#lab-options">
                        <i class="bi bi-grid-fill"></i> Operaciones</a>

                    <ul id="lab-options" class="sidebar-dropdown list-unstyled collapse">
                        <li class="sidebar-item">
                            <a href="laboratorio_entradas.php" class="sidebar-link">
                                <i class="bi bi-caret-up"></i> Entradas
                            </a>
                        </li>

                        <li class="sidebar-item">
                            <a href="laboratorio_salidas.php" class="sidebar-link">
                                <i class="bi bi-caret-down"></i> Salidas
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="sidebar-item">
                    <a href="#" class="sidebar-link">
                        <i class="lni lni-popup"></i>
                        <span>Novedades</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a href="#" class="sidebar-link">
                        <i class="lni lni-cog"></i>
                        <span>Configuracion</span>
                    </a>
                </li>
            </ul>

            <div class="sidebar-footer">
                <a href="#" class="sidebar-link" id="logout">
                    <i class="lni lni-exit"></i>
                    <span>Logout</span>
                </a>
            </div>
            <script src="../js/cerrarsesion.js"></script>

        </aside>


        <div class="main p-3">
        <div class="row page-titles mx-0 bold">
                <div class="col-sm-6 p-md-0">
                    <div class="welcome-text d-flex align-items-center">
                        <img src="../img/sena.png" style="width: 60px; height: auto;" alt="" class="me-3">
                        <div>
                        <h4 style="color: black;" class="bold" st>Bienvenido a <strong class="bold" style="color: green;">sistema de consumo controlado</strong></h4>
                            <p class="mb-0">¡La solución inteligente para gestionar entradas y salidas!</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                    <ol class="breadcrumb" style="font-size:20px;">
                      <?php echo htmlspecialchars($_SESSION['username']); ?>
                      <i class="bi bi-person-fill"></i>
                    </ol>
                </div>
        </div>

            <div class="container">
            <h2><strong style="color: green;">Entradas de laboratorio</strong></h2>
                <table id="Tabla_inventario" class="table table-striped">
        <thead class="table-dark">
            <tr>
                <th>Fecha</th>
                <th>Dependencia</th>
                <th>Responsable</th>
                <th>Reactivo</th>
                <th>Cantidad Anterior</th>
                <th>Cantidad Ingresada</th>
                <th>Cantidad Total</th>
                <th>Unidad Medida</th>
            </tr>
        </thead>
        <tbody>
        <script src="../js/TablaEntradas.js"></script>
            <!-- Los datos se cargarán dinámicamente con DataTables -->
        </tbody>
    </table>
    <!-- DataTables Scripts -->
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.print.min.js"></script>
                
            </div>
        </div>
    </div>

    <script src="../js/selector.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>