<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once "../../models/mostrarmodels.php";
$model = new InventarioModel();
$inventario = $model->obtenerInventario();

session_start();

if (!isset($_SESSION['username'])) {
    header("Location: ../../index.php");
    exit();
}

$username = $_SESSION['username'];
$image = isset($_SESSION['profile_image']) ? $_SESSION['profile_image'] : 'default.jpg';

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SICC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link href="https://cdn.lineicons.com/4.0/lineicons.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/administrador.css">
    <link rel="stylesheet" href="./css/pdf.css" media="print">
</head>

<body>
    <div class="wrapper">

        <aside id="sidebar" class="expand">
            <div class="d-flex">
                <button class="toggle-btn" type="button">
                    <i class="bi bi-hexagon-fill"></i>
                </button>
                <div class="sidebar-logo">
                    <a href="#" style="font-size: 25px;">Laboratorio</a>
                </div>
            </div>

            <ul class="sidebar-nav">
                <li class="sidebar-item">
                    <a href="laboratorio.php" class="sidebar-link">
                        <i class="bi bi-house-door-fill"></i>
                        <span>Inicio</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse" data-bs-target="#lab-options">
                        <i class="bi bi-grid-fill"></i> Operaciones</a>

                    <ul id="lab-options" class="sidebar-dropdown list-unstyled collapse">
                        <li class="sidebar-item">
                            <a href="laboratorio_entradas.php" class="sidebar-link">
                                <i class="bi bi-caret-up"></i> Entradas
                            </a>
                        </li>

                        <li class="sidebar-item">
                            <a href="laboratorio_salidas.php" class="sidebar-link">
                                <i class="bi bi-caret-down"></i> Salidas
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="sidebar-item">
                    <a href="#" class="sidebar-link">
                        <i class="lni lni-popup"></i>
                        <span>Novedades</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a href="#" class="sidebar-link">
                        <i class="lni lni-cog"></i>
                        <span>Configuracion</span>
                    </a>
                </li>
            </ul>

            <div class="sidebar-footer">
                <a href="../../config/cerrarsesion.php" class="sidebar-link">
                    <i class="lni lni-exit"></i>
                    <span>Logout</span>
                </a>
            </div>

        </aside>

        <div class="main p-3">

            <div style="font-size: 20px;" class="text-end">
                <?php echo htmlspecialchars($_SESSION['username']); ?>
                <i class="bi bi-person-fill"></i>
            </div>

            <div class="container">
                <h1><strong style="color: #28a745;">Salida de elementos</strong></h1>


                <form class="row g-3 align-items-center" action="../../controllers/SalidaController.php" method="POST">
                    <div class="col-md-5">
                        <label for="insumo" class="form-label mb-3">Selecciona un ítem:</label>
                        <select id="insumo" name="insumo" class="form-select" required>

                            <option value="">Cargando...</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label for="cantidad" class="form-label mb-3">Cantidad:</label>
                        <input type="number" id="cantidad" name="cantidad" class="form-control" required>
                    </div>
                    <div class="col-md-3">
                        <label for="unidad_medida" class="form-label mb-3">Unidad de Medida:</label>
                        <select id="unidad_medida" name="unidad_medida" class="form-select" required>
                            <option value="" selected disabled>Seleccione una unidad</option>
                            <option value="unidad">Unidad</option>
                            <option value="litro">Litro</option>
                            <option value="miligramos">Miligramos</option>
                            <option value="gramos">Gramos</option>
                            <option value="kilogramos">Kilogramos</option>
                            <option value="mililitros">Mililitros</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="descripcion" class="form-label mb-3">Descripción del Consumo:</label>
                        <textarea id="descripcion" name="descripcion" class="form-control" rows="2" required></textarea>
                    </div>
                    <input type="hidden" name="dependencia" value="laboratorio">
                    <div class="col-md-3 d-flex align-items-end" style="padding-top: 41px;">
                        <button class="btn btn-primary btn-sm w-100" style="background-color: #28a745; color: white; border: 2px solid #28a745;" type="submit">Generar Salida</button>
                    </div>
                </form>
                <hr>
                <br>
                <h2>Salidas Registradas</h2>
                <table class="table">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>responsable</th>
                            <th>Insumo</th>
                            <th>Cantidad</th>
                            <th>Unidad</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($inventario as $item): ?>
                            <tr>
                                <td><?= htmlspecialchars($item['id']); ?></td>
                                <td><?= htmlspecialchars($_SESSION['username']); ?></td>
                                <td><?= htmlspecialchars($item['insumo']); ?></td>
                                <td><?= htmlspecialchars($item['cantidad_salida']); ?></td>
                                <td><?= htmlspecialchars($item['unidad_medida']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
</body>

</html>
<script src="../js/selector.js"></script>
<script src="../js/actualizar_tab.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>