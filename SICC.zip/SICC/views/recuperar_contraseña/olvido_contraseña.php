<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperar Contraseña</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- MDBootstrap CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex align-items-center" style="height: 100vh;">

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6"> 
                <div class="card shadow-lg">
                    <div class="card-body p-5 text-center">
                        <h2 class="text-success mb-4">Restablecer Contraseña</h2> 
                        <p class="text-dark">Ingresa tu correo electrónico para recibir instrucciones de recuperación.</p>
                        
                        <form action="../../controllers/restablecercontroller.php" method="POST">
                            <div class="mb-4">
                                <input type="email" class="form-control" name="email" placeholder="email" required>
                            </div>
                            <button type="submit" name="recuperar" class="btn btn-success w-100">Enviar Instrucciones</button> 
                        </form>

                        <div class="d-flex justify-content-between mt-4">
                            <a href="../../index.php" class="text-success text-decoration-none d-block ">Iniciar Sesión</a> 
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- MDBootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.js"></script>

</body>
</html>
