<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="/assets/logo-vt.svg">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="icon" href="../../views/icons/hexagon-fill.svg" type="image/x-icon">
    <link rel="stylesheet" href="../css/index.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex justify-content-center align-items-center vh-100">
    <div class="bg-white p-5 rounded-5 text-secondary shadow" style="width: 25rem">
        <div class="d-flex justify-content-center">
            <img src="..//icons/hexagon-fill.svg" alt="login-icon" style="height: 7rem">
        </div>
        <div class="text-center fs-1 bold">SICC</div>

        <!-- FORMULARIO -->
        <form action="../../config/InicioSesion.php" method="POST" >
            <div class="input-group mt-4 ">
                <div class="input-group-text bg-success">
                    <img src="../icons/user-icon.svg" alt="username-icon" style="height: 1rem">
                </div>
                <input class="form-control bg-light " type="email" name="correo" placeholder="Correo" required>
            </div>

            <div class="input-group mt-3  ">
                <div class="input-group-text bg-success">
                    <img src="../icons/password-icon.svg" alt="password-icon" style="height: 1rem">
                </div>
                <input class="form-control bg-light " type="password" name="password" placeholder="Contraseña" required>
            </div>

            <button type="submit" class="btn btn-success text-white w-100 mt-4 ">Iniciar Sesión</button>
            <hr class="my-4">
            <a href="../recuperar_contra/olvido_contrasena.php" class="text-success d-block text-center  ">¿Olvidaste tu contraseña?</a>
            </form>

        

    </div>
</body>
</html>