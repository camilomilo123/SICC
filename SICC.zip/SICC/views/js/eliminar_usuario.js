$(document).ready(function () {
    $(".btn-eliminar").click(function () {
        let idUsuario = $(this).data("id");

        if (confirm("¿Estás seguro de que deseas eliminar este usuario?")) {
            $.ajax({
                url: "../../controllers/UsuarioController.php", // Verifica la ruta
                type: "POST",
                data: { action: "delete", id: idUsuario }, // Agregamos 'action'
                dataType: "json",
                success: function (response) {
                    if (response.success) { // 'success' en el JSON del backend
                        alert("✅ Usuario eliminado con éxito.");
                        $("#fila_" + idUsuario).remove(); // Elimina la fila de la tabla
                    } else {
                        alert("❌ Error: " + (response.error || "No se pudo eliminar."));
                    }
                },
                error: function (xhr, status, error) {
                    console.error("Error AJAX:", status, error);
                    alert("❌ Error en la solicitud AJAX.");
                }
            });
        }
    });
});

