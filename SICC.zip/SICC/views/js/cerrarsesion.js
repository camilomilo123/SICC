document.getElementById("logout").addEventListener("click", function(event) {
    event.preventDefault(); // Evita que el enlace funcione de inmediato
    
    Swal.fire({
        title: "¿Estás seguro?",
        text: "Se cerrará tu sesión.",
        icon: "warning",
        
        showCancelButton: true,
        confirmButtonColor: "#d33",
        cancelButtonColor: "#818285",
        confirmButtonText: "Sí, cerrar sesión",
        cancelButtonText: "Cancelar"
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = "../../config/cerrarsesion.php"; // Redirige si confirma
        }
    });
});