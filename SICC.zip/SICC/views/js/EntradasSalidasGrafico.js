document.addEventListener("DOMContentLoaded", function () {
    fetch("../../controllers/ReporteController.php?action=obtenerDatosGrafico")
        .then(response => response.json())
        .then(data => {
            const ctx = document.getElementById("graficoEntradasSalidas").getContext("2d");

            new Chart(ctx, {
                type: "doughnut", // Gráfico circular
                data: {
                    labels: ["Entradas", "Salidas"],
                    datasets: [{
                        data: [data.entradas, data.salidas],
                        backgroundColor: ["#36A2EB", "#FF6384"], // Azul para entradas, rojo para salidas
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: "top"
                        }
                    }
                }
            });
        })
        .catch(error => console.error("Error al obtener datos:", error));
});
