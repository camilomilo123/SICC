document.addEventListener("DOMContentLoaded", function () {
    let vista = "laboratorio"; // Valor por defecto

    // Comprobar la URL actual para determinar la vista
    if (window.location.pathname.includes("admin")) {
        vista = "administrador";
    } else if (window.location.pathname.includes("Lab_admin")) {
        vista = "laboratorio";
    }

    function cargarNotificaciones() {
        fetch("../../controllers/NotificacionesController.php?action=obtenerNotificaciones&categoria=laboratorio")
            .then(response => response.json())
            .then(data => {
                let contador = document.getElementById("notificacionesContador");
                let lista = document.getElementById("notificacionesLista");

                lista.innerHTML = ""; // Limpiar notificaciones anteriores

                // Filtrar solo las notificaciones de tipo "entrada"
                let notificacionesEntrada = data.notificaciones.filter(notificacion => notificacion.tipo === "entrada");

                // Actualizar el contador solo con las entradas no leídas
                let noLeidas = notificacionesEntrada.filter(notificacion => !notificacion.leida);
                if (noLeidas.length > 0) {
                    contador.textContent = noLeidas.length;
                    contador.classList.remove("d-none");
                } else {
                    contador.classList.add("d-none");
                }

                // Mostrar solo las notificaciones de entradas
                notificacionesEntrada.forEach(notificacion => {
                    let urlDestino = "laboratorio_entradas.php"; // Solo muestra entradas

                    // Determinar la clase CSS según si ha sido leída
                    let claseLeida = notificacion.leida ? "leida" : "";

                    let item = document.createElement("li");
                    item.innerHTML = `
                        <a class="dropdown-item notificacion entrada ${claseLeida}" href="${urlDestino}" data-id="${notificacion.id}">
                            ${notificacion.mensaje}
                        </a>
                    `;
                    lista.appendChild(item);
                });

                // Marcar como leída cuando se haga clic en una notificación
                document.querySelectorAll(".notificacion").forEach(item => {
                    item.addEventListener("click", function () {
                        marcarNotificacionLeida(this.getAttribute("data-id"));
                    });
                });
            })
            .catch(error => console.error("Error al obtener notificaciones:", error));
    }

    function marcarNotificacionLeida(id) {
        fetch("../../controllers/NotificacionesController.php?action=marcarLeida", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ id: id }),
        })
        .then(response => response.json())
        .then(() => {
            // Recargar notificaciones después de marcar como leída
            cargarNotificaciones();
        })
        .catch(error => console.error("Error al marcar notificación como leída:", error));
    }

    // Evento al abrir el dropdown para limpiar el contador
    document.getElementById("notificacionesDropdown").addEventListener("click", function () {
        document.getElementById("notificacionesContador").classList.add("d-none");
    });

    setInterval(cargarNotificaciones, 5000); // Recargar cada 5 segundos
    cargarNotificaciones(); // Cargar inmediatamente
});
