
    $(document).ready(function() {
        $("#formSalida").submit(function(event) {
            event.preventDefault();

            $.ajax({
                url: "../../controllers/SalidaController.php",
                type: "POST",
                data: $(this).serialize(),
                dataType: "json",
                success: function(response) {
                    if (response.status === "success") {
                        alert(response.message);
                        actualizarTabla(response.nueva_salida);
                    } else {
                        alert(response.message);
                    }
                },
                error: function() {
                    alert("Error al procesar la solicitud.");
                }
            });
        });

        function actualizarTabla(data) {
            let nuevaFila = `<tr>
                <td>${data.dependencia}</td>
                <td>${data.insumo}</td>
                <td>${data.unidad_medida}</td>
                <td>${data.cantidad_salida}</td>
                <td>${data.cantidad_total}</td>
                <td>${data.descripcion}</td>
                <td>${data.fecha}</td>
            </tr>`;
            $("#tablaSalidas tbody").prepend(nuevaFila);
        }
    });
   