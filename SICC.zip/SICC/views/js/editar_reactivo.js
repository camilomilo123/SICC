document.getElementById("formulario").addEventListener("submit", function(e) {
    e.preventDefault(); 

    Swal.fire({
        title: '¿Confirmas la edición del reactivo?',
        text: "Estás a punto de editar la información del reactivo.",
        icon: 'warning',
        showCancelButton: true,
        cancelButtonText: 'Cancelar',
        confirmButtonText: 'Sí, actualizar',
        confirmButtonColor: '#008f39', 
        cancelButtonColor: '#d33'
    }).then((result) => {
        if (result.isConfirmed) {
            Swal.fire({
                title: 'reactivo actualizado!',
                text: 'La información del insumo se edito correctamente.',
                icon: 'success',
                confirmButtonText: 'Aceptar',
                confirmButtonColor: '#008f39'
            }).then(() => {
                document.getElementById("formulario").submit();
            });
        } else {
            Swal.fire({
                title: 'Operación cancelada',
                text: 'No se realizaron cambios en el reactivo.',
                icon: 'error',
                confirmButtonText: 'Aceptar',
                confirmButtonColor: '#d33' 
            });
        }
    });
});

// Manejo del botón de volver
document.querySelectorAll('a[href="Inv_lab.php"]').forEach(button => {
    button.addEventListener('click', function(event) {
        event.preventDefault();
        window.location.href = "Inv_lab.php";
    });
});