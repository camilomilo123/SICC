$(document).ready(function () {
    $.ajax({
        url: '../../controllers/InventarioController.php?action=listar',
        type: 'GET',
        dataType: 'json',
        success: function (data) {
            let select = $('#inventario, #insumo'); 
            select.empty();
            select.append('<option value="">Seleccione una opción</option>');
            data.forEach(function (item) {
                select.append(`<option value="${item.id}">${item.reactivo}</option>`);
            });
        },
        error: function () {
            alert('Error al cargar los datos.');
        }
    });
});
