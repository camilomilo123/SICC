$("#formulario").submit(function(e) {
    e.preventDefault(); 

    Swal.fire({
        title: '¿Deseas confirmar esta salida?',
        text: "Estás a punto de registrar la salida de un insumo.",
        icon: 'warning',
        showCancelButton: true,
        cancelButtonText: 'Cancelar',
        confirmButtonText: 'Sí, registrar salida',
        confirmButtonColor: '#008f39', 
        cancelButtonColor: '#d33' 
    }).then((result) => {
        if (result.isConfirmed) {
            // Recoger los datos del formulario
            var formData = $("#formulario").serialize();

            $.ajax({
                url: "../../controllers/SalidaController.php",
                type: "POST",
                data: formData,
                dataType: "json",
                success: function(response) {
                    if (response.status === "success") {
                        Swal.fire({
                            title: '¡Salida registrada!',
                            text: 'El insumo ha sido descontado correctamente del inventario.',
                            icon: 'success',
                            confirmButtonColor: '#008f39'
                        }).then(() => {
                            location.reload();
                        });
                    } else {
                        Swal.fire({
                            title: '❌ Error al registrar',
                            text: response.message,
                            icon: 'error',
                            confirmButtonColor: '#d33'
                        });
                    }
                },
                error: function() {
                    Swal.fire({
                        title: '⚠️ Error de conexión',
                        text: 'Hubo un problema con el servidor. Intenta nuevamente.',
                        icon: 'error',
                        confirmButtonColor: '#d33'
                    });
                }
            });
        }
    });
});