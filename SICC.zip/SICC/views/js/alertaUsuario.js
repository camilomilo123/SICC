setTimeout(() => {
    let mensaje = document.getElementById("mensaje");
    if (mensaje) mensaje.style.display = "none";
}, 3000);