function actualizarContadorSalidas() {
    fetch("../../controllers/EntradasController.php?action=contarSalidas")
        .then(response => response.json())
        .then(data => {
            document.getElementById("contadorSalidas").textContent = data.total;
        })
        .catch(error => console.error("Error al obtener las salidas:", error));
}

// Llamar a la función al cargar la página
document.addEventListener("DOMContentLoaded", actualizarContadorSalidas);
