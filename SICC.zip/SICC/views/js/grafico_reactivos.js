let currentPage = 1;  // Página actual
const itemsPerPage = 8;  // Número de elementos por página
let chartInstance = null;  // Variable para guardar la instancia del gráfico

document.addEventListener("DOMContentLoaded", function () {
    // Función para cargar los datos y graficar
    function cargarDatos(page) {
        fetch("../../controllers/get_chart_data.php")
            .then(response => response.json())
            .then(data => {
                // Calcular el rango de datos a mostrar según la página actual
                const start = (page - 1) * itemsPerPage;
                const end = start + itemsPerPage;
                const paginatedData = data.slice(start, end);

                // Obtener las etiquetas (reactivos) y cantidades para el gráfico
                const labels = paginatedData.map(item => item.reactivo);
                const cantidades = paginatedData.map(item => item.cantidad);

                // Obtener el contexto del gráfico
                const ctx = document.getElementById('myChart').getContext('2d');

                // Si ya existe una instancia del gráfico, destruirla
                if (chartInstance) {
                    chartInstance.destroy();
                }

                // Crear el gráfico
                chartInstance = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: 'Cantidad Disponible laboratorio',
                            data: cantidades,
                            backgroundColor: 'rgba(54, 162, 235, 0.6)',
                            borderColor: '#fff',
                            borderWidth: 2
                        }]
                    },
                    options: {
                        responsive: true,
                        scales: {
                            y: {
                                beginAtZero: true
                            }
                        }
                    }
                });

                // Actualizar la visibilidad de los botones de paginación
                // Ocultar "Anterior" si estamos en la primera página
                document.getElementById("prevPage").style.display = page === 1 ? 'none' : 'inline-block';

                // Ocultar "Siguiente" si estamos en la última página
                document.getElementById("nextPage").style.display = end >= data.length ? 'none' : 'inline-block';
            })
            .catch(error => console.error("Error al obtener los datos:", error));
    }

    // Evento para el botón "Siguiente"
    document.getElementById("nextPage").addEventListener("click", function () {
        currentPage++;
        cargarDatos(currentPage);
    });

    // Evento para el botón "Anterior"
    document.getElementById("prevPage").addEventListener("click", function () {
        if (currentPage > 1) {
            currentPage--;
            cargarDatos(currentPage);
        }
    });

    // Cargar la primera página de datos al cargar la página
    cargarDatos(currentPage);
});


