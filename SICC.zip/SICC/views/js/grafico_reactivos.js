document.addEventListener("DOMContentLoaded", function () {
    fetch("../../controllers/get_chart_data.php")
        .then(response => response.json())
        .then(data => {
            const labels = data.map(item => item.reactivo);
            const cantidades = data.map(item => item.cantidad);

            const ctx = document.getElementById('myChart').getContext('2d');
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Cantidad Disponible',
                        data: cantidades,
                        backgroundColor: 'rgba(54, 162, 235, 0.6)',
                        borderColor: '#fff',
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        })
        .catch(error => console.error("Error al obtener los datos:", error));
});