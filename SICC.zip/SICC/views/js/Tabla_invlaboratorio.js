$(document).ready(function() {
    let tabla = $('#Tabla_invlaboratorio').DataTable({
        "ajax": {
            "url": "../../controllers/InvLabController.php",
            "type": "POST",
            "dataSrc": "data"
        },
        "columns": [
            { "data": "id" },
            { "data": "reactivo" },
            { "data": "formula" },
            { "data": "estado" },
            { "data": "codigo_almacenamiento" },
            { "data": "cantidad" },
            { "data": "unidad_medida" },
            { "data": "fecha_vencimiento" },
            { "data": "lote" },
            { "data": "ubicacion" },
            {
                "data": "id",
                "render": function(data) {
                    return `<button class="btn btn-danger btnEliminar" data-id="${data}">Eliminar</button>`;
                }
            }
        ],
        "paging": true,
        "searching": true,
        "ordering": true,
        "info": true,
        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por página",
            "zeroRecords": "No se encontraron resultados",
            "info": "Mostrando _START_ a _END_ de _TOTAL_ registros",
            "infoEmpty": "No hay registros disponibles",
            "infoFiltered": "(filtrado de _MAX_ registros totales)",
            "search": "Buscar:",
            "paginate": {
                "first": "Primero",
                "last": "Último",
                "next": "Siguiente",
                "previous": "Anterior"
            }
        }
    });

    // Evento para eliminar
    $('#Tabla_invlaboratorio').on('click', '.btnEliminar', function() {
        let id = $(this).data('id');
    
        Swal.fire({
            title: "¿Estás seguro?",
            text: "Esta acción no se puede deshacer",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#d33",
            cancelButtonColor: "#3085d6",
            confirmButtonText: "Sí, eliminar",
            cancelButtonText: "Cancelar"
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: "../../controllers/InvLabController.php",
                    type: "POST",
                    data: { action: "eliminar", id: id },
                    dataType: "json",
                    success: function(response) {
                        if (response.status === "success") {
                            Swal.fire({
                                title: "Eliminado",
                                text: response.message,
                                icon: "success",
                                timer: 2000,
                                showConfirmButton: false
                            });
                            tabla.ajax.reload(null, false);
                        } else {
                            Swal.fire({
                                title: "Error",
                                text: "Error al eliminar: " + response.message,
                                icon: "error"
                            });
                        }
                    },
                    error: function(xhr, status, error) {
                        console.log(xhr.responseText);
                        Swal.fire({
                            title: "Error",
                            text: "Error en la petición AJAX: " + error,
                            icon: "error"
                        });
                    }
                });
            }
        });
    });
    
});


