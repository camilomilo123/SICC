$(document).ready(function () {
    $('#Tabla_inventario').DataTable({
"ajax": {
    "url": "../../Controllers/get_usuarios.php",
    "dataSrc": "data"
},
"columns": [
    { "data": "id_usuario" },
    { "data": "nombre" },
    { "data": "telefono" },
    { "data": "correo" },
    { "data": "rol" }  // Ahora usamos "rol" porque la consulta ya nos da el nombre del rol
],
"paging": true,
        "searching": true,
        "ordering": true,
        "info": true,
        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por página",
            "zeroRecords": "No se encontraron resultados",
            "info": "Mostrando _START_ a _END_ de _TOTAL_ registros",
            "infoEmpty": "No hay registros disponibles",
            "infoFiltered": "(filtrado de _MAX_ registros totales)",
            "search": "Buscar:",
            "paginate": {
                "first": "Primero",
                "last": "Último",
                "next": "Siguiente",
                "previous": "Anterior"
            }
        },
});

});