$(document).ready(function() {
    var tabla = $('#Tabla_invdeportes').DataTable({
        "ajax": {
            "url": "../../controllers/InvDepController.php",
            "type": "POST",
        },
        "columns": [
            { "data": "id" },
            { "data": "elemento" },
            { "data": "cantidad" },
            { "data": "unidad_medida" },
            { "data": "ubicacion" },
            {
                "data": "id",
                "render": function(data) {
                    return `<button class="btn btn-danger btnEliminar" data-id="${data}">Eliminar</button>`;
                }
            }
        ],
        "paging": true,
        "searching": true,
        "ordering": true,
        "info": true,
        "language": {
            "lengthMenu": "Mostrar _MENU_ registros por página",
            "zeroRecords": "No se encontraron resultados",
            "info": "Mostrando _START_ a _END_ de _TOTAL_ registros",
            "infoEmpty": "No hay registros disponibles",
            "infoFiltered": "(filtrado de _MAX_ registros totales)",
            "search": "Buscar:",
            "paginate": {
                "first": "Primero",
                "last": "Último",
                "next": "Siguiente",
                "previous": "Anterior"
            }
        }
    });

    // Evento para eliminar
    $('#Tabla_invdeportes').on('click', '.btnEliminar', function() {
        let id = $(this).data('id');

        if (confirm("¿Seguro que deseas eliminar este registro?")) {
            $.ajax({
                url: "../../controllers/InvDepController.php",
                type: "POST",
                data: { action: "eliminar", id: id },
                dataType: "json",
                success: function(response) {
                    if (response.status === "success") {
                        alert(response.message);
                        tabla.ajax.reload(null, false); // Recargar sin perder paginación
                    } else {
                        alert("Error al eliminar: " + response.message);
                    }
                },
                error: function(xhr, status, error) {
                    console.log(xhr.responseText);
                    alert("Error en la petición AJAX: " + error);
                }
            });
        }
    });
});



