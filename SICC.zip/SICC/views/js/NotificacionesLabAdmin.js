document.addEventListener("DOMContentLoaded", function () {
    function cargarNotificaciones() {
        fetch("../../controllers/NotificacionesController.php?action=obtenerNotificaciones&categoria=laboratorio")
            .then(response => response.json())
            .then(data => {
                let contador = document.getElementById("notificacionesContador");
                let lista = document.getElementById("notificacionesLista");

                lista.innerHTML = ""; // Limpiar notificaciones anteriores

                // Filtrar solo las notificaciones de tipo "salida"
                let notificacionesSalida = data.notificaciones.filter(notificacion => notificacion.tipo === "salida");

                // Actualizar el contador solo con las salidas no leídas
                let noLeidas = notificacionesSalida.filter(notificacion => !notificacion.leida);
                if (noLeidas.length > 0) {
                    contador.textContent = noLeidas.length;
                    contador.classList.remove("d-none");
                } else {
                    contador.classList.add("d-none");
                }

                // Mostrar solo las notificaciones de salidas
                notificacionesSalida.forEach(notificacion => {
                    let urlDestino = "Lab_admin_salida.php"; // Solo muestra salidas

                    // Determinar la clase CSS según si ha sido leída
                    let claseLeida = notificacion.leida ? "leida" : "";

                    let item = document.createElement("li");
                    item.innerHTML = `
                        <a class="dropdown-item notificacion salida ${claseLeida}" href="${urlDestino}" data-id="${notificacion.id}">
                            ${notificacion.mensaje}
                        </a>
                    `;
                    lista.appendChild(item);
                });

                // Marcar como leída cuando se haga clic en una notificación
                document.querySelectorAll(".notificacion").forEach(item => {
                    item.addEventListener("click", function () {
                        marcarNotificacionLeida(this.getAttribute("data-id"));
                    });
                });
            })
            .catch(error => console.error("Error al obtener notificaciones:", error));
    }

    function marcarNotificacionLeida(id) {
        fetch("../../controllers/NotificacionesController.php?action=marcarLeida", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ id: id }),
        })
        .then(response => response.json())
        .then(() => {
            // Recargar notificaciones después de marcar como leída
            cargarNotificaciones();
        })
        .catch(error => console.error("Error al marcar notificación como leída:", error));
    }

    // Evento al abrir el dropdown para limpiar el contador
    document.getElementById("notificacionesDropdown").addEventListener("click", function () {
        document.getElementById("notificacionesContador").classList.add("d-none");
    });

    setInterval(cargarNotificaciones, 5000); // Recargar cada 5 segundos
    cargarNotificaciones(); // Cargar inmediatamente
});
