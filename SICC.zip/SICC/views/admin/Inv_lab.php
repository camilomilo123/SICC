<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
// Verifica si el usuario ha iniciado sesión
if (!isset($_SESSION['username'])) {
    header("Location: ../../index.php"); // Redirige al login si no hay sesión
    exit();
}

// Verifica si el usuario tiene el rol de administrador
if ($_SESSION['role_id'] != 1) {
    echo "Acceso denegado";
    exit();
}


// Si el usuario es admin, continúa con la carga del contenido
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SICC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.lineicons.com/4.0/lineicons.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/administrador.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body>
    <div class="wrapper">
        <aside id="sidebar" class="expand">
            <div class="d-flex">
                <button class="toggle-btn" type="button">
                    <i class="bi bi-hexagon-fill"></i>
                </button>
                <div class="sidebar-logo">
                    <a href="#" style="font-size: 25px;">SICC</a>
                </div>
            </div>

            <ul class="sidebar-nav">
                <li class="sidebar-item">
                    <a href="administrador.php" class="sidebar-link">
                        <i class="bi bi-house-door-fill"></i>
                        <span>Inicio</span>
                    </a>
                </li>

                <li class="sidebar-item">
                    <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
                        data-bs-target="#auth" aria-expanded="false" aria-controls="auth">

                        <i class="bi bi-grid-fill"></i>
                        <span> Dependencias</span>
                    </a>

                    <ul id="auth" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">

                        <!-- Laboratorio -->
                        <li class="sidebar-item">
                            <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
                                data-bs-target="#lab-options" aria-expanded="false" aria-controls="lab-options">
                                <i class="bi bi-thermometer-high"></i>Laboratorio
                            </a>
                            <ul id="lab-options" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#auth">
                                <li class="sidebar-item">
                                    <a href="Inv_lab.php" class="sidebar-link"><i class="bi bi-clipboard-fill"></i>Inventario</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="Lab_admin_entrada.php" class="sidebar-link"><i class="bi bi-caret-up"></i>Entradas</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="Lab_admin_salida.php" class="sidebar-link"> <i class="bi bi-caret-down"></i>Salidas</a>
                                </li>
                            </ul>
                        </li>

                        <!-- Bienestar -->
                        <li class="sidebar-item">
                            <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
                                data-bs-target="#bienestar-options" aria-expanded="false" aria-controls="bienestar-options">
                                <i class="bi bi-person-arms-up"></i>Bienestar
                            </a>
                            <ul id="bienestar-options" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#auth">
                                <li class="sidebar-item">
                                    <a href="#" class="sidebar-link"> <i class="bi bi-caret-up"></i>Entradas</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="#" class="sidebar-link"> <i class="bi bi-caret-down"></i>Salidas</a>
                                </li>
                            </ul>
                        </li>

                        <!-- Deportes -->
                        <li class="sidebar-item">
                            <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
                                data-bs-target="#deportes-options" aria-expanded="false" aria-controls="deportes-options">
                                <i class="bi bi-trophy-fill"></i>Deportes
                            </a>
                            <ul id="deportes-options" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#auth">
                                <li class="sidebar-item">
                                    <a href="#" class="sidebar-link"><i class="bi bi-caret-up"></i>Entradas</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="#" class="sidebar-link"> <i class="bi bi-caret-down"></i>Salidas</a>
                                </li>
                            </ul>
                        </li>

                        <!-- Hospedaje -->
                        <li class="sidebar-item">
                            <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
                                data-bs-target="#hospedaje-options" aria-expanded="false" aria-controls="hospedaje-options">
                                <i class="bi bi-buildings-fill"></i>Hospedaje
                            </a>
                            <ul id="hospedaje-options" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#auth">
                                <li class="sidebar-item">
                                    <a href="#" class="sidebar-link"><i class="bi bi-caret-up"></i>Entradas</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="#" class="sidebar-link"> <i class="bi bi-caret-down"></i>Salidas</a>
                                </li>
                            </ul>
                        </li>
                    </ul>



                </li>

                <li class="sidebar-item">
                    <a href="#" class="sidebar-link collapsed" data-bs-toggle="collapse"
                        data-bs-target="#multi-two" aria-expanded="false" aria-controls="multi-two">
                        <i class="bi bi-database-fill-gear"></i>
                        Opciones de inventario
                    </a>
                    <ul id="multi-two" class="sidebar-dropdown list-unstyled collapse">
                        <li class="sidebar-item">
                            <a href="#" class="sidebar-link"><i class="bi bi-plus-circle"></i>Añadir</a>
                        </li>
                        <li class="sidebar-item">
                            <a href="#" class="sidebar-link"><i class="bi bi-x-circle"></i>eliminar</a>
                        </li>
                        <li class="sidebar-item">
                            <a href="#" class="sidebar-link"><i class="bi bi-pencil"></i>Editar</a>
                        </li>

                    </ul>
                </li>

                <li class="sidebar-item">
                    <a href="usuarios.php" class="sidebar-link">
                        <i class="bi bi-people-fill"></i>
                        <span>Usuarios</span>
                    </a>
                </li>

                <li class="sidebar-item">
                    <a href="#" class="sidebar-link">
                        <i class="lni lni-popup"></i>
                        <span>Novedades</span>
                    </a>
                </li>

                <li class="sidebar-item">
                    <a href="#" class="sidebar-link">
                        <i class="lni lni-cog"></i>
                        <span>Configuracion</span>
                    </a>
                </li>

                <div class="sidebar-footer">
                    <a href="../../config/cerrarsesion.php" class="sidebar-link">
                        <i class="lni lni-exit"></i>
                        <span>Logout</span>
                    </a>
                </div>

        </aside>
        <div class="main p-3">
            
            <div style="font-size: 20px;" class="text-end ">
                <?php echo htmlspecialchars($_SESSION['username']); ?>
                <i class="bi bi-person-fill"></i>
            </div>
            <h2><strong style="color: green;">Inventario de laboratorio</strong></h2>

            <div class="container mt-5">
        
                <h4>Lista de Reactivos Registrados</h4>
                <table class="table table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Reactivo</th>
                            <th>Fórmula</th>
                            <th>Estado</th>
                            <th>Código</th>
                            <th>Cantidad</th>
                            <th>Unidad de Medida</th>
                            <th>Fecha Vencimiento</th>
                            <th>Lote</th>
                            <th>Ubicación</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        require_once "../../models/conexion_bd.php";
                        $conexiondb = new Database();
                        $pdo = $conexiondb->getConnection();
                        $sql = "SELECT * FROM inventario_laboratorio";
                        $stmt = $pdo->prepare($sql);
                        $stmt->execute();
                        $reactivos = $stmt->fetchAll(PDO::FETCH_ASSOC);

                        foreach ($reactivos as $reactivo) {
                            echo "<tr>"
                                . "<td>{$reactivo['id']}</td>"
                                . "<td>{$reactivo['reactivo']}</td>"
                                . "<td>{$reactivo['formula']}</td>"
                                . "<td>{$reactivo['estado']}</td>"
                                . "<td>{$reactivo['codigo_almacenamiento']}</td>"
                                . "<td>{$reactivo['cantidad']}</td>"
                                . "<td>{$reactivo['unidad_medida']}</td>"
                                . "<td>{$reactivo['fecha_vencimiento']}</td>"
                                . "<td>{$reactivo['lote']}</td>"
                                . "<td>{$reactivo['ubicacion']}</td>"
                                . "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>

            <div class="container mt-3">
                <a href="crearlab.php" class="btn btn-primary" style="background-color: #28a745; color: white; border: 2px solid #28a745;">Crear reactivo</a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

</body>

</html>