<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
// Verifica si el usuario ha iniciado sesión
if (!isset($_SESSION['username'])) {
    header("Location: ../../index.php"); // Redirige al login si no hay sesión
    exit();
}

// Verifica si el usuario tiene el rol de administrador
if ($_SESSION['role_id'] != 1) {
    echo "Acceso denegado";
    exit();
}


// Si el usuario es admin, continúa con la carga del contenido
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SICC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="icon" href="../../views/icons/hexagon-fill.svg" type="image/x-icon">



    <link href="https://cdn.lineicons.com/4.0/lineicons.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/administrador.css">
</head>

<body>

    <div class="wrapper">

        <aside id="sidebar" class="expand">
            <div class="d-flex">
                <button class="toggle-btn" type="button">
                    <i class="bi bi-hexagon-fill"></i>
                </button>
                <div class="sidebar-logo">
                    <a href="#" style="font-size: 25px;">SICC</a>
                </div>
            </div>

            <ul class="sidebar-nav">
                <li class="sidebar-item">
                    <a href="administrador.php" class="sidebar-link">
                        <i class="bi bi-house-door-fill"></i>
                        <span>Inicio</span>
                    </a>
                </li>

                <li class="sidebar-item">
                    <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
                        data-bs-target="#auth" aria-expanded="false" aria-controls="auth">

                        <i class="bi bi-grid-fill"></i>
                        <span> Dependencias</span>
                    </a>

                    <ul id="auth" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">

                        <!-- Laboratorio -->
                        <li class="sidebar-item">
                            <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
                                data-bs-target="#lab-options" aria-expanded="false" aria-controls="lab-options">
                                <i class="bi bi-thermometer-high"></i>Laboratorio
                            </a>
                            <ul id="lab-options" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#auth">
                                <li class="sidebar-item">
                                    <a href="Inv_lab.php" class="sidebar-link"><i class="bi bi-clipboard-fill"></i>Inventario</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="Lab_admin_entrada.php" class="sidebar-link"><i class="bi bi-caret-up"></i>Entradas</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="Lab_admin_salida.php" class="sidebar-link"> <i class="bi bi-caret-down"></i>Salidas</a>
                                </li>
                            </ul>
                        </li>

                        <!-- Deportes -->
                        <li class="sidebar-item">
                            <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
                                data-bs-target="#deportes-options" aria-expanded="false" aria-controls="deportes-options">
                                <i class="bi bi-trophy-fill"></i>Deportes
                            </a>
                            <ul id="deportes-options" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#auth">
                                <li class="sidebar-item">
                                    <a href="Inv_dep.php" class="sidebar-link"><i class="bi bi-clipboard-fill"></i>Inventario</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="#" class="sidebar-link"><i class="bi bi-caret-up"></i>Entradas</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="#" class="sidebar-link"> <i class="bi bi-caret-down"></i>Salidas</a>
                                </li>
                            </ul>
                        </li>

                        <!-- Bienestar -->
                        <li class="sidebar-item">
                            <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
                                data-bs-target="#bienestar-options" aria-expanded="false" aria-controls="bienestar-options">
                                <i class="bi bi-person-arms-up"></i>Bienestar
                            </a>
                            <ul id="bienestar-options" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#auth">
                                <li class="sidebar-item">
                                    <a href="#" class="sidebar-link"> <i class="bi bi-caret-up"></i>Entradas</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="#" class="sidebar-link"> <i class="bi bi-caret-down"></i>Salidas</a>
                                </li>
                            </ul>
                        </li>


                        <!-- Hospedaje -->
                        <li class="sidebar-item">
                            <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
                                data-bs-target="#hospedaje-options" aria-expanded="false" aria-controls="hospedaje-options">
                                <i class="bi bi-buildings-fill"></i>Hospedaje
                            </a>
                            <ul id="hospedaje-options" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#auth">
                                <li class="sidebar-item">
                                    <a href="#" class="sidebar-link"><i class="bi bi-caret-up"></i>Entradas</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="#" class="sidebar-link"> <i class="bi bi-caret-down"></i>Salidas</a>
                                </li>
                            </ul>
                        </li>
                    </ul>


                </li>


                <li class="sidebar-item">
                    <a href="usuarios.php" class="sidebar-link">
                        <i class="bi bi-people-fill"></i>
                        <span>Usuarios</span>
                    </a>
                </li>

                <li class="sidebar-item">
                    <a href="../Laboratorio/laboratorio.php" class="sidebar-link">
                        <i class="lni lni-popup"></i>
                        <span>Novedades</span>
                    </a>
                </li>



                <div class="sidebar-footer">
                    <a href="#" class="sidebar-link" id="logout">
                        <i class="lni lni-exit"></i>
                        <span>Logout</span>
                    </a>
                </div>
                <script src="../js/cerrarsesion.js"></script>

        </aside>

        <div class="main p-3">
            <div class="row page-titles mx-0 bold">
                <div class="col-sm-6 p-md-0">
                    <div class="welcome-text d-flex align-items-center">
                        <img src="../img/sena.png" style="width: 60px; height: auto;" alt="" class="me-3">
                        <div>
                            <h4 style="color: black;" class="bold" st>Bienvenido a <strong class="bold" style="color: green;">sistema de consumo controlado</strong></h4>
                            <p class="mb-0">¡La solución inteligente para gestionar entradas y salidas!</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                    <ol class="breadcrumb" style="font-size:20px;">
                        <?php echo htmlspecialchars($_SESSION['username']); ?>
                        <i class="bi bi-person-fill"></i>
                    </ol>
                </div>
            </div>

            <div class="container">



                <form action="../../controllers/creardepController.php" method="POST" class="container mt-5" id="formulario">
                    <h1>Nuevo material deportivo <strong style="color: green;"><i class="bi bi-bicycle icon"></i></strong></h1>
                    <br>
                    <div class="row">
                        <div class="col-12 col-sm-6 col-md-4 mb-3">
                            <label for="reactivo" class="form-label text-dark">Elemento:</label>
                            <input type="text" name="elemento" id="elemento" class="form-control form-control-sm bg-light" required>
                        </div>
                        <div class="col-12 col-sm-6 col-md-4 mb-3">
                            <label for="ubicacion" class="form-label text-dark">Ubicación:</label>
                            <input type="text" name="ubicacion" id="ubicacion" class="form-control form-control-sm bg-light">
                        </div>
                        <div class="col-12 col-sm-6 col-md-4 mb-3">
                            <label for="cantidad" class="form-label text-dark">Cantidad:</label>
                            <input type="number" name="cantidad" id="cantidad" class="form-control form-control-sm bg-light" required>
                        </div>
                        <div class="col-12 col-sm-6 col-md-4 mb-3">
                            <label for="unidad_medida" class="form-label text-dark">Unidad de Medida:</label>
                            <select name="unidad_medida" id="unidad_medida" class="form-control form-control-sm bg-light">
                                <option value="" disabled selected>Seleccione una unidad</option>
                                <option value="unidades">Unidad</option>

                            </select>
                        </div>
                        <div class="col-12 mb-3">
                            <button type="submit" class="btn btn-success" style="width: 100%;" id="guardarBtn">Guardar</button>
                        </div>
                        <div class="col-12 mb-3">
                            <button type="button" id="boton_editar" class="btn btn-secondary w-100" onclick="location.href='Inv_dep.php'">Volver</button>
                        </div>
                    </div>
                </form>
            </div>

            <script>
                // Si el formulario se envía correctamente, muestra la alerta de SweetAlert
                document.getElementById("formulario").addEventListener("submit", function(e) {
                    e.preventDefault(); // Evitar que el formulario se envíe de forma predeterminada

                    // Alerta de confirmación antes de crear el insumo
                    Swal.fire({
                        title: '¿Estás seguro?',
                        text: "¿Quieres crear este nuevo elemento?",
                        icon: 'warning',
                        showCancelButton: true,
                        cancelButtonText: 'Cancelar',
                        confirmButtonText: 'Sí, crear',
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            // Si el usuario confirma, muestra la alerta de éxito
                            Swal.fire({
                                title: '¡Se ha creado!',
                                text: 'El elemento deportivo ha sido creado correctamente.',
                                icon: 'success',
                                confirmButtonText: 'Aceptar'
                            }).then(() => {
                                // Luego, envía el formulario
                                this.submit();
                            });
                        } else {
                            // Si el usuario cancela, muestra la alerta de cancelación
                            Swal.fire({
                                title: '¡No se creó el elemento!',
                                text: 'El elemento no fue creado.',
                                icon: 'error',
                                confirmButtonText: 'Aceptar'
                            });
                        }
                    });
                });

                // El botón de volver no depende del estado del formulario
                document.querySelectorAll('a[href="Inv_lab.php"]').forEach(button => {
                    button.addEventListener('click', function(event) {
                        event.preventDefault();
                        window.location.href = "Inv_dep.php";
                    });
                });
            </script>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

</body>

</html>