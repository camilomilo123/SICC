<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
// Verifica si el usuario ha iniciado sesión
if (!isset($_SESSION['username'])) {
    header("Location: ../../index.php"); // Redirige al login si no hay sesión
    exit();
}

// Verifica si el usuario tiene el rol de administrador
if ($_SESSION['role_id'] != 1) {
    echo "Acceso denegado";
    exit();
}


// Si el usuario es admin, continúa con la carga del contenido
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SICC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="icon" href="../../views/icons/hexagon-fill.svg" type="image/x-icon">
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.2/css/buttons.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>


    <link href="https://cdn.lineicons.com/4.0/lineicons.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/administrador.css">
</head>

<body>

    <div class="wrapper">

        <aside id="sidebar" class="expand">
            <div class="d-flex">
                <button class="toggle-btn" type="button">
                    <i class="bi bi-hexagon-fill"></i>
                </button>
                <div class="sidebar-logo">
                    <a href="#" style="font-size: 25px;">SICC</a>
                </div>
            </div>

            <ul class="sidebar-nav">
                <li class="sidebar-item">
                    <a href="administrador.php" class="sidebar-link">
                        <i class="bi bi-house-door-fill"></i>
                        <span>Inicio</span>
                    </a>
                </li>

                <li class="sidebar-item">
                    <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
                        data-bs-target="#auth" aria-expanded="false" aria-controls="auth">

                        <i class="bi bi-grid-fill"></i>
                        <span> Dependencias</span>
                    </a>

                    <ul id="auth" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">

                        <!-- Laboratorio -->
                        <li class="sidebar-item">
                            <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
                                data-bs-target="#lab-options" aria-expanded="false" aria-controls="lab-options">
                                <i class="bi bi-thermometer-high"></i>Laboratorio
                            </a>
                            <ul id="lab-options" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#auth">
                                <li class="sidebar-item">
                                    <a href="Inv_lab.php" class="sidebar-link"><i class="bi bi-clipboard-fill"></i>Inventario</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="Lab_admin_entrada.php" class="sidebar-link"><i class="bi bi-caret-up"></i>Entradas</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="Lab_admin_salida.php" class="sidebar-link"> <i class="bi bi-caret-down"></i>Salidas</a>
                                </li>
                            </ul>
                        </li>

                        <!-- Deportes -->
                        <li class="sidebar-item">
                            <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
                                data-bs-target="#deportes-options" aria-expanded="false" aria-controls="deportes-options">
                                <i class="bi bi-trophy-fill"></i>Deportes
                            </a>
                            <ul id="deportes-options" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#auth">
                                <li class="sidebar-item">
                                    <a href="Inv_dep.php" class="sidebar-link"><i class="bi bi-clipboard-fill"></i>Inventario</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="#" class="sidebar-link"><i class="bi bi-caret-up"></i>Entradas</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="#" class="sidebar-link"> <i class="bi bi-caret-down"></i>Salidas</a>
                                </li>
                            </ul>
                        </li>

                        <!-- Bienestar -->
                        <li class="sidebar-item">
                            <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
                                data-bs-target="#bienestar-options" aria-expanded="false" aria-controls="bienestar-options">
                                <i class="bi bi-person-arms-up"></i>Bienestar
                            </a>
                            <ul id="bienestar-options" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#auth">
                                <li class="sidebar-item">
                                    <a href="#" class="sidebar-link"> <i class="bi bi-caret-up"></i>Entradas</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="#" class="sidebar-link"> <i class="bi bi-caret-down"></i>Salidas</a>
                                </li>
                            </ul>
                        </li>


                        <!-- Hospedaje -->
                        <li class="sidebar-item">
                            <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
                                data-bs-target="#hospedaje-options" aria-expanded="false" aria-controls="hospedaje-options">
                                <i class="bi bi-buildings-fill"></i>Hospedaje
                            </a>
                            <ul id="hospedaje-options" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#auth">
                                <li class="sidebar-item">
                                    <a href="#" class="sidebar-link"><i class="bi bi-caret-up"></i>Entradas</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="#" class="sidebar-link"> <i class="bi bi-caret-down"></i>Salidas</a>
                                </li>
                            </ul>
                        </li>
                    </ul>


                </li>


                <li class="sidebar-item">
                    <a href="usuarios.php" class="sidebar-link">
                        <i class="bi bi-people-fill"></i>
                        <span>Usuarios</span>
                    </a>
                </li>

                <li class="sidebar-item">
                    <a href="../Laboratorio/laboratorio.php" class="sidebar-link">
                        <i class="lni lni-popup"></i>
                        <span>Novedades</span>
                    </a>
                </li>



                <div class="sidebar-footer">
                    <a href="#" class="sidebar-link" id="logout">
                        <i class="lni lni-exit"></i>
                        <span>Logout</span>
                    </a>
                </div>
                <script src="../js/cerrarsesion.js"></script>

        </aside>

        <div class="main p-3">

            <div class="row page-titles mx-0 bold">
                <div class="col-sm-6 p-md-0">
                    <div class="welcome-text d-flex align-items-center">
                        <img src="../img/sena.png" style="width: 60px; height: auto;" alt="" class="me-3">
                        <div>
                            <h4 style="color: black;" class="bold" st>Bienvenido a <strong class="bold" style="color: green;">sistema de consumo controlado</strong></h4>
                            <p class="mb-0">¡La solución inteligente para gestionar entradas y salidas!</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                    <ol class="breadcrumb" style="font-size:20px;">
                        <?php echo htmlspecialchars($_SESSION['username']); ?>
                        <i class="bi bi-person-fill"></i>
                    </ol>
                </div>
            </div>

            <div class="container mt-5">
                <h2><strong style="color: green;">Inventario de Deportes</strong></h2>

                <h4>Lista de elementos deportivos registrados</h4>
                <br>

                <br>
                <table id="Tabla_invdeportes" class="table table-striped">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Material deportivo</th>
                            <th>Cantidad</th>
                            <th>Unidad de Medida</th>
                            <th>Ubicación</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Los datos se cargarán dinámicamente con DataTables -->
                    </tbody>
                </table>
                <div>
                    <a href="creardep.php" id="Anadir_Btn" class="btn btn-success"><i class="bi bi-plus-circle-fill"></i> Crear elemento</a>
                    <a href="editar.php" id="Editar_Btn" class="btn btn-secondary"><i class="bi bi-pen-fill"></i> Editar</a>
                    
                </div>

                <!-- DataTables Scripts -->
                <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
                <script src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>
                <script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.html5.min.js"></script>
                <script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.print.min.js"></script>

                <!-- Script personalizado -->
                <script src="../js/Tabla_invdeportes.js"></script>




                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>


</body>

</html>