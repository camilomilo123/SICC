<?php
session_start();
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
// Verifica si el usuario ha iniciado sesión


if (!isset($_SESSION['correo'])) {
    header("Location: ../../index.php");
    exit();
}

if ($_SESSION['role_id'] != 1) {
    echo "Acceso denegado";
    exit();
}

$username = isset($_SESSION['username']) ? $_SESSION['username'] : 'Usuario';




// Si el usuario es admin, continúa con la carga del contenido
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SICC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="icon" href="../../views/icons/hexagon-fill.svg" type="image/x-icon">



    <link href="https://cdn.lineicons.com/4.0/lineicons.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/administrador.css">
    <link rel="stylesheet" href="../css/Notificaciones.css">
    
</head>

<body>

    <div class="wrapper light">

        <aside id="sidebar" class="expand">
            <div class="d-flex">
                <button class="toggle-btn" type="button">
                    <i class="bi bi-hexagon-fill"></i>
                </button>
                <div class="sidebar-logo">
                    <a href="#" style="font-size: 25px;">SICC</a>
                </div>
            </div>

            <ul class="sidebar-nav">
                <li class="sidebar-item">
                    <a href="administrador.php" class="sidebar-link">
                        <i class="bi bi-house-door-fill"></i>
                        <span>Inicio</span>
                    </a>
                </li>

                <li class="sidebar-item">
                    <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
                        data-bs-target="#auth" aria-expanded="false" aria-controls="auth">

                        <i class="bi bi-grid-fill"></i>
                        <span> Dependencias</span>
                    </a>

                    <ul id="auth" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#sidebar">

                        <!-- Laboratorio -->
                        <li class="sidebar-item">
                            <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
                                data-bs-target="#lab-options" aria-expanded="false" aria-controls="lab-options">
                                <i class="bi bi-thermometer-high"></i>Laboratorio
                            </a>
                            <ul id="lab-options" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#auth">
                                <li class="sidebar-item">
                                    <a href="Inv_lab.php" class="sidebar-link"><i class="bi bi-clipboard-fill"></i>Inventario</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="Lab_admin_entrada.php" class="sidebar-link"><i class="bi bi-caret-up"></i>Entradas</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="Lab_admin_salida.php" class="sidebar-link"> <i class="bi bi-caret-down"></i>Salidas</a>
                                </li>
                            </ul>
                        </li>

                        <!-- Deportes -->
                        <li class="sidebar-item">
                            <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
                                data-bs-target="#deportes-options" aria-expanded="false" aria-controls="deportes-options">
                                <i class="bi bi-trophy-fill"></i>Deportes
                            </a>
                            <ul id="deportes-options" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#auth">
                                <li class="sidebar-item">
                                    <a href="Inv_dep.php" class="sidebar-link"><i class="bi bi-clipboard-fill"></i>Inventario</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="#" class="sidebar-link"><i class="bi bi-caret-up"></i>Entradas</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="#" class="sidebar-link"> <i class="bi bi-caret-down"></i>Salidas</a>
                                </li>
                            </ul>
                        </li>

                        <!-- Bienestar -->
                        <li class="sidebar-item">
                            <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
                                data-bs-target="#bienestar-options" aria-expanded="false" aria-controls="bienestar-options">
                                <i class="bi bi-person-arms-up"></i>Bienestar
                            </a>
                            <ul id="bienestar-options" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#auth">
                                <li class="sidebar-item">
                                    <a href="#" class="sidebar-link"> <i class="bi bi-caret-up"></i>Entradas</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="#" class="sidebar-link"> <i class="bi bi-caret-down"></i>Salidas</a>
                                </li>
                            </ul>
                        </li>


                        <!-- Hospedaje -->
                        <li class="sidebar-item">
                            <a href="#" class="sidebar-link collapsed has-dropdown" data-bs-toggle="collapse"
                                data-bs-target="#hospedaje-options" aria-expanded="false" aria-controls="hospedaje-options">
                                <i class="bi bi-buildings-fill"></i>Hospedaje
                            </a>
                            <ul id="hospedaje-options" class="sidebar-dropdown list-unstyled collapse" data-bs-parent="#auth">
                                <li class="sidebar-item">
                                    <a href="#" class="sidebar-link"><i class="bi bi-caret-up"></i>Entradas</a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="#" class="sidebar-link"> <i class="bi bi-caret-down"></i>Salidas</a>
                                </li>
                            </ul>
                        </li>
                    </ul>


                </li>


                <li class="sidebar-item">
                    <a href="usuarios.php" class="sidebar-link">
                        <i class="bi bi-people-fill"></i>
                        <span>Usuarios</span>
                    </a>
                </li>

                <li class="sidebar-item">
                    <a href="../Laboratorio/laboratorio.php" class="sidebar-link">
                        <i class="lni lni-popup"></i>
                        <span>Novedades</span>
                    </a>
                </li>



                <div class="sidebar-footer">
                    <a href="#" class="sidebar-link" id="logout">
                        <i class="lni lni-exit"></i>
                        <span>Logout</span>
                    </a>
                </div>
                <script src="../js/cerrarsesion.js"></script>

        </aside>

        
        <div class="main p-3 bold">
            <div class="row page-titles mx-0">
                <div class="col-sm-6 p-md-0">
                    <div class="welcome-text d-flex align-items-center">
                        <img src="../img/sena.png" style="width: 60px; height: auto;" alt="" class="me-3">
                        <div>
                            <h4 style="color: black;" class="bold" st>Bienvenido a <strong class="bold" style="color: green;">sistema de consumo controlado</strong></h4>
                            <p class="mb-0">¡La solución inteligente para gestionar entradas y salidas!</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                <a class="nav-link position-relative" href="#" id="notificacionesDropdown" role="button" data-bs-toggle="dropdown">
                        <i class="bi bi-bell-fill" style="font-size: 25px; padding-right: 10px;"></i>
                        <span id="notificacionesContador" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger d-none">
                            0
                        </span>
                    </a>
                    <ul id="notificacionesLista" class="dropdown-menu dropdown-menu-end">
                        <li><p class="dropdown-item text-center">No hay notificaciones</p></li>
                    </ul>
                    <script src="../js/NotificacionesLabAdmin.js"></script>
                   

                    
                    
                    <ol class="breadcrumb bold" style="font-size:20px;">
                        <?php echo htmlspecialchars($_SESSION['username']); ?>
                        <i class="bi bi-person-fill"></i>
                    </ol>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3 col-sm-6">
                    <div class="card">
                        <div class="stat-widget-one card-body">
                            <div class="stat-icon d-inline-block">
                                <i class="bi bi-arrow-up-circle-fill text-success border-success"></i>
                            </div>
                            <div class="stat-content d-inline-block">
                                <div class="stat-text">Entradas</div>
                                <div class="stat-digit" id="totalEntradas">0</div>
                                <script src="../js/contar_entradas.js"></script>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="card">
                        <div class="stat-widget-one card-body">
                            <div class="stat-icon d-inline-block">
                                <i class="bi bi-arrow-down-circle-fill text-danger border-danger"></i>
                            </div>
                            <div class="stat-content d-inline-block">
                                <div class="stat-text">Salidas</div>
                                <div class="stat-digit" id="contadorSalidas">0</div>
                                <script src="../js/contar_salidas.js"></script>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="card">
                        <div class="stat-widget-one card-body">
                            <div class="stat-icon d-inline-block">
                                <i class="bi bi-box-fill text-muted "></i>
                            </div>
                            <div class="stat-content d-inline-block">
                                <div class="stat-text" >Insumos</div>
                                <div class="stat-digit" id="TotalInsumos">0</div>
                                <script src="../js/ContarTotalInsumos.js"></script>
                                

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="card">
                        <div class="stat-widget-one card-body">
                            <div class="stat-icon d-inline-block">
                                <i class="bi bi-people-fill"></i>
                            </div>
                            <div class="stat-content d-inline-block">
                                <div class="stat-text">Usuarios</div>
                                <div class="stat-digit" id="TotalUsuarios">0</div>
                                <script src="../js/ContarUsuarios.js"></script>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-8">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">cantidad de insumos Laboratorio</h4>
                        </div>
                        <div class="card-body">

                            <canvas id="myChart"></canvas>
                            <br>
                            <button id="prevPage" class="btn btn-primary btn-sm" >Anterior</button>
                            <button id="nextPage" class="btn btn-primary btn-sm">Siguiente</button>
                            <script src="../js/grafico_reactivos.js"></script>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 w-100 h-100">
                    <div class="card">
                    <div id="GraficoEspacioCircular" class="card-body">
                            <h4 class="card-title" >laboratorio</h4>
                            <canvas  id="graficoEntradasSalidas"></canvas>
                            <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
                            <script src="../js/EntradasSalidasGrafico.js"></script>
                            
                        </div>
                        
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-8">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">cantidad de insumos Deportes</h4>
                        </div>
                        <div class="card-body">

                            <canvas id="myChart"></canvas>
                            <br>
                            <button id="prevPage" class="btn btn-primary btn-sm" >Anterior</button>
                            <button id="nextPage" class="btn btn-primary btn-sm">Siguiente</button>
                            <script src="../js/grafico_reactivos.js"></script>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 w-100 h-100">
                    <div class="card">
                    <div id="GraficoEspacioCircular" class="card-body">
                            <h4 class="card-title" >Deportes</h4>
                            <canvas  id="graficoEntradasSalidas"></canvas>
                            <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
                            <script src="../js/EntradasSalidasGrafico.js"></script>
                            
                        </div>
                        
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-8">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">cantidad de insumos bienestar</h4>
                        </div>
                        <div class="card-body">

                            <canvas id="myChart"></canvas>
                            <br>
                            <button id="prevPage" class="btn btn-primary btn-sm" >Anterior</button>
                            <button id="nextPage" class="btn btn-primary btn-sm">Siguiente</button>
                            <script src="../js/grafico_reactivos.js"></script>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 w-100 h-100">
                    <div class="card">
                    <div id="GraficoEspacioCircular" class="card-body">
                            <h4 class="card-title" >bienestar</h4>
                            <canvas  id="graficoEntradasSalidas"></canvas>
                            <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
                            <script src="../js/EntradasSalidasGrafico.js"></script>
                            
                        </div>
                        
                    </div>
                </div>
            </div>
            <div class="row"> <!-- Contenedor de fila -->
                <div class="col-xl-4 col-lg-6 col-xxl-6 col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Roles del sistema </h4>
                        </div>
                        <div class="card-body">
                            <div class="recent-comment m-t-15">
                                <div class="media">
                                    <div class="media-left">
                                        <a href="#"><img class="media-object mr-3" src="../img/senap.jpg" alt="..."></a>
                                    </div>
                                    <div class="media-body">
                                        <h4 class="media-heading text-primary">Jefe de almacen</h4>
                                        <p>Realiza entradas y descarga reportes de estos mismos </p>
                                        <p class="comment-date">Entradas <br>Reportes </p>
                                    </div>
                                </div>
                                <div class="media">
                                    <div class="media-left">
                                        <a href="#"><img class="media-object mr-3" src="../img/senap.jpg" alt="..."></a>
                                    </div>
                                    <div class="media-body">
                                        <h4 class="media-heading text-success">Dependencia</h4>
                                        <p>Realiza las salidas del inventario</p>
                                        <p class="comment-date">Salidas</p>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                
            </div>

        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

</body>

</html>