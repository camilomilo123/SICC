<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once '../Models/conexion_bd.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = trim($_POST['username']);
    $telefono = trim($_POST['telefono']);
    $correo = trim($_POST['correo']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $role_id = intval($_POST['rol_id']);

    try {
        $conexion = new Database();
        $pdo = $conexion->getConnection();

        // 🔍 Verificar si el correo ya está registrado
        $sqlCheck = "SELECT correo FROM usuario WHERE correo = :correo";
        $stmtCheck = $pdo->prepare($sqlCheck);
        $stmtCheck->execute(['correo' => $correo]);

        if ($stmtCheck->fetch()) {
            echo json_encode(["status" => "error", "message" => "El correo ya está registrado."]);
            exit();
        }

        
        $sql = "INSERT INTO usuario (nombre, telefono, correo, contraseña, role_id) 
                VALUES (:nombre, :telefono, :correo, :password, :role_id)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            'nombre'   => $nombre,
            'telefono' => $telefono,
            'correo'   => $correo,
            'password' => $password,
            'role_id'  => $role_id
        ]);

        echo json_encode(["status" => "success"]);
    } catch (PDOException $e) {
        error_log("Error en el registro: " . $e->getMessage(), 3, "../logs/errors.log");
        echo json_encode(["status" => "error", "message" => "Error en el registro."]);
    }
}
?>