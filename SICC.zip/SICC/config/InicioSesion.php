<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../Models/conexion_bd.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $correo = $_POST['correo'];
    $password = $_POST['password'];

    try {
        $conexion = new Database();
        $pdo = $conexion->getConnection();

       
        $sql = "SELECT id_usuario, nombre, correo, role_id, contraseña FROM usuario WHERE correo = :correo";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['correo' => $correo]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // Verificar si se obtuvo el usuario
        if (!$user) {
            echo "<script>
                    alert('Usuario no encontrado');
                    window.location.href = '../index.php';
                  </script>";
            exit();
        }

        // Verificar que el campo 'nombre' no es NULL ni vacío
        if (empty($user['nombre'])) {
            echo "<script>alert('Error: El campo nombre está vacío en la base de datos');</script>";
            exit();
        }

        // Verificar si la contraseña es correcta
        if (password_verify($password, $user['contraseña'])) {
            $_SESSION['user_id'] = $user['id_usuario'];
            $_SESSION['correo'] = $user['correo'];
            $_SESSION['username'] = $user['nombre']; // Ahora se usa correctamente el nombre
            $_SESSION['role_id'] = $user['role_id'];

            session_write_close(); // Cierra la sesión antes de redirigir

            // Redirigir según el rol
            if ($user['role_id'] == 1) {
                header('Location: ../views/admin/administrador.php');
                exit();
            } elseif ($user['role_id'] == 2) {
                header('Location: ../views/Laboratorio/laboratorio.php');
                exit();
            } else {
                echo "<script>alert('Acceso denegado');</script>";
            }
        } else {
            echo "<script>
                    alert('credenciales incorrectas');
                    window.location.href = '../index.php';
                  </script>";
            exit();
        }
    } catch (Throwable $th) {
        echo "Error en la conexión: " . $th->getMessage();
    }
}