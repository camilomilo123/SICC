<?php
session_start();

// Variable de sesión 
$username = isset($_SESSION['username']) ? $_SESSION['username'] : 'Usuario';

error_reporting(E_ALL);
ini_set('display_errors', 1);
require '../vendor/autoload.php';
require_once '../models/conexion_bd.php';

use Dompdf\Dompdf;
use Dompdf\Options;

date_default_timezone_set('America/Bogota');
$fecha_actual = date('Y-m-d');
$hora_actual = date('h:i A');

// Fechas del formulario
$fecha_inicio = isset($_GET['fecha_inicio']) ? $_GET['fecha_inicio'] : $fecha_actual;
$fecha_fin = isset($_GET['fecha_fin']) ? $_GET['fecha_fin'] : $fecha_actual;

// Rango de fechas 
$fecha_inicio .= " 00:00:00";
$fecha_fin .= " 23:59:59";

$conexion = new Database();
$pdo = $conexion->getConnection();

// Error si la conexión falla 
if (!$pdo) {
    die("Error al conectar con la base de datos.");
}

// Consulta SQL con filtro de fechas (maneja cantidad_total correctamente si es una columna virtual)
$sql = "SELECT dependencia, responsable, id, insumo, fecha, descripcion, unidad_medida, 
               cantidad_salida, cantidad_total 
        FROM salidas  
        WHERE fecha BETWEEN :fecha_inicio AND :fecha_fin";

$stmt = $pdo->prepare($sql);
$stmt->bindParam(':fecha_inicio', $fecha_inicio);
$stmt->bindParam(':fecha_fin', $fecha_fin);
$stmt->execute();
$insumos = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Opciones de Dompdf
$options = new Options();
$options->set('defaultFont', 'Helvetica');
$options->set('isHtml5ParserEnabled', true);
$options->set('isRemoteEnabled', true);
$options->set('chroot', realpath($_SERVER['DOCUMENT_ROOT'] . "/SICC"));

$dompdf = new Dompdf($options);

// Ruta de la imagen
$imagen = realpath(__DIR__ . '/../views/img/senap.jpg');

if (!file_exists($imagen)) {
    die('La imagen no se encontró en: ' . $imagen);
}

// HTML del reporte
$html = '
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reporte de Salidas</title>
    <style>
        body { font-family: Arial, sans-serif; }
        .container { width: 100%; padding: 10px; }
        .header-table { width: 100%; border-bottom: 2px solid #333; margin-bottom: 5px; }
        .header-table td { vertical-align: middle; padding: 2px; }
        .logo { width: 60px; height: auto; }
        .title { text-align: center; font-size: 14px; font-weight: bold; }
        .info { text-align: right; font-size: 12px; line-height: 1.2; }
        .table { width: 100%; font-size: 14px; border-collapse: collapse; margin-top: 5px; }
        .table th { border-bottom: 2px solid black; padding: 8px; text-align: center; font-weight: bold; }
        .table td { padding: 5px; text-align: center; }
    </style>
</head>
<body>
<div class="container">
    <table class="header-table">
        <tr>
            <td style="width: 15%;">
                <img src="file://' . $imagen . '" alt="Logo SENA" class="logo">
            </td>
            <td style="width: 70%;" class="title">
                <p>SENA - SERVICIO NACIONAL DE APRENDIZAJE - 899999034-1<br>
                25. SENA - REGIONAL CUNDINAMARCA C. de Costo: 950910 CTR DE DESARROLLO AGROINDUSTRIAL Y <br>
                REPORTE DE SALIDAS ' . ($fecha_inicio == $fecha_fin ? "DEL " . substr($fecha_inicio, 0, 10) : "DEL " . substr($fecha_inicio, 0, 10) . " AL " . substr($fecha_fin, 0, 10)) . '</p>
            </td>
            <td style="width: 15%;" class="info">
                <p><strong>Usuario:</strong> ' . $username . '</p>
                <p><strong>Fecha:</strong> ' . $fecha_actual . '</p>
                <p><strong>Hora:</strong> ' . $hora_actual . '</p>
            </td>
        </tr>
    </table>

    <table class="table">
        <tr>
            <th>Fecha</th>
            <th>Insumo</th>
            <th>Dependencia</th>
            <th>Responsable</th>
            <th>Descripción</th>
            <th>Cantidad salida</th>
            <th>Cantidad total</th>
            <th>Unidad de medida</th>
        </tr>';

foreach ($insumos as $insumo) {
   
    $html .= '<tr>
        <td>' . htmlspecialchars($insumo["fecha"]) . '</td>
        <td>' . htmlspecialchars($insumo["insumo"]) . '</td>
        <td>' . htmlspecialchars($insumo["dependencia"]) . '</td>
        <td>' . htmlspecialchars($insumo["responsable"]) . '</td>
        <td>' . htmlspecialchars($insumo["descripcion"]) . '</td>
        <td>' . (fmod($insumo["cantidad_salida"], 1) == 0 ? number_format($insumo["cantidad_salida"], 0) : number_format($insumo["cantidad_salida"], 2)) . '</td>
        <td>' . (fmod($insumo["cantidad_total"], 1) == 0 ? number_format($insumo["cantidad_total"], 0) : number_format($insumo["cantidad_total"], 2)) . '</td>
        <td>' . htmlspecialchars($insumo["unidad_medida"]) . '</td>
    </tr>';
}

$html .= '</table></body></html>';

// Cargar HTML en Dompdf
$dompdf->loadHtml($html);

// Formato horizontal
$dompdf->setPaper('A4', 'landscape');
$dompdf->render();

// Mostrar el PDF en el navegador 
$dompdf->stream("ReporteSalidas_" . date('Ymd') . ".pdf", ['Attachment' => false]);