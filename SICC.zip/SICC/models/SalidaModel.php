<?php
require_once 'conexion_bd.php';

class SalidasModel {
    private $db;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    public function registrarSalida($dependencia, $insumo, $cantidad_salida, $unidad_medida, $fecha, $descripcion, $responsable) {
        try {
            $this->db->beginTransaction();

            $query = "SELECT cantidad, reactivo, unidad_medida FROM inventario_laboratorio WHERE id = :insumo FOR UPDATE";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(":insumo", $insumo, PDO::PARAM_INT);
            $stmt->execute();
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$resultado) {
                throw new Exception("El insumo con ID $insumo no existe en el inventario.");
            }

            $cantidad_actual = (float) $resultado["cantidad"];
            $nombre_reactivo = $resultado["reactivo"];
            $unidad_bd = $resultado["unidad_medida"];

            $cantidad_salida_convertida = $this->convertirUnidad($cantidad_salida, $unidad_medida, $unidad_bd);

            if ($cantidad_actual < $cantidad_salida_convertida) {
                throw new Exception("No hay suficiente cantidad en inventario para realizar la salida.");
            }

            $nueva_cantidad = number_format($cantidad_actual - $cantidad_salida_convertida, 2, '.', '');

            $updateQuery = "UPDATE inventario_laboratorio SET cantidad = :nueva_cantidad WHERE id = :insumo";
            $stmtUpdate = $this->db->prepare($updateQuery);
            $stmtUpdate->bindParam(":nueva_cantidad", $nueva_cantidad, PDO::PARAM_STR);
            $stmtUpdate->bindParam(":insumo", $insumo, PDO::PARAM_INT);
            $stmtUpdate->execute();

            $insertQuery = "INSERT INTO salidas (dependencia, insumo, unidad_medida, cantidad_salida, cantidad_total, descripcion, fecha, responsable) 
                            VALUES (:dependencia, :insumo, :unidad_medida, :cantidad_salida, :cantidad_total, :descripcion, :fecha, :responsable)";
            $stmtInsert = $this->db->prepare($insertQuery);
            $stmtInsert->bindParam(":responsable", $responsable, PDO::PARAM_STR);
            $stmtInsert->bindParam(":dependencia", $dependencia, PDO::PARAM_STR);
            $stmtInsert->bindParam(":insumo", $nombre_reactivo, PDO::PARAM_STR);
            $stmtInsert->bindParam(":unidad_medida", $unidad_medida, PDO::PARAM_STR);
            $stmtInsert->bindParam(":cantidad_salida", $cantidad_salida, PDO::PARAM_STR);
            $stmtInsert->bindParam(":cantidad_total", $nueva_cantidad, PDO::PARAM_STR);
            $stmtInsert->bindParam(":descripcion", $descripcion, PDO::PARAM_STR);
            $stmtInsert->bindParam(":fecha", $fecha, PDO::PARAM_STR);
            $stmtInsert->execute();

            $this->db->commit();

            return ["status" => "success", "message" => "Salida registrada correctamente"];

        } catch (Exception $e) {
            $this->db->rollBack();
            return ["status" => "error", "message" => $e->getMessage()];
        }
    }

    public function getSalida() {
        try {
            $query = "SELECT id, dependencia, responsable,descripcion, fecha, unidad_medida, cantidad_salida, insumo 
                      FROM salidas
                      ORDER BY fecha DESC";

            $stmt = $this->db->prepare($query);
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            return [];
        }
    }
    
    

    private function convertirUnidad($cantidad, $unidad_origen, $unidad_destino) {
        $conversiones = [
            "gramos" => ["kilogramos" => 0.001, "miligramos" => 1000, "libras" => 0.00220462],
            "kilogramos" => ["gramos" => 1000, "miligramos" => 1000000, "libras" => 2.20462],
            "miligramos" => ["gramos" => 0.001, "kilogramos" => 0.000001, "libras" => 0.00000220462],
            "libras" => ["gramos" => 453.592, "kilogramos" => 0.453592, "miligramos" => 453592],
            "mililitros" => ["litros" => 0.001],  
            "litros" => ["mililitros" => 1000]   
        ];
    
        if ($unidad_origen === $unidad_destino) {
            return $cantidad;
        }
    
        if (isset($conversiones[$unidad_origen][$unidad_destino])) {
            return $cantidad * $conversiones[$unidad_origen][$unidad_destino];
        }
    
        throw new Exception("No se puede convertir entre estas unidades: $unidad_origen y $unidad_destino.");
    }
    
    
       
    

    public function obtenerCantidadInventario($insumo) {
        $query = "SELECT cantidad FROM inventario_laboratorio WHERE id = :insumo";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(":insumo", $insumo, PDO::PARAM_INT);
        $stmt->execute();
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ? (float) $resultado["cantidad"] : false;
    }

    public function actualizarCantidadInventario($insumo, $nueva_cantidad) {
        $query = "UPDATE inventario_laboratorio SET cantidad = :nueva_cantidad WHERE id = :insumo";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(":nueva_cantidad", $nueva_cantidad, PDO::PARAM_STR);
        $stmt->bindParam(":insumo", $insumo, PDO::PARAM_INT);
        return $stmt->execute();
    }
}
?>


