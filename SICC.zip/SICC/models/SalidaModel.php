<?php
require_once 'conexion_bd.php';

class SalidasModel {
    private $db;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();

        if (!$this->db) {
            die("Error: No se pudo conectar a la base de datos.");
        }

        // Habilitar errores en PDO para depuración
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    public function registrarSalida($dependencia, $insumo, $cantidad_salida, $unidad_medida, $fecha, $descripcion) {
        try {
            $this->db->beginTransaction();

            // Obtener la cantidad actual y el nombre del reactivo en inventario
            $query = "SELECT cantidad, reactivo FROM inventario_laboratorio WHERE id = :insumo FOR UPDATE";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(":insumo", $insumo, PDO::PARAM_INT);
            $stmt->execute();
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$resultado) {
                throw new Exception("El insumo con ID $insumo no existe en el inventario.");
            }

            $cantidad_actual = $resultado["cantidad"];
            $nombre_reactivo = $resultado["reactivo"];

            if (!$nombre_reactivo) {
                throw new Exception("El insumo con ID $insumo no tiene un nombre de reactivo registrado.");
            }

            if ($cantidad_actual < $cantidad_salida) {
                throw new Exception("No hay suficiente cantidad en inventario para realizar la salida.");
            }

            // Calcular la nueva cantidad
            $nueva_cantidad = $cantidad_actual - $cantidad_salida;

            // Actualizar la cantidad en el inventario
            $updateQuery = "UPDATE inventario_laboratorio SET cantidad = :nueva_cantidad WHERE id = :insumo";
            $stmtUpdate = $this->db->prepare($updateQuery);
            $stmtUpdate->bindParam(":nueva_cantidad", $nueva_cantidad, PDO::PARAM_INT);
            $stmtUpdate->bindParam(":insumo", $insumo, PDO::PARAM_INT);
            $stmtUpdate->execute();

            // Insertar en la tabla salidas con el nombre del reactivo en lugar del ID
            $insertQuery = "INSERT INTO salidas (dependencia, insumo, unidad_medida, cantidad_salida, cantidad_total, descripcion, fecha) 
                            VALUES (:dependencia, :insumo, :unidad_medida, :cantidad_salida, :cantidad_total, :descripcion, :fecha)";
            $stmtInsert = $this->db->prepare($insertQuery);
            $stmtInsert->bindParam(":dependencia", $dependencia, PDO::PARAM_STR);
            $stmtInsert->bindParam(":insumo", $nombre_reactivo, PDO::PARAM_STR); // Guardamos el nombre del reactivo
            $stmtInsert->bindParam(":unidad_medida", $unidad_medida, PDO::PARAM_STR);
            $stmtInsert->bindParam(":cantidad_salida", $cantidad_salida, PDO::PARAM_INT);
            $stmtInsert->bindParam(":cantidad_total", $nueva_cantidad, PDO::PARAM_INT);
            $stmtInsert->bindParam(":descripcion", $descripcion, PDO::PARAM_STR);
            $stmtInsert->bindParam(":fecha", $fecha, PDO::PARAM_STR);
            $stmtInsert->execute();

            $this->db->commit();

            return ["status" => "success", "message" => "Salida registrada correctamente"];

        } catch (Exception $e) {
            $this->db->rollBack();
            return ["status" => "error", "message" => "Error: " . $e->getMessage()];
        }
    }

    // Método para obtener la cantidad actual del inventario
    public function obtenerCantidadInventario($insumo) {
        try {
            $query = "SELECT cantidad FROM inventario_laboratorio WHERE id = :insumo";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(":insumo", $insumo, PDO::PARAM_INT);
            $stmt->execute();
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
            
            return $resultado ? $resultado["cantidad"] : false;
        } catch (Exception $e) {
            return false;
        }
    }

    // Método para actualizar la cantidad en el inventario
    public function actualizarCantidadInventario($insumo, $nueva_cantidad) {
        try {
            $query = "UPDATE inventario_laboratorio SET cantidad = :nueva_cantidad WHERE id = :insumo";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(":nueva_cantidad", $nueva_cantidad, PDO::PARAM_INT);
            $stmt->bindParam(":insumo", $insumo, PDO::PARAM_INT);
            $stmt->execute();

            return true;
        } catch (Exception $e) {
            return false;
        }
    }
}
?>
