<?php
require_once "conexion_bd.php";

class CrearModel {
    private $pdo;

    public function __construct() {
        $conexiondb = new Database();
        $this->pdo = $conexiondb->getConnection();
    }

    public function agregarReactivo($datos) {
        try {
            $sql = "INSERT INTO inventario_deportes (elemento, cantidad, unidad_medida, ubicacion) 
                    VALUES (:elemento, :cantidad, :unidad_medida, :ubicacion)";
            $stmt = $this->pdo->prepare($sql);
            return $stmt->execute([
                ':elemento' => $datos['elemento'],
                ':cantidad' => $datos['cantidad'],
                ':unidad_medida' => $datos['unidad_medida'],
                ':ubicacion' => $datos['ubicacion']
            ]);
        } catch (PDOException $e) {
            die("Error en la base de datos: " . $e->getMessage());
        }
    }
}
?>