<?php
require_once 'conexion_bd.php';

class EditarModel {
    private $db;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    public function registrarcambio($insumo, $formula, $estado, $fecha_vencimiento, $lote, $ubicacion, $codigo, $cantidad, $unidad_medida) {
        try {
            $this->db->beginTransaction(); // Iniciar la transacción

            // 1. Obtener los valores actuales
            $sql_select = "SELECT formula, estado, fecha_vencimiento, lote, unidad_medida, ubicacion, codigo_almacenamiento, cantidad 
                           FROM inventario_laboratorio WHERE id = :insumo";
            $stmt_select = $this->db->prepare($sql_select);
            $stmt_select->execute([':insumo' => $insumo]);
            $datos_actuales = $stmt_select->fetch(PDO::FETCH_ASSOC);

            if (!$datos_actuales) {
                return ["status" => "error", "message" => "El registro no existe."];
            }

            // 2. Mantener valores anteriores si no se envían nuevos
            $formula = !empty($formula) ? $formula : $datos_actuales['formula'];
            $estado = !empty($estado) ? $estado : $datos_actuales['estado'];
            $fecha_vencimiento = !empty($fecha_vencimiento) ? $fecha_vencimiento : $datos_actuales['fecha_vencimiento'];
            $lote = !empty($lote) ? $lote : $datos_actuales['lote'];
            $unidad_medida = !empty($unidad_medida) ? $unidad_medida : $datos_actuales['unidad_medida'];
            $ubicacion = !empty($ubicacion) ? $ubicacion : $datos_actuales['ubicacion'];
            $codigo = !empty($codigo) ? $codigo : $datos_actuales['codigo_almacenamiento'];
            $cantidad = ($cantidad !== null && $cantidad !== '') ? (float) $cantidad : $datos_actuales['cantidad'];

            // 3. Ejecutar la actualización
            $sql_update = "UPDATE inventario_laboratorio 
                           SET formula = :formula, estado = :estado, 
                               fecha_vencimiento = :fecha_vencimiento, lote = :lote, 
                               unidad_medida = :unidad_medida, ubicacion = :ubicacion, 
                               codigo_almacenamiento = :codigo, cantidad = :cantidad 
                           WHERE id = :insumo";

            $stmt_update = $this->db->prepare($sql_update);
            $stmt_update->execute([
                ':formula' => $formula,
                ':estado' => $estado,
                ':fecha_vencimiento' => $fecha_vencimiento,
                ':lote' => $lote,
                ':unidad_medida' => $unidad_medida,
                ':ubicacion' => $ubicacion,
                ':codigo' => $codigo,
                ':cantidad' => $cantidad,
                ':insumo' => $insumo
            ]);

            $this->db->commit(); // Confirmar la transacción
            return true; // Indicar que la actualización fue exitosa

        } catch (PDOException $e) {
            $this->db->rollBack(); // Revertir los cambios si hay un error
            return ["status" => "error", "message" => "Error en la base de datos: " . $e->getMessage()];
        }
    }
}
?>
