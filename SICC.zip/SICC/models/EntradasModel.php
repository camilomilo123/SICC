<?php
require_once 'conexion_bd.php';

class EntradasModel
{
    private $db;

    public function __construct()
    {
        $database = new Database();
        $this->db = $database->getConnection();

        if (!$this->db) {
            die("Error: No se pudo conectar a la base de datos.");
        }

        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }


    public function getEntradas()
    {
        try {
            $query = "SELECT e.id, e.dependencia, e.responsable, e.fecha, e.unidad_medida, 
                                 e.cantidad_anterior, e.cantidad_ingresada, e.cantidad_total, i.reactivo AS insumo
                          FROM entradas e
                          JOIN inventario_laboratorio i ON e.insumo = i.reactivo
                          ORDER BY e.fecha DESC";
            $stmt = $this->db->prepare($query);
            $stmt->execute();
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

            return $result;
        } catch (Exception $e) {
            return [];
        }
    }

    public function registrarEntrada($dependencia, $insumo, $cantidad_ingresada, $fecha, $unidad_medida)
    {
        try {
            $this->db->beginTransaction();

            // Obtener la cantidad actual
            $query = "SELECT cantidad, reactivo FROM inventario_laboratorio WHERE id = :insumo FOR UPDATE";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(":insumo", $insumo, PDO::PARAM_INT);
            $stmt->execute();
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$resultado) {
                throw new Exception("El insumo con ID $insumo no existe en el inventario.");
            }


            $nombre_reactivo = $resultado["reactivo"];
            if (!$nombre_reactivo) {
                throw new Exception("El insumo con ID $insumo no tiene un nombre de reactivo registrado.");
            }

            $cantidad_actual = $resultado["cantidad"];
            $nueva_cantidad = $cantidad_actual + $cantidad_ingresada;

            // Actualizar la cantidad en el inventario
            $updateQuery = "UPDATE inventario_laboratorio SET cantidad = :nueva_cantidad WHERE id = :insumo";
            $stmtUpdate = $this->db->prepare($updateQuery);
            $stmtUpdate->bindParam(":nueva_cantidad", $nueva_cantidad, PDO::PARAM_INT);
            $stmtUpdate->bindParam(":insumo", $insumo, PDO::PARAM_INT);
            $stmtUpdate->execute();

            // Insertar en la tabla entradas
            $insertQuery = "INSERT INTO entradas (dependencia, insumo, fecha, cantidad_anterior, cantidad_ingresada, cantidad_total, unidad_medida) 
                            VALUES (:dependencia, :insumo, :fecha, :cantidad_anterior, :cantidad_ingresada, :cantidad_total, :unidad_medida)";
            $stmtInsert = $this->db->prepare($insertQuery);
            $stmtInsert->bindParam(":dependencia", $dependencia, PDO::PARAM_STR);
            $stmtInsert->bindParam(":insumo", $nombre_reactivo, PDO::PARAM_STR);
            $stmtInsert->bindParam(":fecha", $fecha, PDO::PARAM_STR);
            $stmtInsert->bindParam(":cantidad_anterior", $cantidad_actual, PDO::PARAM_INT);
            $stmtInsert->bindParam(":cantidad_ingresada", $cantidad_ingresada, PDO::PARAM_INT);
            $stmtInsert->bindParam(":cantidad_total", $nueva_cantidad, PDO::PARAM_INT);
            $stmtInsert->bindParam(":unidad_medida", $unidad_medida, PDO::PARAM_STR);
            $stmtInsert->execute();

            $this->db->commit();
            return ["status" => "success", "message" => "Entrada registrada correctamente"];
        } catch (Exception $e) {
            $this->db->rollBack();
            return ["status" => "error", "message" => "Error: " . $e->getMessage()];
        }
    }

    public function actualizarCantidadInventario($insumo, $nueva_cantidad)
    {
        try {
            $query = "UPDATE inventario_laboratorio SET cantidad = :nueva_cantidad WHERE id = :insumo";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(":nueva_cantidad", $nueva_cantidad, PDO::PARAM_INT);
            $stmt->bindParam(":insumo", $insumo, PDO::PARAM_INT);
            $stmt->execute();

            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    public function obtenerCantidadInventario($insumo)
    {
        try {
            $query = "SELECT cantidad FROM inventario_laboratorio WHERE id = :insumo";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(":insumo", $insumo, PDO::PARAM_INT);
            $stmt->execute();
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);

            return $resultado ? $resultado["cantidad"] : false;
        } catch (Exception $e) {
            return false;
        }
    }
}
