<?php
require_once 'conexion_bd.php';

class EntradasModel {
    private $db;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        if (!$this->db) {
            die("Error: No se pudo conectar a la base de datos.");
        }
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    

    public function obtenerCantidadInventario($insumo) {
        try {
            $query = "SELECT cantidad FROM inventario_laboratorio WHERE id = :insumo";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(":insumo", $insumo, PDO::PARAM_INT);
            $stmt->execute();
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
            return $resultado ? (float) $resultado['cantidad'] : false;
        } catch (Exception $e) {
            return false;
        }
    }

    public function registrarEntrada($dependencia, $insumo, $cantidad_ingresada, $fecha, $unidad_medida, $responsable) {
        try {
            $this->db->beginTransaction();

            // Obtener la cantidad actual y la unidad en la base de datos
            $query = "SELECT cantidad, unidad_medida, reactivo FROM inventario_laboratorio WHERE id = :insumo FOR UPDATE";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(":insumo", $insumo, PDO::PARAM_INT);
            $stmt->execute();
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$resultado) {
                throw new Exception("El insumo con ID $insumo no existe en el inventario.");
            }

            $cantidad_actual = (float) $resultado["cantidad"];
            $nombre_reactivo = $resultado["reactivo"];
            $unidad_bd = $resultado["unidad_medida"];

            if (!$nombre_reactivo) {
                throw new Exception("El insumo con ID $insumo no tiene un nombre de reactivo registrado.");
            }

            // Convertir la cantidad ingresada a la misma unidad que está en la base de datos
            $cantidad_entrada_convertida = $this->convertirUnidades($cantidad_ingresada, $unidad_medida, $unidad_bd);

            // Calcular la nueva cantidad correctamente
            $nueva_cantidad = number_format($cantidad_actual + $cantidad_entrada_convertida, 2, '.', '');

            // Actualizar el inventario
            $updateQuery = "UPDATE inventario_laboratorio SET cantidad = :nueva_cantidad WHERE id = :insumo";
            $stmtUpdate = $this->db->prepare($updateQuery);
            $stmtUpdate->bindParam(":nueva_cantidad", $nueva_cantidad, PDO::PARAM_STR);
            $stmtUpdate->bindParam(":insumo", $insumo, PDO::PARAM_INT);
            $stmtUpdate->execute();

            // Registrar la entrada en la tabla `entradas` (sin cantidad_total)
            $insertQuery = "INSERT INTO entradas (dependencia, insumo, fecha, cantidad_anterior, cantidad_ingresada, unidad_medida, responsable) 
                            VALUES (:dependencia, :insumo, :fecha, :cantidad_anterior, :cantidad_ingresada, :unidad_medida, :responsable)";
            $stmtInsert = $this->db->prepare($insertQuery);
            $stmtInsert->bindParam(":responsable", $responsable, PDO::PARAM_STR);
            $stmtInsert->bindParam(":dependencia", $dependencia, PDO::PARAM_STR);
            $stmtInsert->bindParam(":insumo", $nombre_reactivo, PDO::PARAM_STR);
            $stmtInsert->bindParam(":fecha", $fecha, PDO::PARAM_STR);
            $stmtInsert->bindParam(":cantidad_anterior", $cantidad_actual, PDO::PARAM_STR);
            $stmtInsert->bindParam(":cantidad_ingresada", $cantidad_entrada_convertida, PDO::PARAM_STR);
            $stmtInsert->bindParam(":unidad_medida", $unidad_medida, PDO::PARAM_STR);
            $stmtInsert->execute();

            $this->db->commit();
            return ["status" => "success", "message" => "Entrada registrada correctamente"];
        } catch (Exception $e) {
            $this->db->rollBack();
            return ["status" => "error", "message" => $e->getMessage()];
        }
    }
    
public function contarEntradas() {
    try {
        $query = "SELECT COUNT(*) AS total FROM entradas";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ? $resultado['total'] : 0;
    } catch (Exception $e) {
        return 0;
    }
}
public function contarEntradasLab($dependencia) {
    try {
        $query = "SELECT COUNT(*) AS total FROM entradas WHERE dependencia = :dependencia";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(":dependencia", $dependencia, PDO::PARAM_STR);
        $stmt->execute();
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ? $resultado['total'] : 0;
    } catch (Exception $e) {
        return 0;
    }
}
public function contarSalidasLab($dependencia) {
    try {
        $query = "SELECT COUNT(*) AS total FROM salidas WHERE dependencia = :dependencia";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(":dependencia", $dependencia, PDO::PARAM_STR);
        $stmt->execute();
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado ? $resultado['total'] : 0;
    } catch (Exception $e) {
        return 0;
    }
}

public function contarSalidas() {
    try {
        $query = "SELECT COUNT(*) AS total FROM salidas"; 
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado['total'] ?? 0;
    } catch (Exception $e) {
        return 0;
    }
}

    // Método para obtener todas las entradas con `cantidad_total` calculada
    public function getEntradas() {
        try {
            $query = "SELECT e.id, e.dependencia, e.responsable, e.fecha, e.unidad_medida, 
                             e.cantidad_anterior, e.cantidad_ingresada, 
                             (e.cantidad_anterior + e.cantidad_ingresada) AS cantidad_total,
                             i.reactivo AS insumo
                      FROM entradas e
                      JOIN inventario_laboratorio i ON e.insumo = i.reactivo
                      WHERE e.dependencia = :dependencia
                      ORDER BY e.fecha DESC";
            
            $stmt = $this->db->prepare($query);
            $dependencia = "Laboratorio"; // Filtro por "Laboratorio"
            $stmt->bindParam(":dependencia", $dependencia, PDO::PARAM_STR);
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            return [];
        }
    }
    
    private function convertirUnidades($cantidad, $unidad_origen, $unidad_destino) {
        $conversiones = [
            "gramos" => ["kilogramos" => 0.001, "miligramos" => 1000, "libra" => 0.00220462],
            "kilogramos" => ["gramos" => 1000, "miligramos" => 1000000, "libra" => 2.20462],
            "miligramos" => ["gramos" => 0.001, "kilogramos" => 0.000001, "libra" => 0.00000220462],
            "libra" => ["gramos" => 453.592, "kilogramos" => 0.453592, "miligramos" => 453592],
            "mililitros" => ["litros" => 0.001],
            "litros" => ["mililitros" => 1000]
        ];

        if ($unidad_origen === $unidad_destino) {
            return $cantidad;
        }

        if (isset($conversiones[$unidad_origen][$unidad_destino])) {
            return $cantidad * $conversiones[$unidad_origen][$unidad_destino];
        }

        throw new Exception("No se puede convertir entre estas unidades: $unidad_origen y $unidad_destino.");
    }
}
?>



