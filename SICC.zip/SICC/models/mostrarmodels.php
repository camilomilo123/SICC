<?php
require_once "conexion_bd.php";

class InventarioModel {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    public function obtenerInventario() {
        $query = "SELECT * FROM salidas";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function registrarSalida($responsable, $insumo, $cantidad, $unidad) {
        $query = "INSERT INTO salidas (responsable, insumo, cantidad_salida, unidad_medida) VALUES ( :responsable, :insumo, :cantidad_salida, :unidad)";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":responsable", $responsable);
        $stmt->bindParam(":insumo", $insumo);
        $stmt->bindParam(":cantidad_salida", $cantidad);
        $stmt->bindParam(":unidad", $unidad);
   
        return $stmt->execute();
    }
}
?>
