<?php
require_once 'conexion_bd.php';

class Reporte {
    private $db;

    public function __construct() {
        $this->db = new Database();
    }

    public function obtenerDatos() {
        $sql = "SELECT reactivo, cantidad FROM inventario_laboratorio"; // Ajusta según tu DB
        $stmt = $this->db->getConnection()->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>

