<?php
require_once "conexion_bd.php";

class Reporte {
    private $db;

    public function __construct() {
        $conexion = new Database();
        $this->db = $conexion->getConnection();
    }

    /**
     * Obtener datos generales (puedes modificarlo según lo que necesites)
     */
    public function obtenerDatos() {
        try {
            $query = "SELECT COUNT(*) AS total_registros FROM entradas";
            $stmt = $this->db->prepare($query);
            $stmt->execute();
            $resultados = $stmt->fetch(PDO::FETCH_ASSOC);
            return ["total" => $resultados["total_registros"] ?? 0];
        } catch (PDOException $e) {
            return ["error" => $e->getMessage()];
        }
    }

    /**
     * Obtener el total de entradas y salidas para el gráfico circular
     */
    public function obtenerDatosGrafico() {
        try {
            $query = "
                SELECT 
                    (SELECT COUNT(*) FROM entradas WHERE dependencia = 'laboratorio') AS total_entradas,
                    (SELECT COUNT(*) FROM salidas WHERE dependencia = 'laboratorio') AS total_salidas";
            
            $stmt = $this->db->prepare($query);
            $stmt->execute();
            $resultados = $stmt->fetch(PDO::FETCH_ASSOC);

            return [
                "entradas" => $resultados["total_entradas"] ?? 0, 
                "salidas" => $resultados["total_salidas"] ?? 0
            ];
        } catch (PDOException $e) {
            return ["error" => $e->getMessage()];
        }
    }
}
?>

