<?php
class Usuario {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    // Verifica si el correo existe en la base de datos
    public function verificarCorreo($email) {
        $stmt = $this->db->prepare("SELECT correo FROM usuario WHERE correo = ? ");
        $stmt->execute([$email]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Guarda el token y su expiración en la base de datos
    public function guardarToken($email, $token, $expiracion) {
        $stmt = $this->db->prepare("UPDATE usuario SET reset_token = ?, reset_expiration = ? WHERE correo = ?");
        return $stmt->execute([$token, $expiracion, $email]);
    }
    

    // Verifica si el token existe en la base de datos y no ha expirado
    public function verificarToken($token) {
        $stmt = $this->db->prepare("SELECT correo FROM usuario WHERE reset_token = ? AND reset_expiration > NOW()");
        $stmt->execute([$token]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Actualiza la contraseña del usuario y elimina el token de recuperación
    public function actualizarContraseña($email, $nuevaContraseña) {
        $hashedPassword = password_hash($nuevaContraseña, PASSWORD_BCRYPT);
        $stmt = $this->db->prepare("UPDATE usuario SET contraseña = ?, reset_token = NULL, reset_expiration = NULL WHERE correo = ?");
        return $stmt->execute([$hashedPassword, $email]);
    }
}
?>
