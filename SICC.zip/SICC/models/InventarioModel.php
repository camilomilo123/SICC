<?php
class InventarioModel {
    private $pdo;

    public function __construct($db) {
        $this->pdo = $db;
    }

    public function obtenerInventario() {
        $stmt = $this->pdo->prepare("SELECT id, reactivo FROM inventario_laboratorio");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
}
?>
