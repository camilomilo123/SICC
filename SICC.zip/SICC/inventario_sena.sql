-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 31-03-2025 a las 23:55:41
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `inventario_sena`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `almacen`
--

CREATE TABLE `almacen` (
  `item` int(11) NOT NULL,
  `consecutivo` int(11) NOT NULL,
  `producto` text NOT NULL,
  `descripcion` varchar(250) NOT NULL,
  `unidad_medida` varchar(250) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `ubicacion` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `entradas`
--

CREATE TABLE `entradas` (
  `id` int(11) NOT NULL,
  `dependencia` enum('bienestar','deporte','hospedaje','laboratorio') NOT NULL,
  `responsable` tinytext NOT NULL,
  `insumo` text NOT NULL,
  `fecha` datetime NOT NULL,
  `unidad_medida` enum('unidad','litros','libra','mililitros','kilogramos','gramos','miligramos') NOT NULL,
  `cantidad_anterior` decimal(11,2) DEFAULT NULL,
  `cantidad_ingresada` decimal(11,2) DEFAULT NULL,
  `cantidad_total` decimal(11,2) GENERATED ALWAYS AS (`cantidad_anterior` + `cantidad_ingresada`) VIRTUAL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `entradas`
--

INSERT INTO `entradas` (`id`, `dependencia`, `responsable`, `insumo`, `fecha`, `unidad_medida`, `cantidad_anterior`, `cantidad_ingresada`) VALUES
(1, 'laboratorio', 'David', 'Acido Nitrico', '2025-03-26 21:40:39', 'litros', 5900.00, 1000.00),
(2, 'laboratorio', 'David', 'Cloroformo', '2025-03-26 21:41:06', 'mililitros', 1450.00, 100.00),
(3, 'laboratorio', 'David', 'Acido Acetico', '2025-03-26 21:41:24', 'litros', 500.00, 2500000.00),
(6, 'laboratorio', 'David', 'Acido Nitrico', '2025-03-26 23:39:28', 'mililitros', 5900.00, 300.00),
(7, 'laboratorio', 'samanta', 'Acido Nitrico', '2025-03-27 16:29:55', 'mililitros', 6200.00, 200.00),
(8, 'laboratorio', 'samanta', 'Acido Nitrico', '2025-03-27 17:12:52', 'mililitros', 6400.00, 200.00),
(9, 'laboratorio', 'samanta', 'Cloroformo', '2025-03-28 22:20:06', 'mililitros', 1050.00, 200.00),
(10, 'laboratorio', 'samanta', 'Cloroformo', '2025-03-28 22:43:46', 'mililitros', 1050.00, 200.00),
(13, 'laboratorio', 'samanta', 'Cloroformo', '2025-03-28 22:46:07', 'mililitros', 1250.00, 200.00),
(14, 'laboratorio', 'samanta', 'Cloroformo', '2025-03-28 22:48:33', 'mililitros', 1450.00, 200.00),
(15, 'laboratorio', 'samanta', 'Cloroformo', '2025-03-28 23:01:42', 'mililitros', 1650.00, 200.00),
(16, 'laboratorio', 'samanta', 'Acido Nitrico', '2025-03-28 23:01:59', 'mililitros', 6400.00, 200.00),
(20, 'laboratorio', 'samanta', 'Cloroformo', '2025-03-31 18:15:13', 'mililitros', 1650.00, 200.00),
(22, 'laboratorio', 'samanta', 'Cloroformo', '2025-03-31 18:30:14', 'mililitros', 2050.00, 200.00),
(23, 'laboratorio', 'samanta', 'Cloroformo', '2025-03-31 18:47:35', 'mililitros', 2250.00, 200.00),
(24, 'laboratorio', 'samanta', 'Acido Nitrico', '2025-03-31 18:48:46', 'mililitros', 6600.00, 200.00),
(28, 'laboratorio', 'samanta', 'Cloroformo', '2025-03-31 19:43:27', 'mililitros', 1850.00, 200.00),
(29, 'laboratorio', 'samanta', 'Cloroformo', '2025-03-31 19:54:18', 'mililitros', 1850.00, 100.00),
(30, 'laboratorio', 'samanta', 'Acido Nitrico', '2025-03-31 20:00:44', 'mililitros', 6800.00, 200.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inventario_deportes`
--

CREATE TABLE `inventario_deportes` (
  `id` int(250) NOT NULL,
  `elemento` varchar(100) NOT NULL,
  `cantidad` int(250) NOT NULL,
  `unidad_medida` varchar(50) DEFAULT NULL,
  `ubicacion` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `inventario_deportes`
--

INSERT INTO `inventario_deportes` (`id`, `elemento`, `cantidad`, `unidad_medida`, `ubicacion`) VALUES
(1, 'Balón de micro Golty', 10, 'unidades', 'Estantería');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inventario_laboratorio`
--

CREATE TABLE `inventario_laboratorio` (
  `id` int(11) NOT NULL,
  `reactivo` varchar(100) NOT NULL,
  `formula` varchar(100) DEFAULT NULL,
  `estado` varchar(50) NOT NULL,
  `fecha_vencimiento` date DEFAULT NULL,
  `lote` varchar(50) DEFAULT NULL,
  `unidad_medida` varchar(20) DEFAULT NULL,
  `ubicacion` varchar(100) DEFAULT NULL,
  `codigo_almacenamiento` varchar(50) DEFAULT NULL,
  `cantidad` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `inventario_laboratorio`
--

INSERT INTO `inventario_laboratorio` (`id`, `reactivo`, `formula`, `estado`, `fecha_vencimiento`, `lote`, `unidad_medida`, `ubicacion`, `codigo_almacenamiento`, `cantidad`) VALUES
(1, 'Reactivo A', 'H2O', 'Disponible', '2025-06-01', 'L001', 'litros', 'Laboratorio A', 'A001', 100),
(2, 'Reactivo B', 'NaCl', 'Disponible', '2025-07-01', 'L002', 'gramos', 'Laboratorio B', 'B001', 250),
(3, 'Reactivo C', 'C6H12O6', 'Vencido', '2024-12-31', 'L003', 'mililitros', 'Laboratorio C', 'C001', 50),
(4, 'Reactivo D', 'NaOH', 'Disponible', '2025-08-01', 'L004', 'kilogramos', 'Laboratorio D', 'D001', 10),
(5, 'Reactivo E', 'HCl', 'Disponible', '2025-09-01', 'L005', 'litros', 'Laboratorio E', 'E001', 200),
(6, 'Reactivo F', 'H2SO4', 'Vencido', '2024-11-01', 'L006', 'miligramos', 'Laboratorio F', 'F001', 500),
(7, 'Reactivo G', 'Na2SO4', 'Disponible', '2025-10-01', 'L007', 'gramos', 'Laboratorio G', 'G001', 150),
(8, 'Reactivo H', 'C12H22O11', 'Disponible', '2025-12-01', 'L008', 'litros', 'Laboratorio H', 'H001', 100),
(9, 'Reactivo I', 'KNO3', 'Vencido', '2024-10-01', 'L009', 'kilogramos', 'Laboratorio I', 'I001', 80),
(10, 'Reactivo J', 'C6H6', 'Disponible', '2025-11-01', 'L010', 'mililitros', 'Laboratorio J', 'J001', 120),
(11, 'Reactivo K', 'CaCO3', 'Disponible', '2025-09-15', 'L011', 'gramos', 'Laboratorio K', 'K001', 60),
(12, 'Reactivo L', 'NH3', 'Disponible', '2025-08-20', 'L012', 'litros', 'Laboratorio L', 'L001', 180),
(14, 'Acido Nitrico', 'HNO3', 'Liquido', '2027-11-01', '141222', 'mililitros', 'E2-M5-F1', 'Corrosivo', 6800),
(15, 'Cloroformo', 'CHCI2', 'Liquido', '2024-02-29', 'K53200845110', 'mililitros', 'E2-M3-F2', 'Tóxico', 1750),
(16, 'Acido Acetico', 'C2H4O6', 'Liquido', '2027-01-09', '2053864', 'mililitros', 'E2-M5-F1', 'Corrosivo', 500),
(22, 'dolex', 'sss', 'sss', '2025-03-31', 'ss', 'mililitros', 'sss', 'corrosivo', 200),
(23, 'Gatorade', '33', '333', '2025-03-31', '333', 'mililitros', 'sasaima', 'eeee', 200),
(24, 'dolex', 'sss', 'ss', '2025-03-31', 'sws', 'mililitros', 'sss', 'x--334-44', 500),
(25, 'cerveza', 'chontaduro', 'sss', '2025-03-31', 'ss', 'kilogramos', 'sss', 'corrosivo', 500),
(26, 'Reactivo M', 'HNO3', 'Disponible', '2025-12-20', 'L013', 'mililitros', 'Laboratorio M', 'M001', 90),
(27, 'Reactivo N', 'Na2CO3', 'Vencido', '2024-07-01', 'L014', 'kilogramos', 'Laboratorio N', 'N001', 30),
(28, 'Reactivo O', 'K2Cr2O7', 'Disponible', '2025-06-15', 'L015', 'gramos', 'Laboratorio O', 'O001', 220),
(29, 'Reactivo P', 'C2H5OH', 'Disponible', '2025-11-25', 'L016', 'litros', 'Laboratorio P', 'P001', 130),
(30, 'Reactivo Q', 'C10H12N2', 'Vencido', '2024-09-01', 'L017', 'mililitros', 'Laboratorio Q', 'Q001', 180),
(31, 'Reactivo R', 'FeCl3', 'Disponible', '2025-08-10', 'L018', 'kilogramos', 'Laboratorio R', 'R001', 75),
(32, 'Reactivo S', 'K2SO4', 'Disponible', '2025-12-25', 'L019', 'gramos', 'Laboratorio S', 'S001', 60),
(33, 'Reactivo T', 'C3H8O3', 'Disponible', '2025-05-15', 'L020', 'litros', 'Laboratorio T', 'T001', 170),
(34, 'Reactivo U', 'NaClO', 'Vencido', '2024-10-15', 'L021', 'miligramos', 'Laboratorio U', 'U001', 300),
(35, 'Reactivo V', 'C6H12O6', 'Disponible', '2025-07-30', 'L022', 'gramos', 'Laboratorio V', 'V001', 110),
(36, 'Reactivo W', 'C5H10O5', 'Disponible', '2025-10-05', 'L023', 'mililitros', 'Laboratorio W', 'W001', 80),
(37, 'Reactivo X', 'H2C2O4', 'Vencido', '2024-08-20', 'L024', 'kilogramos', 'Laboratorio X', 'X001', 45);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notificaciones`
--

CREATE TABLE `notificaciones` (
  `id` int(11) NOT NULL,
  `mensaje` text NOT NULL,
  `tipo` enum('entrada','salida') NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp(),
  `leida` tinyint(1) DEFAULT 0,
  `categoria` varchar(50) NOT NULL DEFAULT 'general'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `notificaciones`
--

INSERT INTO `notificaciones` (`id`, `mensaje`, `tipo`, `fecha`, `leida`, `categoria`) VALUES
(1, 'Se ingresaron 200 mililitros de Cloroformo en la dependencia Laboratorio.', 'entrada', '2025-03-28 21:20:06', 1, 'general'),
(2, 'Se retiraron 200 mililitros de Cloroformo en la dependencia laboratorio.', 'entrada', '2025-03-28 21:26:38', 1, 'general'),
(3, 'Se ingresaron 200 mililitros de Cloroformo en la dependencia Laboratorio.', 'entrada', '2025-03-28 21:43:46', 1, 'general'),
(4, 'Se ingresaron 200 mililitros de Cloroformo en la dependencia Laboratorio.', 'entrada', '2025-03-28 21:46:07', 1, 'general'),
(5, 'Se ingresaron 200 mililitros de Cloroformo en la dependencia Laboratorio.', 'entrada', '2025-03-28 21:48:33', 1, 'general'),
(6, 'Se ingresaron 200 mililitros de Cloroformo en la dependencia Laboratorio.', 'entrada', '2025-03-28 22:01:42', 1, 'general'),
(7, 'Se ingresaron 200 mililitros de Acido Nitrico en la dependencia Laboratorio.', 'entrada', '2025-03-28 22:01:59', 1, 'general'),
(8, 'Nueva entrada registrada: 200 mililitros de Cloroformo', 'entrada', '2025-03-31 16:17:49', 1, 'general'),
(9, 'Se ingresaron 200 mililitros de Cloroformo en la dependencia Laboratorio.', 'entrada', '2025-03-31 16:30:14', 1, 'general'),
(10, 'Se ingresaron 200 mililitros de Cloroformo en la dependencia Laboratorio.', 'entrada', '2025-03-31 16:47:35', 1, 'general'),
(11, 'Se ingresaron 200 mililitros de Acido Nitrico en la dependencia Laboratorio.', 'entrada', '2025-03-31 16:48:46', 1, 'general'),
(12, 'Se retiraron 200 mililitros de Cloroformo en la dependencia laboratorio.', 'entrada', '2025-03-31 17:02:51', 1, 'general'),
(13, 'Se retiraron 200 mililitros de Cloroformo en la dependencia laboratorio.', 'salida', '2025-03-31 17:06:07', 1, 'general'),
(15, 'Se ingresaron 200 mililitros de Cloroformo en la dependencia Laboratorio.', 'entrada', '2025-03-31 17:43:27', 1, 'laboratorio'),
(16, 'Se retiraron 200 mililitros de Cloroformo en la dependencia laboratorio.', 'salida', '2025-03-31 17:47:35', 1, 'laboratorio'),
(17, 'Se ingresaron 100 mililitros de Cloroformo en la dependencia Laboratorio.', 'entrada', '2025-03-31 17:54:18', 1, 'laboratorio'),
(18, 'Se ingresaron 200 mililitros de Acido Nitrico en la dependencia Laboratorio.', 'entrada', '2025-03-31 18:00:44', 1, 'laboratorio'),
(19, 'Se retiraron 200 mililitros de Cloroformo en la dependencia laboratorio.', 'salida', '2025-03-31 18:15:28', 1, 'laboratorio'),
(20, 'Se retiraron 200 mililitros de Acido Nitrico en la dependencia laboratorio.', 'salida', '2025-03-31 18:24:52', 1, 'laboratorio');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`id`, `nombre`) VALUES
(1, 'administrador'),
(2, 'laboratorio');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `salidas`
--

CREATE TABLE `salidas` (
  `dependencia` enum('bienestar','deporte','hospedaje','laboratorio') NOT NULL,
  `responsable` tinytext NOT NULL,
  `id` int(250) NOT NULL,
  `insumo` text NOT NULL,
  `fecha` datetime DEFAULT current_timestamp(),
  `descripcion` text DEFAULT NULL,
  `unidad_medida` enum('unidad','litros','libras','mililitros','kilogramos','gramos','miligramos') NOT NULL,
  `cantidad_salida` decimal(11,2) NOT NULL,
  `cantidad_total` decimal(11,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `salidas`
--

INSERT INTO `salidas` (`dependencia`, `responsable`, `id`, `insumo`, `fecha`, `descripcion`, `unidad_medida`, `cantidad_salida`, `cantidad_total`) VALUES
('laboratorio', 'Arturo', 14, 'Cloroformo', '2025-03-19 04:36:07', 'xqx', 'libras', 0.20, 723.91),
('laboratorio', 'Arturo', 15, 'Acido Nitrico', '2025-03-19 04:36:33', 'xqx', 'litros', 0.20, 99.80),
('laboratorio', 'carlos', 18, 'Acido Nitrico', '2025-03-24 19:45:36', 'xxx', 'mililitros', 200.00, 4700.00),
('laboratorio', 'carlos', 20, 'Acido Nitrico', '2025-03-24 20:01:12', 'practica para el dia de la ciencia', 'mililitros', 200.00, 4500.00),
('laboratorio', 'carlos', 23, 'Cloroformo', '2025-03-28 22:26:38', 'dddd', 'mililitros', 200.00, 1050.00),
('laboratorio', 'carlos', 24, 'Cloroformo', '2025-03-31 18:14:00', 'ddd', 'mililitros', 200.00, 1650.00),
('laboratorio', 'carlos', 25, 'Cloroformo', '2025-03-31 18:51:48', '200', 'mililitros', 200.00, 2250.00),
('laboratorio', 'carlos', 26, 'Cloroformo', '2025-03-31 19:02:51', 'ddd', 'mililitros', 200.00, 2050.00),
('laboratorio', 'carlos', 27, 'Cloroformo', '2025-03-31 19:06:07', '200', 'mililitros', 200.00, 1850.00),
('laboratorio', 'carlos', 30, 'Cloroformo', '2025-03-31 19:47:35', 'dd', 'mililitros', 200.00, 1850.00),
('laboratorio', 'carlos', 31, 'Cloroformo', '2025-03-31 20:15:28', '22', 'mililitros', 200.00, 1750.00),
('laboratorio', 'carlos', 32, 'Acido Nitrico', '2025-03-31 20:24:52', 'fff', 'mililitros', 200.00, 6800.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id_usuario` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `correo` varchar(50) NOT NULL,
  `role_id` int(11) NOT NULL,
  `contraseña` varchar(150) NOT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_expiration` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id_usuario`, `nombre`, `telefono`, `correo`, `role_id`, `contraseña`, `reset_token`, `reset_expiration`) VALUES
(22, 'samanta', '3214127016', 'samata23@gmail.com', 1, '$2y$10$Nld4dHFnvnanBKEX1Hn1h.A06kCMBp5rUMwCD3zPiyyCrpSxly5w2', NULL, NULL),
(25, 'carlos', '3214127016', 'carlos1234@gmail.com', 2, '$2y$10$ojXOr8AlzUnXXqSDx4EPeeDWWFcHOkoXHulyshAPHawPDw1vyTZAW', NULL, NULL),
(81, 'David', '3123021995', 'hayderpalacios@gmail.com', 1, '$2y$10$h0p/eJHIWQuqfzhyVam1g.CHVjD1hqTpDW9s5h10jA4aswCav.Uky', NULL, NULL),
(89, 'Palacios', '3123021995', 'palacios@gmail.com', 2, '$2y$10$m8RjSToamFerZULNRS4EhOwOVwueTZkHmCjAUtD6yqPfH6XgePfYu', NULL, NULL),
(90, 'Carlos A', '3208908754', 'andress040406@gmail.com', 1, '$2y$10$K/rEZRVG/fwRcBHANoy6kO3wTSSVKk991CNQX2dFpZCvN5iy/RnlK', NULL, NULL),
(92, 'Arturo', '3208908755', 'carlosarturog@gmail.com', 2, '$2y$10$NUqhJqITN58XTQOaYUNJAOVtQym6A.EpFS81VoktVAyiVyNGVcZaa', NULL, NULL),
(98, 'Camilo', '3214127016', 'camiloguti1070@gmail.com', 1, '$2y$10$El4U6.oyaZpNaWcgBcsHnuvljKZeOi7PAa2g9U2weJf8NHeDtoaeS', '3ef85d0d875bac294fd60154d496982a1b3e067546585e340a66214491e9c1a34a9e56038592ff8c01c4405fca1298513af4', '2025-03-27 17:29:01');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `almacen`
--
ALTER TABLE `almacen`
  ADD PRIMARY KEY (`item`);

--
-- Indices de la tabla `entradas`
--
ALTER TABLE `entradas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `inventario_deportes`
--
ALTER TABLE `inventario_deportes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `inventario_laboratorio`
--
ALTER TABLE `inventario_laboratorio`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `notificaciones`
--
ALTER TABLE `notificaciones`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `salidas`
--
ALTER TABLE `salidas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `correo` (`correo`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `almacen`
--
ALTER TABLE `almacen`
  MODIFY `item` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `entradas`
--
ALTER TABLE `entradas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT de la tabla `inventario_deportes`
--
ALTER TABLE `inventario_deportes`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `inventario_laboratorio`
--
ALTER TABLE `inventario_laboratorio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT de la tabla `notificaciones`
--
ALTER TABLE `notificaciones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `salidas`
--
ALTER TABLE `salidas`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=99;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
