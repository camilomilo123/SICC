<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST['id_reactivo'])) {
        $id_reactivo = $_POST['id_reactivo'];
        echo "Reactivo seleccionado: " . htmlspecialchars($id_reactivo);
        
    } else {
        echo "Por favor seleccione un reactivo.";
    }
}
?>
