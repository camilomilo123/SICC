<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../models/EntradasModel.php';

$model = new EntradasModel();
$entradas = $model->getEntradas();

echo json_encode($entradas);
?>
