<?php
require_once '../models/crearModel.php';

class CrearLabController {
    private $model;

    public function __construct() {
        $this->model = new CrearModel();
    }

    public function guardarReactivo() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $datos = [
                'reactivo' => $_POST['reactivo'],
                'formula' => $_POST['formula'] ?? null,
                'estado' => $_POST['estado'],
                'fecha_vencimiento' => $_POST['fecha_vencimiento'] ?? null,
                'lote' => $_POST['lote'] ?? null,
                'unidad_medida' => $_POST['unidad_medida'] ?? null,
                'ubicacion' => $_POST['ubicacion'] ?? null,
                'codigo' => $_POST['codigo'] ?? null,
                'cantidad' => $_POST['cantidad']
            ];

            if ($this->model->agregarReactivo($datos)) {
                header("Location: ../views/admin/crearlab.php?success=1");
            } else {
                header("Location: ../views/admin/crearlab.php?error=1");
            }
            exit();
        }
    }
}

$controller = new CrearLabController();
$controller->guardarReactivo();
?>
