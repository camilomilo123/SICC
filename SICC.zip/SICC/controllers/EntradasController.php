<?php
require_once '../models/EntradasModel.php';

class EntradasController {
    private $model;

    public function __construct() {
        $this->model = new EntradasModel();
    }

    public function registrarEntrada($datos) {
        // Validar que las claves existen en $_POST antes de usarlas
        $dependencia = "Laboratorio"; // Definido como hidden en el formulario
        $insumo = isset($datos['insumo']) ? $datos['insumo'] : null;
        $cantidad_ingresada = isset($datos['cantidad_ingresada']) ? $datos['cantidad_ingresada'] : null;
        $fecha = date("Y-m-d H:i:s");
        $unidad_medida = isset($datos['unidad_medida']) ? $datos['unidad_medida'] : null;

        // Verificar que los valores no sean null antes de continuar
        if (!$insumo || !$cantidad_ingresada) {
            echo json_encode(["status" => "error", "message" => "Todos los campos son obligatorios."]);
            return;
        }

        // Obtener la cantidad actual en el inventario
        $cantidadActual = $this->model->obtenerCantidadInventario($insumo);

        if ($cantidadActual !== false) {
            // Registrar la entrada
            $resultado = $this->model->registrarEntrada($dependencia, $insumo, $cantidad_ingresada, $fecha, $unidad_medida);

            // Si la entrada fue exitosa, actualizar el inventario
            if ($resultado["status"] === "success") {
                $nuevaCantidad = $cantidadActual + $cantidad_ingresada;
                $this->model->actualizarCantidadInventario($insumo, $nuevaCantidad);
            }

            echo json_encode($resultado);
        } else {
            echo json_encode(["status" => "error", "message" => "Error al obtener la cantidad en inventario."]);
        }
    }
}

// Manejar la solicitud POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $controller = new EntradasController();
    $controller->registrarEntrada($_POST);
}
