<?php
session_start(); 
require_once '../models/EntradasModel.php';

header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");

class EntradasController {
    private $model;

    public function __construct() {
        $this->model = new EntradasModel();
    }

    public function registrarEntrada($datos): bool|string {
        if (!isset($datos['insumo'], $datos['cantidad_ingresada'], $datos['unidad_medida'])) {
            return json_encode(["status" => "error", "message" => "Todos los campos son obligatorios."]);
        }

        if (!isset($_SESSION['username'])) {
            return json_encode(["status" => "error", "message" => "Usuario no autenticado."]);
        } 

        $dependencia = $datos['dependencia'] ?? null;
        if (!$dependencia) {
            return json_encode(["status" => "error", "message" => "La dependencia es obligatoria."]);
        }

        $insumo = $datos['insumo'];
        $responsable = $_SESSION['username']; 
        $cantidad_ingresada = (float) $datos['cantidad_ingresada'];
        $unidad_medida = $datos['unidad_medida'];
        $fecha = date("Y-m-d H:i:s");

        $cantidadActual = $this->model->obtenerCantidadInventario($insumo);

        if ($cantidadActual !== false) {
            $resultado = $this->model->registrarEntrada($dependencia, $insumo, $cantidad_ingresada, $fecha, $unidad_medida, $responsable);

            if (!is_array($resultado)) {
                return json_encode(["status" => "error", "message" => "Error interno en la base de datos."]);
            }

            return json_encode($resultado);
        } else {
            return json_encode(["status" => "error", "message" => "Error al obtener la cantidad en inventario."]);
        }
    }

    public function contarEntradas(): void {
        $totalEntradas = $this->model->contarEntradas();
        echo json_encode(["total" => $totalEntradas]);
    }

    public function contarSalidas(): void {
        $total = $this->model->contarSalidas();
        echo json_encode(["total" => $total]);
    }
    public function contarEntradasLaboratorio(): void {
        $totalEntradas = $this->model->contarEntradasLab("Laboratorio"); 
        echo json_encode(["total" => $totalEntradas]);
    }
    public function contarSalidasLaboratorio(): void {
        $totalEntradas = $this->model->contarSalidasLab("Laboratorio"); 
        echo json_encode(["total" => $totalEntradas]);
    }
}

// Manejo de solicitudes GET y POST
$controller = new EntradasController();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    echo $controller->registrarEntrada($_POST);
} elseif ($_SERVER["REQUEST_METHOD"] === "GET" && isset($_GET['action'])) {
    if ($_GET['action'] === 'contarEntradas') {
        $controller->contarEntradas();
    } elseif ($_GET['action'] === 'contarSalidas') {
        $controller->contarSalidas();
    }elseif ($_GET['action'] === 'contarEntradasLaboratorio') {  
        $controller->contarEntradasLaboratorio();
    }elseif ($_GET['action'] === 'contarSalidasLaboratorio') {  
        $controller->contarSalidasLaboratorio();
    }

}

