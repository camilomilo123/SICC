<?php
require_once __DIR__ . '/../models/restablecermodel.php';
require_once __DIR__ . '/../models/conexion_bd.php';

require_once __DIR__ . '/../librerias/PHPMailer/Exception.php';
require_once __DIR__ . '/../librerias/PHPMailer/PHPMailer.php';
require_once __DIR__ . '/../librerias/PHPMailer/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

class UsuarioController {
    private $usuarioModel;

    public function __construct() {
        $database = new Database();
        $this->usuarioModel = new Usuario($database->getConnection());
    }

    // Enviar correo de recuperación con token
    public function enviarCorreoRecuperacion($email) {
        $usuario = $this->usuarioModel->verificarCorreo($email);

        if ($usuario) {
            $token = bin2hex(random_bytes(50)); // Generar un token seguro
            $expiracion = date('Y-m-d H:i:s', strtotime('+1 hour')); // Expira en 1 hora

            $this->usuarioModel->guardarToken($usuario['correo'], $token, $expiracion);

           
            $enlace = "http://localhost/SICC/views/recuperar_contraseña/restablecer_contraseña.php?token=$token";
            $mensaje = "<p>Haga clic en el siguiente enlace para restablecer su contraseña:</p>
            <a href='$enlace' style='color: #28a745; font-weight: bold; text-decoration: none;'>Restablecer_Contraseña</a>";

            $enlace = "http://localhost/SICC/views/recuperar_contraseña/restablecer_contraseña.php?token=$token";

            $mensaje = "<p>Hola,</p>
            <p>Recibimos una solicitud para restablecer la contraseña de tu cuenta. Si no realizaste esta solicitud, puedes ignorar este mensaje.</p>
            <p>Haz clic en el siguiente boton para cambiar tu contraseña:</p>
            <p><a href='$enlace' style='display: inline-block; background-color:rgb(7, 127, 35); color: white; padding: 6px 12px; text-decoration: none; font-size: 16px; border-radius: 5px;'>Restablecer Contraseña</a></p>
            <br>
            <p>Si el botón no funciona, haz clic en el siguiente enlace o copia y pega el siguiente enlace en tu navegador:</p>
            <p><a href='$enlace'>$enlace</a></p>
            <p>Este enlace es válido por 1 hora. Después de este tiempo, dejará de funcionar y deberás solicitar un nuevo restablecimiento de contraseña.</p>
            <p>Atentamente,<br>El equipo de soporte</p>
            <p><strong>Nota:</strong> No respondas a este correo, ya que es un mensaje automático.</p>";



            return $this->enviarCorreo($email, "Recuperación de Contraseña", $mensaje);
        }

        return false;
    }

    // Método para enviar correo
    private function enviarCorreo($destinatario, $asunto, $mensaje) {
        $mail = new PHPMailer(true);

        try {
            $mail->isSMTP();
            $mail->CharSet = 'UTF-8';
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = 'andress040406@gmail.com';
            $mail->Password   = 'olimtrcgvnswkfcy'; 
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            $mail->Port       = 465;

            $mail->SMTPOptions = array(
                'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
                )
            );

            $mail->setFrom('andress040406@gmail.com', 'Equipo de Asistencia de SICC');
            $mail->addAddress($destinatario);

            $mail->isHTML(true);
            $mail->Subject = $asunto;
            $mail->Body = $mensaje;

            return $mail->send();
        } catch (Exception $e) {
            error_log("Error al enviar correo: " . $mail->ErrorInfo);
            return false;
        }
    }

    // Restablecer la contraseña con el token
    public function restablecerContraseña($token, $nuevaContraseña) {
        $usuario = $this->usuarioModel->verificarToken($token);

        if ($usuario) {
            return $this->usuarioModel->actualizarContraseña($usuario['correo'], $nuevaContraseña);
        }

        return false;
    }
}

// Manejo de solicitudes POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $controller = new UsuarioController();

    if (isset($_POST['recuperar'])) {
        $email = $_POST['email'];
        if ($controller->enviarCorreoRecuperacion($email)) {
            echo "<script>alert('Correo enviado con éxito'); window.location.href = '../index.php';</script>";
        } else {
            echo "<script>alert('Error al enviar el correo'); window.location.href = '../views/recuperar_contraseña/recuperar.php';</script>";
        }
    }

    if (isset($_POST['restablecer'])) {
        $token = $_POST['token'];
        $nuevaContraseña = $_POST['nueva_contrasena'];

        if ($controller->restablecerContraseña($token, $nuevaContraseña)) {
            echo "<script>alert('Contraseña actualizada correctamente'); window.location.href = '../index.php';</script>";
        } else {
            echo "<script>alert('Error al actualizar la contraseña'); window.location.href = '../views/recuperar_contraseña/restablecer_contraseña.php';</script>";
        }
    }
}
?>
