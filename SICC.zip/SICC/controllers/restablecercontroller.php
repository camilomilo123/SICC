<?php
require_once __DIR__ . '/../models/restablecermodel.php';
require_once __DIR__ . '/../models/conexion_bd.php';

require_once __DIR__ . '/../librerias/PHPMailer/Exception.php';
require_once __DIR__ . '/../librerias/PHPMailer/PHPMailer.php';
require_once __DIR__ . '/../librerias/PHPMailer/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

class UsuarioController {
    private $usuarioModel;

    public function __construct() {
        $database = new Database();
        $this->usuarioModel = new Usuario($database->getConnection());
    }

    // Enviar correo de recuperación con token
    public function enviarCorreoRecuperacion($email) {
        $usuario = $this->usuarioModel->verificarCorreo($email);

        if ($usuario) {
            $token = bin2hex(random_bytes(50)); // Generar un token seguro
            $expiracion = date('Y-m-d H:i:s', strtotime('+1 hour')); // Expira en 1 hora

            $this->usuarioModel->guardarToken($usuario['correo'], $token, $expiracion);

           
            $enlace = "http://localhost/SICC/views/recuperar_contraseña/restablecer_contraseña.php?token=$token";
            $mensaje = "<p>Haga clic en el siguiente enlace para restablecer su contraseña:</p>
            <a href='$enlace' style='color: #28a745; font-weight: bold; text-decoration: none;'>Restablecer_Contraseña</a>";

            $enlace = "http://localhost/SICC/views/recuperar_contraseña/restablecer_contraseña.php?token=$token";

            

$mensaje =<<<HTML
<div style=" height: 100vh; display: flex; justify-content: center; align-items: center; padding: 20px;">
    <div style="max-width: 600px; width: 100%; background-color: #ffffff; border-radius: 12px; padding: 30px; box-shadow: 0px 10px 25px rgba(0, 0, 0, 0.15); font-family: 'Arial', sans-serif; color: #333; text-align: center;">

        <!-- Encabezado con Logo -->
        <div style="padding-bottom: 20px; border-bottom: 2px solid #018b03;">
            <img src="sena.png" alt="SENA Logo" style="max-width: 100px; display: block; margin: 0 auto;">
            <h2 style="color: #212529; font-size: 26px; margin-top: 10px; font-weight: bold;">🔒 Recuperación de Contraseña</h2>
        </div>

        <!-- Mensaje Principal -->
        <div style="padding: 20px; line-height: 1.6; text-align: left;">
            <p>👋 Hola,</p>
            <p>Recibimos una solicitud para restablecer la contraseña de tu cuenta. Si no realizaste esta solicitud, puedes ignorar este mensaje.</p>

            <!-- Botón de Restablecer Contraseña -->
            <p style="text-align: center; margin-top: 25px;">
                <a href="$enlace" style="display: inline-block; background-color: #018b03; color: white; padding: 14px 30px; text-decoration: none; font-size: 16px; font-weight: bold; border-radius: 8px; box-shadow: 2px 4px 12px rgba(0, 0, 0, 0.25); transition: all 0.3s ease-in-out;"
                    onmouseover="this.style.transform='scale(1.07)'; this.style.boxShadow='4px 6px 15px rgba(0, 0, 0, 0.3)';"
                    onmouseout="this.style.transform='scale(1)'; this.style.boxShadow='2px 4px 12px rgba(0, 0, 0, 0.25)';">
                    🔑 Restablecer Contraseña
                </a>
            </p>

            <!-- Alternativa en caso de que el botón no funcione -->
            <p style="text-align: center; font-size: 14px; color: #555;">Si el botón no funciona, haz clic en el siguiente enlace:</p>
            <p style="text-align: center;"><a href="$enlace" style="color: #018b03; font-weight: bold;">$enlace</a></p>

            <p style="font-size: 14px; color: #777;">Este enlace es válido por 1 hora. Después de este tiempo, deberás solicitar un nuevo restablecimiento de contraseña.</p>
        </div>

        <!-- Sección de Consejos de Seguridad -->
        <div style="background-color: #e9f5ef; padding: 15px; border-radius: 8px; margin-top: 20px; box-shadow: inset 0px 2px 5px rgba(0, 0, 0, 0.1);">
            <h4 style="color: #018b03; margin-bottom: 10px;">🛡️ Consejos de Seguridad</h4>
            <ul style="padding-left: 20px; color: #555; font-size: 14px; text-align: left;">
                <li>🔹 Actualiza tus contraseñas regularmente.</li>
                <li>🔹 Habilita la autenticación de dos factores.</li>
                <li>🔹 Cierra sesión en dispositivos que no sean tuyos.</li>
            </ul>
        </div>

        <!-- Pie de Página con Información de Contacto -->
        <div style="margin-top: 20px; padding: 10px; background-color: #212529; color: white; border-radius: 0 0 12px 12px;">
            <p style="margin: 5px 0; font-size: 14px;">📍 Dirección: Cl. 2 #13 - 3, Villeta, Cundinamarca</p>
            <p style="margin: 5px 0; font-size: 14px;">📧 Correo: <a href="mailto:soporte@gmail.com" style="color: #28a745; text-decoration: none;">soporte@gmail.com</a></p>
        </div>

    </div>
</div>
HTML;
            
            
            
            
            

            return $this->enviarCorreo($email, "Recuperación de Contraseña", $mensaje);
        }

        return false;
    }

    // Método para enviar correo
    private function enviarCorreo($destinatario, $asunto, $mensaje) {
        $mail = new PHPMailer(true);

        try {
            $mail->isSMTP();
            $mail->CharSet = 'UTF-8';
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = 'andress040406@gmail.com';
            $mail->Password   = 'olimtrcgvnswkfcy'; 
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            $mail->Port       = 465;

            $mail->SMTPOptions = array(
                'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
                )
            );

            $mail->setFrom('andress040406@gmail.com', 'Equipo de Asistencia de SICC');
            $mail->addAddress($destinatario);

            $mail->isHTML(true);
            $mail->Subject = $asunto;
            $mail->Body = $mensaje;

            return $mail->send();
        } catch (Exception $e) {
            error_log("Error al enviar correo: " . $mail->ErrorInfo);
            return false;
        }
    }

    // Restablecer la contraseña con el token
    public function restablecerContraseña($token, $nuevaContraseña) {
        $usuario = $this->usuarioModel->verificarToken($token);

        if ($usuario) {
            return $this->usuarioModel->actualizarContraseña($usuario['correo'], $nuevaContraseña);
        }

        return false;
    }
}

// Manejo de solicitudes POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $controller = new UsuarioController();

    if (isset($_POST['recuperar'])) {
        $email = $_POST['email'];
        if ($controller->enviarCorreoRecuperacion($email)) {
            echo "<script>alert('Correo enviado con éxito'); window.location.href = '../index.php';</script>";
        } else {
            echo "<script>alert('Error al enviar el correo'); window.location.href = '../views/recuperar_contraseña/recuperar.php';</script>";
        }
    }

    if (isset($_POST['restablecer'])) {
        $token = $_POST['token'];
        $nuevaContraseña = $_POST['nueva_contrasena'];

        if ($controller->restablecerContraseña($token, $nuevaContraseña)) {
            echo "<script>alert('Contraseña actualizada correctamente'); window.location.href = '../index.php';</script>";
        } else {
            echo "<script>alert('Error al actualizar la contraseña'); window.location.href = '../views/recuperar_contraseña/restablecer_contraseña.php';</script>";
        }
    }
}
?>
