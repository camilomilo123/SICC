<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once "../models/eliminarModel.php"; 

class EliminarController {
    private $model;

    public function __construct() {
        $this->model = new EliminarModel();
    }

    public function eliminar() {
        if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
            $id = filter_var($_GET['id'], FILTER_VALIDATE_INT);

            if ($id && $this->model->eliminarReactivo($id)) {
                // Redirigir con parámetro de éxito
                header("Location: ../views/admin/Inv_lab.php?eliminado=true");
                exit();
            } else {
                // Redirigir con parámetro de error
                header("Location: ../views/admin/Inv_lab.php?error=true");
                exit();
            }
        } else {
            // Si el ID no es válido, redirigimos con mensaje de error
            header("Location: ../views/admin/Inv_lab.php?invalid_id=true");
            exit();
        }
    }
}

// Ejecutar la eliminación solo si se recibe un ID válido
if (!empty($_GET['id'])) {
    $controller = new EliminarController();
    $controller->eliminar();
} else {
    echo "Acceso no autorizado.";
}
?>

