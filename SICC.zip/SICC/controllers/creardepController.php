<?php
require_once '../models/creardepModel.php';

class CrearLabController {
    private $model;

    public function __construct() {
        $this->model = new CrearModel();
    }

    public function guardarReactivo() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $datos = [
                'elemento' => $_POST['elemento'],
                'cantidad' => $_POST['cantidad'],
                'unidad_medida' => $_POST['unidad_medida'] ?? null,
                'ubicacion' => $_POST['ubicacion'] ?? null,
                
                
            ];

            if ($this->model->agregarReactivo($datos)) {
                header("Location: ../views/admin/creardep.php?success=1");
            } else {
                header("Location: ../views/admin/creardep.php?error=1");
            }
            exit();
        }
    }
}

$controller = new CrearLabController();
$controller->guardarReactivo();
?>
