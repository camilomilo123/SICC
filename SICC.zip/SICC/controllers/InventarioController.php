<?php
require_once '../models/InventarioModel.php';
require_once '../models/conexion_bd.php';

class InventarioController {
    private $model;

    public function __construct() {
        $database = new Database();
        $db = $database->getConnection();
        $this->model = new InventarioModel($db);
    }

    public function listarInventario() {
        $datos = $this->model->obtenerInventario();
        echo json_encode($datos);
    }
}

if (isset($_GET['action']) && $_GET['action'] == 'listar') {
    $controller = new InventarioController();
    $controller->listarInventario();
}
?>
