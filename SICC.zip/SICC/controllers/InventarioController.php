<?php
require_once "../models/conexion_bd.php";
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *"); // Evitar problemas de CORS

// Conexión a la base de datos
$conexiondb = new Database();
$pdo = $conexiondb->getConnection();

try {
    $sql = "SELECT id, reactivo, formula, estado, fecha_vencimiento, lote, unidad_medida, ubicacion, codigo_almacenamiento, cantidad FROM inventario_laboratorio";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $inventario = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(["data" => $inventario], JSON_UNESCAPED_UNICODE);
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
exit;



