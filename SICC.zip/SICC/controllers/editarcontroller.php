<?php
require_once '../models/editarmodel.php';

class editarController {
    private $model;

    public function __construct() {
        $this->model = new EditarModel();
    }

    public function registrarcambio($datos) {
        if (empty($datos['insumo'])) {
            return json_encode(["status" => "error", "message" => "Por favor seleccione el insumo."]);
        }

        // Asignación de variables
        $insumo = $datos['insumo'];
        $formula = $datos['formula'];
        $estado = $datos['estado'];
        $fecha_vencimiento = $datos['fecha_vencimiento'];
        $lote = $datos['lote'];
        $ubicacion = $datos['ubicacion'];
        $codigo = $datos['codigo'];
        $cantidad = (float) $datos['cantidad'];
        $unidad_medida = $datos['unidad_medida'];

        // Intentar registrar el cambio en la base de datos
        $resultado = $this->model->registrarcambio($insumo, $formula, $estado, $fecha_vencimiento, $lote, $ubicacion, $codigo, $cantidad, $unidad_medida);

        if ($resultado === true) {
            // Redirección si la operación fue exitosa
            header("Location: ../views/admin/editar.php?success=1");
            exit();
        } else {
            // Devolver error en formato JSON
            return json_encode(["status" => "error", "message" => "No se pudo registrar el cambio."]);
        }
    }
}

// Solo ejecuta si es una solicitud POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $controller = new editarController();
    echo $controller->registrarcambio($_POST);
}
?>
