<?php
require_once '../models/conexion_bd.php';

try {
    $database = new Database();
    $db = $database->getConnection();

    $query = "SELECT reactivo, cantidad FROM inventario_laboratorio";
    $stmt = $db->prepare($query);
    $stmt->execute();

    $resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($resultados);
} catch (Exception $e) {
    echo json_encode(["error" => "Error al obtener los datos: " . $e->getMessage()]);
}
?>
