<?php
require_once '../models/conexion_bd.php';

class UsuarioController {
    private $db;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
    }

    public function obtenerUsuarios() {
        try {
            $sql = "SELECT 
                        usuario.id_usuario, 
                        usuario.nombre, 
                        usuario.telefono, 
                        usuario.correo, 
                        roles.nombre AS rol  
                    FROM usuario
                    INNER JOIN roles ON usuario.role_id = roles.id";  

            $stmt = $this->db->prepare($sql);
            $stmt->execute();
            $usuarios = $stmt->fetchAll();

            echo json_encode(["data" => $usuarios]);
        } catch (PDOException $e) {
            echo json_encode(["error" => $e->getMessage()]);
        }
    }
}

// Crear instancia y llamar a la función
$controller = new UsuarioController();
$controller->obtenerUsuarios();
?>


