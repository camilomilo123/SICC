<?php
require_once "../models/mostrarmodels.php";

$model = new InventarioModel();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $responsable = $_POST["responsable"];
    $insumo = $_POST["insumo"];
    $cantidad = $_POST["cantidad_salida"];
    $unidad = $_POST["unidad_medida"];
 

    if ($model->registrarSalida( $responsable,$insumo, $cantidad, $unidad)) {
        header("Location: ../views/laboratorio/laboratorio_salidas.php?success=1");
    } else {
        header("Location: .../views/laboratorio/laboratorio_salidas.php?error=1");
    }
}
?>
