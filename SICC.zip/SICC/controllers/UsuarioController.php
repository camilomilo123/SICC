<?php
require_once __DIR__ . '/../Models/UsuarioModel.php';
require_once __DIR__ . '/../Models/conexion_bd.php'; // Incluir la clase de conexión

class UsuarioController {
    private $usuarioModel;

    public function __construct() {
        $this->usuarioModel = new UsuarioModel(); // Quitar $pdo como argumento
    }

    public function listarUsuarios() {
        return $this->usuarioModel->obtenerUsuarios();
    }
}

// Crear instancia del controlador y obtener los usuarios
$usuarioController = new UsuarioController();
$usuarios = $usuarioController->listarUsuarios();




