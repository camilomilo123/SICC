<?php
require_once './models/reporte.php';

class ReportesController {
    public function obtenerDatos() {
        $reporte = new Reporte();
        $datos = $reporte->obtenerDatos(); // Método en el modelo
        echo json_encode($datos);
    }
}
?>

