<?php
require_once '../models/reporte.php';

class ReportesController {
    public function obtenerDatos() {
        $reporte = new Reporte();
        $datos = $reporte->obtenerDatos(); // Método en el modelo
        echo json_encode($datos);
    }

    public function obtenerDatosGrafico() {
        $reporte = new Reporte();
        $datos = $reporte->obtenerDatosGrafico(); // Método en el modelo
        echo json_encode($datos);
    }
}

// Manejo de las peticiones AJAX
if (isset($_GET['action'])) {
    $controller = new ReportesController();

    if ($_GET['action'] === 'obtenerDatos') {
        $controller->obtenerDatos();
    } elseif ($_GET['action'] === 'obtenerDatosGrafico') {
        $controller->obtenerDatosGrafico();
    }
}
?>


