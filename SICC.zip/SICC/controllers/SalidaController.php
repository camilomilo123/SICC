<?php
require_once '../models/SalidaModel.php';

class SalidaController {
    private $model;

    public function __construct() {
        $this->model = new SalidasModel();
    }

    public function registrarSalida($datos) {
        // Verificar s i la unidad de medida está presente en los datos recibidos
        if (!isset($datos['unidad_medida']) || empty($datos['unidad_medida'])) {
            return json_encode(["status" => "error", "message" => "La unidad de medida es obligatoria."]);
        }

        $dependencia = $datos['dependencia'];
        $insumo = $datos['insumo'];
        $cantidad_salida = $datos['cantidad'];
        $unidad_medida = $datos['unidad_medida'];
        $fecha = date("Y-m-d H:i:s");
        $descripcion = $datos['descripcion'];

        // Obtener la cantidad actual en el inventario
        $cantidadActual = $this->model->obtenerCantidadInventario($insumo);

        if ($cantidadActual !== false && $cantidadActual >= $cantidad_salida) {
            // Registrar la salida
            $resultado = $this->model->registrarSalida($dependencia, $insumo, $cantidad_salida, $unidad_medida, $fecha, $descripcion);

            // Si la salida fue exitosa, actualizar el inventario
            if ($resultado["status"] === "success") {
                $nuevaCantidad = $cantidadActual - $cantidad_salida;
                $this->model->actualizarCantidadInventario($insumo, $nuevaCantidad);
            }

            return json_encode($resultado);
        } else {
            return json_encode(["status" => "error", "message" => "No hay suficiente cantidad en el inventario."]);
        }
    }
}

// Manejo de la solicitud POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $controller = new SalidaController();
    $mensaje = $controller->registrarSalida($_POST);
    echo $mensaje;
}
?>
