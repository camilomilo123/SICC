<?php
session_start();
require_once '../models/SalidaModel.php';

class SalidaController {
    private $model;

    public function __construct() {
        $this->model = new SalidasModel();
    }

    public function registrarSalida($datos) {
        if (empty($datos['unidad_medida']) || empty($datos['insumo']) || empty($datos['cantidad'])) {
            echo json_encode(["status" => "error", "message" => "Todos los campos son obligatorios."]);
            return;
        }

        if (!isset($_SESSION['username'])) {
            echo json_encode(["status" => "error", "message" => "Usuario no autenticado."]);
            return;
        }

        $dependencia = $datos['dependencia'];
        $insumo = $datos['insumo'];
        $responsable = $_SESSION['username'];
        $cantidad_salida = (float) $datos['cantidad'];
        $unidad_medida = $datos['unidad_medida'];
        $descripcion = $datos['descripcion'] ?? '';
        $fecha = date("Y-m-d H:i:s");

        $resultado = $this->model->registrarSalida($dependencia, $insumo, $cantidad_salida, $unidad_medida, $fecha, $descripcion, $responsable);

        if ($resultado) {
            echo json_encode(["status" => "success", "message" => "Salida registrada correctamente."]);
        } else {
            echo json_encode(["status" => "error", "message" => "No se pudo registrar la salida."]);
        }
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    header("Content-Type: application/json");
    $controller = new SalidaController();
    $controller->registrarSalida($_POST);
    exit;
}
?>
